# Shadow Pack Integration — Instructions for Claude

You are integrating the SHADOW Pack character bundle into an existing game.js. The user has attached three files:

1. `game.js` — their existing game (~14k lines, three.js based)
2. `shadow_pack_assets.js` — 114 new sprite sheet entries + 8 entity configs
3. `shadow_pack_engine.js` — optional engine extensions (lightwizard color cycling)

Your job is to produce a modified `game.js` with the SHADOW Pack integrated, ready to ship.

---

## What's in the integration

**10 characters** (3 already in game.js, 7 brand new):

| Character | Status | Notes |
|---|---|---|
| toxcrawler | NEW | small sneaky enemy, 8 anims |
| hallokin | UPDATED | refined frame counts (death goes from n=3 → n=13) |
| huntress | UPDATED | full moveset (14 anims), refined hurt/idle counts |
| frostfiend | NEW | mid-size ice mage, charge+attack pairs combined into single attack1/2/3/full_attack |
| lightwizard | NEW | 3-color variant character (black/red/blue), `switch` anim cycles colors |
| wetlands | NEW | 7 anims, attack3 is combined pre+mid+end (14 frames) |
| shadeflit | UPDATED | full moveset (15 anims), before+after dash pairs combined |
| verdagger | NEW | small agile dagger user, 6 anims |
| icesentinel | NEW | large frosty knight, idle has different frame size than other anims |
| duskclaw | NEW | wraith with sword + throw move, 6 anims |

**Why some animations were combined:** the original SHADOW Pack ships some attacks as 3 separate sheets (`pre_X`, `mid_X`, `end_X`) or 2 separate sheets (`before_X`, `after_X` / `charge_X`, `attack_X`). The integration concatenates these horizontally into single sheets so they play as one continuous animation. The combined sheets in `shadow_pack_assets.js` use the simple name (e.g. `wetlandsAttack3` instead of three separate entries).

---

## Integration steps

### Step 1: Add the sprite sheets

Find the `SHEETS` object in game.js (search for `hallokinIdle:` — should be around line 608).

After the closing `}` of the `SHEETS` object, paste the entire `Object.assign(SHEETS, { ... });` block from `shadow_pack_assets.js` (the first half of the file).

**Watch for these conflicts:** the integration includes 8 entries that *replace* existing ones (marked `// [REPLACES existing]` in the assets file). These are corrections to hallokin/shadeflit/huntress where the original game.js values were wrong:

- `hallokinDeath`: existing n=3 → corrected to n=13 (original sheet has 13 death poses, game was only playing 3)
- `hallokinHurt`, `huntressIdle`, `huntressHurt`, `shadeflitIdle`, etc.: small fps/n corrections

Apply the replacements by deleting the existing entries first, then pasting the new ones. If gameplay timing was tuned around the old (truncated) values, ask the user before changing.

### Step 2: Add the entity configs

Find `Object.assign(COMPANION_CFG, { ... })` (search for `hallokinAlly:` — should be around line 2680).

After the closing `});`, paste the entire `Object.assign(COMPANION_CFG, { ... });` block from `shadow_pack_assets.js` (the second half of the file).

This adds 8 new ally configs: `toxcrawlerAlly`, `frostfiendAlly`, `lightwizardAlly`, `wetlandsAlly`, `shadeflitAlly`, `verdaggerAlly`, `icesentinelAlly`, `duskclawAlly`.

The configs use the existing structure (sheets, scale, baseY, shadowSize, maxHp, attackPower, attackRange, etc.) and reference the SHEETS keys you added in step 1. Every reference is validated.

The hp/damage/range/speed values are placeholders. Ask the user if they want to tune any of them, or leave them as conservative starter values.

### Step 3: Add recruiter entries (if the game has a recruit system)

Search game.js for `recruit_hallokinAlly`. If it exists (around line 12597), add parallel entries for the 8 new units, copying the structure:

```js
{ id: 'recruit_toxcrawlerAlly', source: 'recruiter',
  name: 'Recruit Toxcrawler', desc: '...',
  cost: 12, buy: () => spawnCompanionNearPlayer('toxcrawlerAlly') },
```

If there's no recruiter system, skip this step.

### Step 4: Optional — lightwizard 3-color cycling

The lightwizard ships in 3 color variants (black/red/blue). The default integration uses only the black variant, which works fine. If the user wants the wizard to actually cycle colors when its `switch` animation plays:

1. Open `shadow_pack_engine.js`
2. Apply the patch to `createAnimator` described in the file (adds ~6 lines for mid-anim frame hooks)
3. After creating the animator for any lightwizard entity, call `setupLightwizardVariants(animator)`
4. The wizard will now cycle black → red → blue → black each time its `switch` anim plays, with the swap happening invisibly during the empty middle frames of the animation

Skip this if the user doesn't ask for it. The base integration works without it.

### Step 5: Verify

After integrating, do these console checks:

```js
// Should print 13
console.log(Object.keys(SHEETS).filter(k => k.startsWith('frostfiend')).length);

// Should print 8 (the new ally configs)
console.log(Object.keys(COMPANION_CFG).filter(k => k.endsWith('Ally') && !['hallokinAlly','shadeflitAlly','huntressAlly','wbossAlly'].includes(k)).length);

// Should print sheet names that all exist in SHEETS
for (const ally of ['toxcrawlerAlly','frostfiendAlly','duskclawAlly']) {
  for (const [state, sheet] of Object.entries(COMPANION_CFG[ally].sheets)) {
    console.log(ally, state, sheet, !!SHEETS[sheet]);
  }
}
```

All `!!SHEETS[sheet]` should be `true`.

---

## Compatibility notes

The SHADOW Pack assets are structurally identical to the existing game.js sheet format:

- Same `{d, n, fps, loop}` schema
- Same `{char}{Anim}` camelCase naming convention
- Same handling of multi-stage attacks via separate sheets (existing `wbossAttack1`/`wbossAttack2` is the precedent for the new combined-into-one-sheet `frostfiendAttack1`)
- Same per-anim aspect ratio handling (`_getFrameDims` + `_applySheetAspect` already in game.js handles wider/taller frames automatically)

No changes to the core animation engine are needed for the base integration. Only the optional lightwizard color cycling needs a small engine patch.

---

## Output format

Produce the modified `game.js` file with:

1. The new SHEETS entries inserted in step 1
2. The new COMPANION_CFG entries inserted in step 2
3. Recruiter entries (if applicable) inserted in step 3
4. A short summary at the end of your response listing:
   - How many sheets were added
   - How many entity configs were added
   - Whether step 4 (lightwizard cycling) was applied
   - Any conflicts you flagged (the 8 replacement entries)

Don't paste the whole game.js back inline — produce it as a file artifact the user can download.
