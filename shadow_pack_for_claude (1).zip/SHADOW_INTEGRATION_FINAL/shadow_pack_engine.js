// =============================================================
// SHADOW Pack: optional engine extensions for game.js
//
// These are NOT required for basic integration. The 8 ally configs
// in cfg_additions.js work fine with the unmodified createAnimator.
// Only paste these in if you want:
//   1. Lightwizard 3-color variant cycling (driven by `switch` anim)
//   2. Mid-anim frame hooks (frame-by-frame events)
//
// Both extensions are additive: existing animator behavior is unchanged
// for any character that doesn't opt in via the new fields.
// =============================================================


// ---------------------------------------------------------------
// EXTENSION 1: Mid-anim frame hooks
// ---------------------------------------------------------------
// Lets a sheet's metadata (or the play() call) declare a callback that
// fires the first time `update()` advances into a specific frame index.
// Used by the lightwizard variant swap at frame 9 of `switch`, and could
// be reused for hit-frame VFX, footstep sounds, attack-active windows, etc.
//
// To install: replace the `update(dt)` body in createAnimator (around
// L1311 of game.js) with the version below. Two lines added at the
// "Mid-anim frame hook" comment, plus reset of _lastFrame on play().

/* PATCHED play() — add ONE line after `this.elapsed = 0;` */
// this._lastFrame = -1;   // <-- ADD: lets `update` detect 1st entry into frame 0

/* PATCHED update(dt) — full replacement */
function _patchedAnimatorUpdate(dt) {
  this.elapsed += dt;
  const sh = SHEETS[this.anims[this.current]];
  if (!sh) return;
  let f = Math.floor(this.elapsed * sh.fps);
  let done = false;
  if (sh.loop) f = f % sh.n;
  else if (f >= sh.n) { f = sh.n - 1; done = true; }
  const tex = this.textures[this.current];
  const facing = this.sprite.userData.facing || 1;
  if (facing < 0) {
    tex.repeat.x = -1 / sh.n;
    tex.offset.x = (f + 1) / sh.n;
  } else {
    tex.repeat.x = 1 / sh.n;
    tex.offset.x = f / sh.n;
  }

  // ---- Mid-anim frame hook ----
  // Fires once per frame transition. Hooks live on the sprite's userData
  // under `frameHooks: { animName: { frameIdx: callback } }`.
  if (this._lastFrame !== f) {
    const hooks = this.sprite.userData.frameHooks?.[this.current];
    if (hooks && hooks[f]) hooks[f](this.sprite, f);
    this._lastFrame = f;
  }

  if (done && this.locked) {
    this.locked = false;
    if (this.onComplete) { const cb = this.onComplete; this.onComplete = null; cb(); }
  }
}


// ---------------------------------------------------------------
// EXTENSION 2: Lightwizard 3-color variant cycling
// ---------------------------------------------------------------
// The wizard ships in 3 color sets: lightwizard*, lightwizardRed*,
// lightwizardBlue*. The `switch` animation cycles between them.
//
// Trick: frames 7-11 of switch are fully transparent (the teleport
// effect). Swapping the texture at frame 9 is invisible — character
// fades to black, swaps, fades back in red. No pop, no slide.
//
// Caveat: the red variant's idle has 9 frames vs black/blue's 8.
// Other anims are shape-identical across variants.
//
// To install:
//   1. Paste this file's `setupLightwizardVariants(animator)` helper.
//   2. After creating the animator for a lightwizard entity, call
//      `setupLightwizardVariants(animator)`.
//   3. Requires Extension 1 (mid-anim frame hooks) to be installed.

const LW_VARIANT_PREFIXES = ['lightwizard', 'lightwizardRed', 'lightwizardBlue'];
const LW_SWITCH_SWAP_FRAME = 9;

function setupLightwizardVariants(animator) {
  // Build 3 parallel texture maps, one per color.
  const baseAnims = animator.anims;            // {idle: 'lightwizardIdle', ...}
  const variantTextures = LW_VARIANT_PREFIXES.map(prefix => {
    const remap = {};
    for (const [state, sheet] of Object.entries(baseAnims)) {
      // sheet looks like 'lightwizardIdle' — strip the 'lightwizard' prefix
      // and re-attach the variant prefix.
      const suffix = sheet.replace(/^lightwizard(Red|Blue)?/, '');
      const variantSheet = prefix + suffix;
      remap[state] = SHEETS[variantSheet] ? makeAnimTex(variantSheet) : animator.textures[state];
    }
    return remap;
  });

  animator.sprite.userData.colorIdx = 0;
  animator.sprite.userData.variantTextures = variantTextures;

  // Hook frame 9 of the switch animation: advance colorIdx and swap the
  // active material map. Subsequent frames render in the new color.
  animator.sprite.userData.frameHooks = {
    switch: {
      [LW_SWITCH_SWAP_FRAME]: (sprite) => {
        const ud = sprite.userData;
        ud.colorIdx = (ud.colorIdx + 1) % 3;
        const newSet = ud.variantTextures[ud.colorIdx];
        if (newSet[animator.current]) {
          // Re-bind animator.textures so future state changes also use the
          // new variant. Then swap the active material map immediately.
          for (const state in newSet) {
            animator.textures[state] = newSet[state];
          }
          sprite.material.map = animator.textures[animator.current];
          sprite.material.needsUpdate = true;
        }
      },
    },
  };
}

// Usage example after creating a lightwizard companion:
//   const animator = createAnimator(sprite, lightwizardCfg.sheets, 'idle');
//   setupLightwizardVariants(animator);
