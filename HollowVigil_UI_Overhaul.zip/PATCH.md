# Hollow Vigil — UI Overhaul Patch (one-shot, fully self-contained)

Every sprite (Style 1 health bar, Pixelwood book frames, toolbar, portraits, bookmarks, artwork, icon containers, dialog paper, time-of-day, compass, gold counter — 72 files total) is base64-embedded inside the JS module in Step 3. No external files are required.

After applying:

- Style 1 chevron + bush health bar with heart icon and red fill
- 9-slot hotbar with smoothly-animated chooser sprite
- 7-frame animated book opening that replaces the journal modal, with four bookmark tabs (Quests, Inventory, Equipment, Calendar)
- Full inventory: 24-slot bag, click to use or equip, right-click to bind to hotbar
- Equipment paper-doll: weapon, armor, charm, head, ring 1, ring 2 with stat-totals panel
- Quest page reusing existing journal data
- Calendar page with day count and dawn / day / sunset / night phase sprites
- Portrait + gold + time-of-day HUD strip
- Magical paper dialog box skin
- Compass rose over the minimap
- Item registry of 28 items, drop tables per zone, save/load schema bumped to v4
- Item pickup toast and rich item tooltips

Apply order matters. Do every step in order.

---

## STEP 0 — No asset placement needed

All 72 sprite files are embedded as base64 data URIs inside the JS module in Step 3. Skip directly to Step 1.

---

## STEP 1 — index.html edits

### 1a. Bump cache version

Find the `<link rel="stylesheet"` tag and the bottom `<script src="game.js"` tag. Change both `?v=expansion4` to `?v=ui_overhaul1`.

### 1b. Replace the existing health bar markup

Find this block (inside `<div id="hud" class="ui">`):

```html
  <div id="healthBar"><div id="healthGhost"></div><div id="healthFill" style="width:100%"></div></div>
```

Replace with:

```html
  <div id="healthBarV2">
    <div class="hbBackPlate"></div>
    <div class="hbFillWrap">
      <div class="hbGhost"></div>
      <div class="hbFill"></div>
    </div>
    <div class="hbHeartIcon"></div>
    <div class="hbBushL"></div>
    <div class="hbBushR"></div>
    <div class="hbText"><span id="hbCur">100</span><span class="hbSep">/</span><span id="hbMax">100</span></div>
  </div>
```

### 1c. Add the portrait + gold + time-of-day strip

Inside `<div id="hud" class="ui">`, after the new health bar block, add:

```html
  <div id="portraitFrame">
    <img id="portraitImg" alt="">
    <div id="portraitBadge"><span id="portraitLevel">1</span></div>
  </div>
  <div id="goldStrip">
    <div class="gsFrame"></div>
    <span id="goldNumNew">0</span>
  </div>
  <div id="todStrip">
    <div class="todFrame"></div>
    <img id="todIcon" alt="">
    <div id="todLabel">DAY 1 · DAWN</div>
  </div>
```

The `src` attributes are deliberately empty — the JS module fills them with data URIs at init.

### 1d. Add hotbar, book overlay, compass, toast, tooltip

Just before the closing `</body>` tag, insert:

```html
<div id="hotbar">
  <div class="hbBody"></div>
  <div id="hbSlots"></div>
  <div id="hbChooser"></div>
</div>

<div id="bookOverlay" class="hidden">
  <div id="bookFrame">
    <div id="bookSprite"></div>
    <div id="bookPages">
      <div id="bookLeft" class="bookPage"></div>
      <div id="bookRight" class="bookPage"></div>
    </div>
    <div id="bookTabs">
      <button class="bookTab active" data-tab="quests"><span>Quests</span></button>
      <button class="bookTab" data-tab="inventory"><span>Inventory</span></button>
      <button class="bookTab" data-tab="equipment"><span>Equipment</span></button>
      <button class="bookTab" data-tab="calendar"><span>Calendar</span></button>
    </div>
    <button id="bookClose" aria-label="Close">close</button>
  </div>
</div>

<div id="compassOverlay"><img id="compassImg" alt=""></div>
<div id="itemPickupToast"></div>
<div id="tooltipPopover" class="hidden"></div>
```

### 1e. Hide the legacy controls box

Delete the entire `<div id="controls" class="ui">...</div>` block.

---

## STEP 2 — styles.css additions

Append the entire block below to the end of `styles.css`. Layout, sizing, and animations only — every background image is a CSS variable (e.g. `var(--img-hb-back)`) that the JS module sets at startup using the embedded base64.

```css
/* ============================================================================
   UI OVERHAUL — appended block. Every background image is a CSS variable;
   JS injects the base64 values into :root at init.
   ============================================================================ */

img, .pixelated, [class^="hb"], [id^="book"], [id^="hb"],
#hotbar, #portraitFrame, #goldStrip, #todStrip, #compassOverlay {
  image-rendering: pixelated;
  image-rendering: -moz-crisp-edges;
  image-rendering: crisp-edges;
}

/* ----- Style 1 health bar ----- */
#healthBar { display: none !important; }
#healthBarV2 {
  position: relative;
  width: 360px; height: 64px;
  margin-top: 10px;
  user-select: none;
  pointer-events: none;
}
#healthBarV2 .hbBackPlate {
  position: absolute; left: 36px; right: 28px; top: 18px; height: 28px;
  background-image: var(--img-hb-back);
  background-size: 100% 100%; background-repeat: no-repeat;
}
#healthBarV2 .hbFillWrap {
  position: absolute; left: 46px; right: 38px; top: 24px; height: 16px;
  overflow: hidden; border-radius: 2px;
}
#healthBarV2 .hbGhost {
  position: absolute; left: 0; top: 0; height: 100%;
  width: 100%;
  background: linear-gradient(180deg, #ffe066 0%, #ffaa44 100%);
  box-shadow: inset 0 1px 0 rgba(255,255,255,0.45);
  transition: width 0.65s ease-out 0.18s;
}
#healthBarV2 .hbFill {
  position: absolute; left: 0; top: 0; height: 100%;
  width: 100%;
  background-image: var(--img-hb-fill-red);
  background-size: auto 100%; background-repeat: repeat-x;
  transition: width 0.32s cubic-bezier(0.22, 1, 0.36, 1);
  box-shadow: inset 0 1px 0 rgba(255,210,180,0.35), inset 0 -1px 0 rgba(40,0,0,0.5);
}
#healthBarV2 .hbHeartIcon {
  position: absolute; left: 0; top: 8px;
  width: 48px; height: 48px;
  background-image: var(--img-hb-heart);
  background-size: contain; background-repeat: no-repeat;
  filter: drop-shadow(2px 2px 0 rgba(0,0,0,0.5));
  transform-origin: center;
}
#healthBarV2 .hbBushL,
#healthBarV2 .hbBushR {
  position: absolute; top: 32px;
  width: 22px; height: 18px;
  background-image: var(--img-hb-bush);
  background-size: contain; background-repeat: no-repeat;
}
#healthBarV2 .hbBushL { left: 32px; }
#healthBarV2 .hbBushR { right: 22px; transform: scaleX(-1); }
#healthBarV2 .hbText {
  position: absolute; left: 46px; right: 38px; top: 22px;
  text-align: center; font-size: 12px; color: #fff;
  text-shadow: 1px 1px 0 #000, -1px 0 0 #000, 0 1px 0 #000, 1px 0 0 #000;
  letter-spacing: 1px; z-index: 3;
}
#healthBarV2 .hbSep { opacity: 0.6; margin: 0 3px; }
#healthBarV2.crit .hbHeartIcon { animation: heartPulse 0.55s ease-in-out infinite; }
@keyframes heartPulse {
  0%, 100% { transform: scale(1); filter: drop-shadow(2px 2px 0 rgba(0,0,0,0.5)); }
  50%      { transform: scale(1.18); filter: drop-shadow(0 0 14px rgba(255,80,40,0.95)) drop-shadow(2px 2px 0 rgba(0,0,0,0.5)); }
}
#healthBarV2.damaged { animation: hbShake 0.35s ease-out; }
@keyframes hbShake {
  0%,100% { transform: translate(0,0); }
  25%     { transform: translate(-3px,1px); }
  50%     { transform: translate(3px,-1px); }
  75%     { transform: translate(-2px,0); }
}

/* ----- Portrait, gold, time-of-day ----- */
#portraitFrame {
  position: relative; margin-top: 12px;
  width: 64px; height: 64px;
  background: rgba(20,12,6,0.7);
  border: 3px solid #5a3a20; border-radius: 6px;
  box-shadow: 0 0 8px rgba(0,0,0,0.5);
}
#portraitFrame img { width: 100%; height: 100%; object-fit: cover; }
#portraitBadge {
  position: absolute; right: -8px; bottom: -8px;
  min-width: 24px; height: 24px; padding: 0 6px;
  background: #c8a04c; color: #1a0a02;
  border: 2px solid #1a0a02; border-radius: 50%;
  font-weight: bold; font-size: 12px;
  display: flex; align-items: center; justify-content: center;
  text-shadow: none;
}
#goldStrip {
  position: relative; margin-top: 10px;
  width: 160px; height: 36px;
  display: flex; align-items: center; justify-content: center;
}
#goldStrip .gsFrame {
  position: absolute; inset: 0;
  background-image: var(--img-gold-frame);
  background-size: 100% 100%; background-repeat: no-repeat;
}
#goldNumNew {
  position: relative; z-index: 2;
  font-size: 18px; color: #ffe066;
  text-shadow: 2px 2px 0 #000;
  letter-spacing: 1px;
}
#goldNumNew.bump { animation: goldBump 0.45s cubic-bezier(0.34, 1.56, 0.64, 1); }
@keyframes goldBump {
  0%   { transform: scale(1); color: #ffe066; }
  35%  { transform: scale(1.45) rotate(-3deg); color: #fff; text-shadow: 0 0 14px #ffd866, 2px 2px 0 #000; }
  100% { transform: scale(1); color: #ffe066; }
}
#todStrip {
  position: relative; margin-top: 8px;
  width: 160px; height: 32px;
  display: flex; align-items: center; padding-left: 36px;
}
#todStrip .todFrame {
  position: absolute; inset: 0;
  background-image: var(--img-tod-frame);
  background-size: 100% 100%; background-repeat: no-repeat;
  opacity: 0.92;
}
#todStrip img {
  position: absolute; left: 4px; top: 50%; transform: translateY(-50%);
  width: 28px; height: 28px;
}
#todLabel {
  position: relative; z-index: 2;
  font-size: 10px; letter-spacing: 2px; color: #f4d68a;
  text-shadow: 1px 1px 0 #000;
}

/* ----- Hotbar ----- */
#hotbar {
  position: fixed; left: 50%; bottom: 22px;
  transform: translateX(-50%);
  width: 720px; height: 80px; z-index: 18;
  pointer-events: auto;
}
#hotbar .hbBody {
  position: absolute; inset: 0;
  background-image: var(--img-tb-body);
  background-size: 100% 100%; background-repeat: no-repeat;
}
#hbSlots {
  position: absolute; inset: 14px 18px 18px 18px;
  display: grid; grid-template-columns: repeat(9, 1fr); gap: 4px;
  z-index: 2;
}
#hbSlots .hbSlot {
  position: relative;
  background: rgba(0,0,0,0.18);
  border-radius: 4px; cursor: pointer;
  transition: filter 0.15s ease, transform 0.15s ease;
}
#hbSlots .hbSlot:hover { filter: brightness(1.2); transform: translateY(-2px); }
#hbSlots .hbSlot .hbSlotIcon {
  position: absolute; inset: 6px;
  background-size: contain; background-repeat: no-repeat; background-position: center;
  image-rendering: pixelated;
}
#hbSlots .hbSlot .hbSlotNum {
  position: absolute; left: 4px; top: 2px;
  font-size: 10px; color: #f4d68a;
  text-shadow: 1px 1px 0 #000; pointer-events: none;
}
#hbSlots .hbSlot .hbSlotCount {
  position: absolute; right: 4px; bottom: 2px;
  font-size: 10px; color: #fff;
  text-shadow: 1px 1px 0 #000; pointer-events: none;
}
#hbChooser {
  position: absolute; top: 8px; width: 64px; height: 64px;
  background-image: var(--img-tb-chooser);
  background-size: contain; background-repeat: no-repeat;
  pointer-events: none;
  transition: left 0.14s cubic-bezier(0.22, 1, 0.36, 1);
  z-index: 3;
  filter: drop-shadow(0 0 6px rgba(255,220,140,0.6));
  animation: chooserBob 1.4s ease-in-out infinite;
}
@keyframes chooserBob {
  0%,100% { filter: drop-shadow(0 0 6px rgba(255,220,140,0.6)); }
  50%     { filter: drop-shadow(0 0 12px rgba(255,220,140,0.95)); }
}
#hbSlots .hbSlot.selected { box-shadow: inset 0 0 0 2px rgba(255,220,140,0.7); }

/* ----- Book overlay (animated open) ----- */
#bookOverlay {
  position: fixed; inset: 0;
  background: rgba(8,6,4,0.78);
  display: flex; align-items: center; justify-content: center;
  z-index: 60;
  opacity: 0;
  transition: opacity 0.22s ease;
  pointer-events: none;
}
#bookOverlay.hidden { display: none; }
#bookOverlay.show { opacity: 1; pointer-events: auto; }
#bookFrame {
  position: relative;
  width: 880px; height: 560px;
  transform: scale(0.55) rotate(-4deg);
  transition: transform 0.42s cubic-bezier(0.34, 1.56, 0.64, 1);
}
#bookOverlay.show #bookFrame { transform: scale(1) rotate(0); }
#bookSprite {
  position: absolute; inset: 0;
  background-image: var(--img-book-f1);
  background-size: 100% 100%; background-repeat: no-repeat;
  image-rendering: pixelated;
}
#bookPages {
  position: absolute;
  left: 6%; right: 6%; top: 12%; bottom: 8%;
  display: grid; grid-template-columns: 1fr 1fr; gap: 24px;
  opacity: 0;
  transition: opacity 0.28s ease 0.45s;
  z-index: 2;
}
#bookOverlay.show.pagesReady #bookPages { opacity: 1; }
.bookPage {
  position: relative;
  padding: 14px 18px;
  font-size: 13px; color: #4a3220;
  text-shadow: none;
  overflow-y: auto;
  scrollbar-width: thin;
}
.bookPage h2 {
  margin: 0 0 8px 0;
  font-size: 18px; letter-spacing: 2px; color: #6e3a1a;
  text-align: center;
  border-bottom: 1px solid #b08a5a;
  padding-bottom: 6px;
}
.bookPage p, .bookPage .qBody { line-height: 1.5; margin: 4px 0 8px 0; }

#bookTabs {
  position: absolute;
  right: -38px; top: 60px;
  display: flex; flex-direction: column; gap: 4px;
  z-index: 3;
}
.bookTab {
  width: 80px; height: 56px;
  background: transparent;
  background-image: var(--img-bm-back);
  background-size: 100% 100%; background-repeat: no-repeat;
  border: 0; cursor: pointer;
  color: #f4d68a;
  font-size: 11px; letter-spacing: 1px;
  text-align: left; padding: 6px 0 0 14px;
  transform: translateX(-12px);
  transition: transform 0.18s cubic-bezier(0.22, 1, 0.36, 1), filter 0.18s ease;
  filter: brightness(0.85);
}
.bookTab:hover  { transform: translateX(-2px); filter: brightness(1); }
.bookTab.active { transform: translateX(8px);  filter: brightness(1.15); }
#bookClose {
  position: absolute; right: -34px; top: -10px;
  width: 28px; height: 28px;
  background: #5a3a20; color: #f4d68a;
  border: 2px solid #2a1a08;
  border-radius: 50%; cursor: pointer;
  font-size: 10px; letter-spacing: 1px;
  z-index: 4;
  transition: background 0.15s ease, transform 0.15s ease;
}
#bookClose:hover { background: #c8a04c; color: #1a0a02; transform: scale(1.1); }

/* ----- Inventory page ----- */
.invGrid {
  display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px;
  margin-top: 12px;
}
.invCell {
  position: relative;
  aspect-ratio: 1 / 1;
  background-image: var(--img-cell1);
  background-size: 100% 100%; background-repeat: no-repeat;
  cursor: pointer;
  image-rendering: pixelated;
  transition: filter 0.15s ease, transform 0.15s ease;
}
.invCell:hover { filter: brightness(1.2); transform: scale(1.05); }
.invCell .invIcon {
  position: absolute; inset: 18%;
  background-size: contain; background-repeat: no-repeat; background-position: center;
}
.invCell .invCount {
  position: absolute; right: 4px; bottom: 2px;
  font-size: 11px; color: #fff; text-shadow: 1px 1px 0 #000;
}
.invCell.equipped { box-shadow: 0 0 0 2px #c8a04c, 0 0 12px #ffd866 inset; }

.invHeaderArt {
  width: 100%; height: 60px;
  background-image: var(--img-art-inventory);
  background-size: contain; background-repeat: no-repeat; background-position: center;
  margin-bottom: 4px;
}
.eqHeaderArt   { background-image: var(--img-art-equipment); }
.qstHeaderArt  { background-image: var(--img-art-quest); }
.calHeaderArt  { background-image: var(--img-art-calendar); }

/* ----- Equipment paper-doll ----- */
.eqDoll {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  grid-template-rows: 1fr 1fr 1fr;
  gap: 8px; height: 280px; margin-top: 12px;
}
.eqSlot {
  position: relative;
  background-image: var(--img-cell2);
  background-size: 100% 100%; background-repeat: no-repeat;
  display: flex; align-items: center; justify-content: center;
  cursor: pointer;
  transition: filter 0.15s ease;
}
.eqSlot:hover { filter: brightness(1.15); }
.eqSlot[data-slot="head"]   { grid-area: 1 / 2 / 2 / 3; }
.eqSlot[data-slot="weapon"] { grid-area: 2 / 1 / 3 / 2; }
.eqSlot[data-slot="armor"]  { grid-area: 2 / 2 / 3 / 3; }
.eqSlot[data-slot="charm"]  { grid-area: 2 / 3 / 3 / 4; }
.eqSlot[data-slot="ring1"]  { grid-area: 3 / 1 / 4 / 2; }
.eqSlot[data-slot="ring2"]  { grid-area: 3 / 3 / 4 / 4; }
.eqSlot .eqLabel {
  position: absolute; bottom: -14px; left: 0; right: 0;
  text-align: center; font-size: 9px; letter-spacing: 1px; color: #6e3a1a;
}
.eqSlot .eqIcon {
  width: 60%; height: 60%;
  background-size: contain; background-repeat: no-repeat; background-position: center;
}
.eqStats {
  margin-top: 22px; font-size: 12px; line-height: 1.6; color: #4a3220;
  border-top: 1px solid #b08a5a; padding-top: 8px;
}
.eqStats b { color: #6e3a1a; }

/* ----- Calendar ----- */
.calBlock {
  margin-top: 8px; display: flex; flex-direction: column; gap: 8px;
  align-items: center;
}
.calBigDay {
  font-size: 36px; color: #6e3a1a; letter-spacing: 4px;
  text-shadow: 1px 1px 0 #d8b67a;
  animation: calPulse 3s ease-in-out infinite;
}
@keyframes calPulse {
  0%,100% { text-shadow: 1px 1px 0 #d8b67a; }
  50%     { text-shadow: 1px 1px 0 #d8b67a, 0 0 18px rgba(255,210,140,0.55); }
}
.calIcon {
  width: 96px; height: 96px;
  background-size: contain; background-repeat: no-repeat; background-position: center;
}
.calLabel { font-size: 14px; color: #4a3220; letter-spacing: 2px; }

/* ----- Compass ----- */
#compassOverlay {
  position: fixed; top: 16px; right: 296px;
  width: 64px; height: 64px;
  z-index: 14; pointer-events: none;
}
#compassOverlay img {
  width: 100%; height: 100%;
  filter: drop-shadow(2px 2px 0 rgba(0,0,0,0.6));
  animation: compassBob 6s ease-in-out infinite;
}
@keyframes compassBob {
  0%,100% { transform: rotate(0deg) translateY(0); }
  50%     { transform: rotate(2deg) translateY(-2px); }
}

/* ----- Item pickup toast ----- */
#itemPickupToast {
  position: fixed; left: 50%; top: 28%;
  transform: translateX(-50%) translateY(20px);
  padding: 8px 14px;
  background-image: var(--img-dlg-paper);
  background-size: 100% 100%; background-repeat: no-repeat;
  font-size: 13px; color: #2a1a08; letter-spacing: 1px;
  opacity: 0; pointer-events: none;
  z-index: 30;
  transition: opacity 0.22s ease, transform 0.22s ease;
  min-width: 260px; text-align: center;
}
#itemPickupToast.show {
  opacity: 1; transform: translateX(-50%) translateY(0);
  animation: toastWiggle 0.55s ease-out;
}
@keyframes toastWiggle {
  0%   { transform: translateX(-50%) translateY(20px) rotate(-3deg); }
  60%  { transform: translateX(-50%) translateY(-4px) rotate(2deg); }
  100% { transform: translateX(-50%) translateY(0) rotate(0); }
}

/* ----- Tooltip ----- */
#tooltipPopover {
  position: fixed; z-index: 80;
  padding: 10px 14px;
  background-image: var(--img-dlg-paper2);
  background-size: 100% 100%; background-repeat: no-repeat;
  color: #2a1a08; font-size: 12px; line-height: 1.5;
  max-width: 240px; pointer-events: none;
}
#tooltipPopover.hidden { display: none; }
#tooltipPopover .tipName  { font-weight: bold; color: #6e3a1a; font-size: 14px; }
#tooltipPopover .tipFlavor { color: #6a4a30; font-style: italic; margin-top: 4px; }
#tooltipPopover .tipStat   { margin-top: 2px; }
#tooltipPopover .tipStat b { color: #1a4a1a; }

/* ----- Dialog skin upgrade ----- */
#dialogBox.useNewSkin #dialogFrame {
  background-image: var(--img-dlg-box);
  background-size: 100% 100%; background-repeat: no-repeat;
  border: none;
  box-shadow: 0 0 24px rgba(0,0,0,0.6);
}
```

---

## STEP 3 — game.js: append the HV_UI module

Append the entire block below at the very end of `game.js`. It defines the embedded base64 image table, sets up CSS variables, and owns inventory, equipment, hotbar, animated book, calendar, item registry, and pickup toast. Everything is namespaced under `HV_UI` so it cannot collide with existing code.

```javascript
/* ============================================================================
   HV_UI — UI overhaul module. Self-contained: every sprite is base64.
   ============================================================================ */
(function () {
  if (window.HV_UI) return;
  const HV_UI = window.HV_UI = {};

  // ---------- IMAGE TABLE (every sprite, base64) --------------------------
  HV_UI.IMG = {
    hbBack: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAgCAYAAADtwH1UAAAAAXNSR0IArs4c6QAAAlFJREFUaIHtmjGOwjAQRX9QuMAKRMUBUgBNtuIouQRH4RIchSo0QMEBqBAoF9iCLRZHxtjxeGISL/KT0Cps7D/+48TOhASfz105TnqJwkBQwbwB1XxBMOMOJpA3YDJfEMTYgwjiDTyZv14uAACr7V49r/fxJ7DPFJ/t2iCbRdYW5gs0STBpdMKA2a5r82VNZ+3Vdl8bryZEo+HjQ4abgL5gmd8D5DiT9XJxB4CyGuL768faQB6QZTbBpV+qpot2Ww0PWG9pKafXIstbm0qlC/NFn2U1fPqOOiFlP5R477AkIZVF1QCaeNe5MpvT7uW7IstRVqzunHCdYGKMRZarcTcmoY/dzMdSZDmAv+RRt7z/bREOGjHzy2qou01qJ3pMAJMiy+sZL+OahJgAJsfrBcfrpT6WkyGvAbYkxDWAgW4XJhZhk/mmNSEmwJGm7apjEmICuMQrIADmoykA4HA7A3jd/zc8nAHSljQuwkxm4wlm40l9zDFfHMQrwCOuD2OsWlDkFXkb6vIknNoKW/KK77MAZ1u0TG3axFBWQ2N9iVv72Zx2bPMByxUQkvk+NE3mi//bxkgpKrq+9kyplUpuRdNESObL57VBo2F9HxDEIqyrqfhEZ74JSizE/kjvl4NIQBPqftsD5DHL2o5xkF/uB/8cIO+356NpbQSTRPlL1j7czpiNJ5QrxOmXFYNHgz4/ZBxM0KFqWWMRtxpT6dnQT6ugQuHpFtFUd3/gexxGfc5C20SoCQA6NIGib6C1bsgJADoyganvRTf0BAAdmMDQ96b7Czt3IQ2Pp5HYAAAAAElFTkSuQmCC',
    hbHeart: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAAA2xJREFUeJztWjFuWzEMfS7qCxQpigTImMFD48WZfBRfwkfxJXwUT/HiZMjQqQjQIoiRduvQwR0KfehLJEVJtF3XeoARWNan+J4oil8R0NDQ0NDQ0NDQ0HCWGHA/XN5cAQC+f/lWPYiz9evHED+3X2tM7YLvrP9avJN+tCBvaCckz7VlQRTgH4JEtEqEUxCgR3AxHWMxHYt9ckAKcHlzZRb+lvCJW4kQCaAgv8v41IC0MV9tMF9tAJAiZCMSQEE+Bz0xMnYAdpwE6eqkmDJe+zEbZzEdm0Reah8ljWlCz4Vp5phRwgtx/zYEANx9+J0aT1UjSLtANfnZaILZaKKyG7ZL5Ev9osAJULyWfPIOChGyyIezX4P3qQ6+M2GYCWHewTl7Nx2H/Xf4G6ZJ8uE4y0T/HFARQG49uVg+raOZSu3dGvLWECtBafY1oJ4hlgPbrhlTygsa7L0U9kk4Z0OypeRDuyUQBQizOTd7KcxXm8hJZ8v99ZdLSbSVikAlwV5iipwpFGH5tGZnvpZ8DbgIqD5ooLB8WkdtxyQPyNtgtEVZIBRhyfQ7FFJ1gIuETgh/xo7tfAL+5LERfQoHIhZgI/lcBAAYEZKl8CmB2qaDnOPK7w7/lQBhgnW1C7X7OJz8EqDI5RRsxRFwjD2bgySCNPuAvuAhE4h2kH2gcOyIb07F1xMhLGMPGRGKZEeB5JqTAyIDflFkcUStwWI6js4ZSskDFUmQGnTfIvj2nQiEHwPiwyJXgJ6xMOzv34bFr8wpUOIy5LNQEgGkCP77uLUIygOTojfYmtdeMin6sNgdfLtCwi3mUfvev1cRMu0VcamtBHuDUs7dXlxXDhHbv724NrNrXgr7Ijy+vgDIF8H1D2259oftc62bHUyXgO+gT/rzx08AdMthNpp0wvlEKREDIY6yBDpws+PIA+ndwf3unvFJP2yfe7Zzo8Bd1AphFgHSDPnEH19fSOfd875gGQlU5CHdeDOLgJAURZLLCf5318eKvAN38cPi+Ft1csxFiGJtA8ThbNAuQrr2YxEBKieksE/0G3jrV13ja2G1BDhneu2pxCXMfDG45OdgeSYoidCFbkHYZ4EiLF382su/wBiQNQOQJq+9t1xyv/mQAgC6hEn6lCJXern70AIAsggH9+cYAgC0CMfypaGhoeF88Qd2gKwmVUxHNgAAAABJRU5ErkJggg==',
    hbFillRed: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAgCAYAAADtwH1UAAAAAXNSR0IArs4c6QAAAN5JREFUaIHt1sENgjAUxvFX5QQL2IQxuLuDi7gZO3B3DBNYQK94Kmkq0hehNMb/LzExtf1e2zwDIgAAAAAAAPgXpq3tmHsTv+By702K3IP70lTl9FmimaMRZuSuH5OqUYtw4PZ4qhfPHUKz3q1rqvJt/t71/XXf5q1RhJsQEen6YXby2Z6igS5vaePut7Cbc9TfIm+NInZoX9cPIt4lxLrGz/QvbxqfG8tU/1Ne6n+AaWs7ag4vouvA0FK2y8tdXyvFg9hcjyb6cAm7Z+uLyF1fk5fqLQgAAAAAAADATl5PcYNgYS2pJgAAAABJRU5ErkJggg==',
    hbFillBlue: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAgCAYAAADtwH1UAAAAAXNSR0IArs4c6QAAAN9JREFUaIHt1r0NwjAQhmEHuUyXGdImpERiFdiCKdiCWegRtMxARw+VI+sw9ongWIj3kZAQnL+7RMePMQAAAAAAAPgX1Xq7f5Qe4hccD7sqR+7CPWmGfnzEaGo0ZEbp/im5FtXKF26ns/pw6CI05925Zuhf6ufu75/7NG8KK4cwxpj79RIsrtsuGejyYoO79+Q2l+j/jbwpbOqifbImtTV+vX/zQr1K93+Xl/0TEBtICm1gbMC67cbsWI/S/bV5OVTL1Sb54yK3R/NVIGlvQIn+mrxc/4IAAAAAAAAAzOQJjL2NgC7ODfcAAAAASUVORK5CYII=',
    hbFillPurple: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAgCAYAAADtwH1UAAAAAXNSR0IArs4c6QAAAOVJREFUaIHt1j0OgkAQhuHFcAM6QuIR6LEmJp7H0tLSG1FL7x2InWfQaslkwd2JuGyM75OQKOx+M5DxxxgAAAAAAAD8i+y8uzxTN/ELTtdjFiN3Y1+URT0ePpo1Gm5G6vohsQY1d0/cHzf15rmb0Oy3+8qinqxfu77c92neErnbhDHG9EM3u7ip2mCgzfM1bq+505yi/jfylshDNy31Q2ca8T40NTJTPjx7Xmalrv8uL/onQDYUMjeBvgabqh2zfTVS19fmxZAdtvvgj4s7PZqvApf2AaSor8mL9S8IAAAAAAAAwEpej7yMOwZF/AcAAAAASUVORK5CYII=',
    hbBush: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAARhJREFUWIXtVjsOwjAMdRFDJKQMbCDBRifUS3AWDsDAKRg4AGfhEhVT2Rhgz5StnVKZEjtOg2DJkyJVrZ334k9cgIyMjD+jkBhppVruu7FWtM8oASHyVBGsEyY/XLZem/P+RgpabJYAAPC6P0mOSQo5900r1XLEDt4ISMkp4KjMVvNiVAQo8rox/YrxozCVGnKEQ5uq1GIBbARiyDFwCkJ1wApwG4VOhE9elfotBaE2JtvQ57g7rvtnLKpujFckjgR1T5AR8DlcT48PcixiCEkk2BQYawu33DsuHb4OCXWEqAg5xBZosgCcV4ocR4m6qh2iBgiVR6o4JUUYPcFCIlyhYnCTcvQcDwmSkH9FgE9Eyg9KRkbGz9EBCqaE9GHz2hcAAAAASUVORK5CYII=',
    iconHeartRed: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACEAAAAdCAYAAAAkXAW5AAAAAXNSR0IArs4c6QAAAURJREFUSIm118sNwjAMAFCHcoIFqMQY3NmBRToLi3QH7h0DqV2A3qpwqGoSNx/HDpYqlXycp7qfYMAPS34bqBc0N+Y3iQE1Icn8hg7omnXN5+I1ayCYqL+22Ph4j3h+dBe/t5ff1HFyIVYI8QC38wk7usZg/kNs9r294FWhCbUAGkHENkEBYQOiCCWkCJBEMCCxIwsYPjMfkYFEIwegfcfgyABk+Mzr0zNOu37vqXLgHAAbsYME+nIRAwBEykFrVrIYB8C+J2pBcgAP8VwsvEi9tZAY4OW/jeEAzuu4BFILAABmuxJVISUAAP+eqAIpBVCEGiIBhBBiiBQQbHACZ+72GoGQAnIINkQDAMh/wJKloSEBcBBsiBTAGuBEtjQSQCkiCZECpIG7qK4xtr+2tmtMcHf17/AgWkCVPzXafNq6uRBxri8uvBc5YtstIgAAAABJRU5ErkJggg==',
    iconHeartBlue: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACEAAAAdCAYAAAAkXAW5AAAAAXNSR0IArs4c6QAAAUZJREFUSImt1z0OwjAMBeAXxNiNM7BCGZG4CtyCU3ALunEOJEZ+ViYOwMZeBtQoMUnj2LbEQJO+fkpKaxzi6sl3B7ui2T7fjUywhIzmOzqhXW8BALdLZwXx+ZvdwR88H/dReD9cvJkv/MDn+bCARIDZaukHXqfO509yZzfzhV8VGqgF0EoihhMUEDYgi1BCqgCjCAYk9ykC3tc7H1GAZKsEoGNTTuhstcT7ev9B8A8Jf1UhnANgIygkNVaqHADIbAfds5qLcQDse8IKUgJEiNulw+f5MIXkAPRpPEHwOK6BWAEAuGElTCE1ACC+J0wgtQCKUEMkgBRCDJECkgeC8u8B2mukSgooIdgQDQAov8BGt4aWBMBBsCFSAGtCUMWtkfaltc1rFqJpjFUd9AAx6sxFkB5A3663yfaupkz+1GjztMsWQsRZXyxZEoz6MVPyAAAAAElFTkSuQmCC',
    iconHeartPurple: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACEAAAAdCAYAAAAkXAW5AAAAAXNSR0IArs4c6QAAAUNJREFUSIm1100KwjAQBeAX8QbuROgR3OtaCj2PS5cuPY8grnXvEQRx5xnqqkMy5mcyGR8ImqbTj0410SHMyD472IXXpvouM8ESkq3v+ISh6wEA5+fFCkL1j9sTDR5ue3o/9y++We2Csz3IqIQEgOViTQeGrqf6s9TZm9WO7gov2ArgiSKmExogYkAS0QipAmQRAkjqVQS8Pw85ogBJpgTgx+bRmRHI+/P4+fZM4eM1ADGiBJH0PQUAEu3gPau5mAQgfiasICVAgDg/L7i/rqaQFOD+ugbLwgzez3ENxAoAwE13whRSAwDCZ8IEUgvgiGaIBhBDqCFaQHTAC60Dsb0GjxZQQoghLQCgvIBlW8OjAUgQYogWIJrgpdgaDaAWkYVoAdrQLmro+vG4PY1D10d3V/9OAGkFmPypaa3X2jcfoq71BRgiExJtgGCLAAAAAElFTkSuQmCC',
    bookF1: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANsAAACPCAYAAABznK6hAAAAAXNSR0IArs4c6QAABSxJREFUeJzt3D9vE3cYwPEnCPZsWYqCJ6BkqvoCYKmQUvUdILHBABNL1VfA0okMZYvE3gEJqRsZOjK6hUxORJZs3hncobnofDnb5z/3nMGfzxJwYvuX/PL1c74kjgAAAAAAAAAAYLNtNfy4UcvrYLZpe2V/ujezpSaxjY4OXsROr7eaJbGQu/vPYsJ+jT6+O8hfEJfOB4O4/+z3mNXTrNiuhLZ9a3dFS2Qew5PTuuBGH98d2JOODE9OL//dJLiphyZ1oZXvgHZVI6oEVxua/clT7WFWcJNimxha3VvaUf36Fht7d/9ZFIeO1ffbj/ZM+v5vGty1mtscHR28GLugLiyPoO2bdCTx28MHVy4TWo7yfkwaOBf9XDlpdb3uBnd6vTgfDGbeEWyS4nt+eHI6ddhMOplYN9lm3pnnbmyq8iSbd+BUY5v68xqTbT389PMPXS9hY835VGqsp/Jh5Ojt04fx7+fPje4INln5kLLOy/178f3Nm/HLH3+NipMlxWQbvX36MG+lsCEuuhrFRWxjoX06bfobXMAk5Y6K4Maes/3591kHy4JvU7Wny9imPVcDFlPuaq5T/8DiroWpBq0q+jLZIInYIInYIInYIInYIInYIInYIEnj2PzGP1w1TxeNY/PHonDVPF2YbLAEkw2StDLZgOWIDZKIDZKIDZKIDZKIDZKIDZKIDZKIDZKIDZKIDZKIDZKIDZKIDZKIDZKIDZKIDZKIDZKIDZKIDZKIDZKIDZKIDZJ4kVZYghdphSRefhySmGyQxMuPwxoSGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyQRGyRpHNv2rd12VwJfoXm6aBzb8OR00fXAN2ueLkw2WILJBklamWzAcsQGScQGScQGScQGScQGScQGScQGScQGScQGScQGScQGScQGScQGScQGScQGScQGSa53vQDqLfKX8cV1vITFemo82c4Hg3ZXQkQlsnmjKX+8l7HIMU8XDiPXzPat3ctQ5g2mfD3Tbf00ju32g/tx/P6o3dVsuOHJ6dih4CKTrbhO+bZox/H7o7j94H7jj28UW7Fpgmtf9VCwaXDliVi9HVavHFrTB7XGJ0iKjS8Ht9PrLbpWJljmULDuENR0W63iOdq8ocW8ZyPLwbGeTLR2LXMSamZs54PB2ATzSJmvSUD2pVvVTurMfM620+s57d+xakjVTRVat5qEFtMmWxHZTq+3UHDlO19lrNVP6mt9IKjbnEmfy06vNxZUeXOLy6ddt+n9rLs2936Z79fiurOi24qI0cv9exER8el0KyIi+sMv8eb180Y3QPtm7YE96l55Dx49eRV72zciIuLO7igiIn5990/9ZNvbvhGPnryKN6+fT51qbT3StDUVs61iqpSPLKa9XfS2l11f19o+0ml6+3WhVdVOtkJ5wtGNuqnV9DJy1YU2cbLd2R2NBVdMOPIVD3KTpliUAqtebs+6MSm0wvW4mGjFO+qCI19xGB8zzgjXhWbPulcOrehpKyJGj/f2Jn4AMJ+6jg77/SiKugyu0B9+SV0g/1vlVLKH3aju4WG/HxGxVR5fY8HZqG58ODuOx3t7S33997ZvxGG/Hz9+d3ula6OZcmxFaFH5ofbWYb8/qrkuX6kPZ8ddL2EjfTgb++/WlX+wNlb5gGd/18h/5WAtLECj9lMAAAAASUVORK5CYII=',
    bookF2: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANsAAACPCAYAAABznK6hAAAAAXNSR0IArs4c6QAABiFJREFUeJzt3D9vU1cYx/HHiOzeshQ5dwKKp6ovICwVUqq+AyQ2GMLEUvUVsHQiQ9kisXcARerWDB0zmoZMjkUklM07w+1ATnp9fa7vOffP717b38+S4sbOsY+/fq7tOGYAJAZdLwDr6fzkKFX+vIcHh2t/X137K4D2+cIa7o2ka5hfzrynr1OEa7NQ6OTj8oVVdOdvS1Hc+XX0Ob7eLgwaIVPLF1ZfJlvIWvO6CpLYtlA2sJCppQ4rRpW1Zs+jDI/YtkRRYH2YWk0KmWxl199pOkRi22Ahga1zWFWFXv+ycGNjvBvzzVgPLjIC8wudbHVC9CG2DeTuJARWrkpQVW/L0Nikb2DCa9UhS2pm9uXjB7PMnYTA6hvujWx+Obv96jw8OLRcF6WHlCHHnOnp0SvbTZKKy0UTbjbXt18pkbXDd2TgC+96OrX9w9+trKey2JZCYyO7Mb+c+YJLv3z8QGQtK3p7ITa4lYcmvtDUvzmwzXxv2GaCS89PjhYOc9C87CQr+uqUBVcUW2Fovq9oR/72dRv78ODQzk+OzHL7gvY0cUh5x3O56enRq4UTfBvKhGtf0ZHEb08ed7KebTbcGy09oBU90N30s/SiovfVyN0ksevpdOl0XkoGvlk1bIpeTPRNtkIuMJ67AfEDJx/byvfTmGz98NPPP3S9BIQ9lVroKXsYmb5/8cT+/fy58JwEBnzje/k/6/XBI/v+3j375Y+/UvdiiZts6fsXT3QrBbbETVep3cS2ENqnGR8EAOrKduSCW3jO9uc/Vx0sC9hM+Z5uY1v1XA1ANdmuol76B1DdHWOqAa1yfTHZABFiA0SIDRAhNkCE2AARYgNEiA0QCY6N3/gHlsV0ERwbHxYFlsV0wWQDamCyASKtTDYA9RAbIEJsgAixASLEBogQGyBCbIAIsQEixAaIEBsgQmyACLEBIsQGiBAbIEJsgAixASLEBogQGyBCbIAIsQEixAaIEBsgQmyACH+kFaiBP9IKiPDnxwERJhsgwp8fB3qI2AARYgNEiA0QITZAhNgAEWIDRIgNECE2QITYABFiA0SIDRAhNkCE2AARYgNEiA0QITZAhNgAEWIDRIgNECE2QITYABFiA0SIDRAhNkCE2AARYgNEiA0QITZAhNgAEWIDRIgNECE2QITYABFiA0SIDRAhNkCE2ACR4NiGe6N2VwKsoZgugmObX86qrgfYWDFdMNmAGphsgEgrkw1APcQGiBAbIEJsgAixASLEBogQGyBCbIAIsQEixAaIEBsgQmyACLEBIne7XgA2X/4347f141rEhkpiPlqSjyv241qbEiexodCqKGICqDvZmlpH14gNt2KiqPNh4iYn2zodohJbT7X5yfiiy657uNeWmMkWet26EBzb9XTaiwVvuvnl7PZ2Hu6NGrnDhz769yWuGFWuW5P345gumGw9kw2sqUO1vk6sNoRMttDr3/RwCY7t/uN9u/j71O4/3m90AfifL5DYMNz3V7lzbbIqk63sdovtISg2d2hDcO3LT7bYO0bVSLdJE5Mt20Ho5QVPtnxwZma7SRJ6dgSqEpoRWStW3ZaxoVnsc7ZscOiPpl5IQZzY27w0tuvpdGGCsal6vArcP/kO8p34lP4i8m6S2PV0Wn91qCy/sflN5QGwWyGh2arJ5iLbTZJKwWV/eJOx5q/Uuj4Q+Dan6LrsJslCUNnNdaevOm/oz+m7Nve+zv3VnbcsuoGZpa8PHpmZ2afZwMzMJvOv9u7ty6ALQPvK9oA96l52D54+f2Pj4Y6ZmT0YpWZm9uvJR/9kGw937OnzN/bu7cuVU62tR5q2pqJaE1Mle2Sx6mvVy667vq61faQTevm+0PK8k83JTjh0wze1Qk+Dli+0wsn2YJQuBOcmHPTcg1zRFLNMYPnT2bNuFIXm3LWbieb+hy846LnDeCt5RdgXGnvWvWxorqeBmaXPxuPCbwAQx9fR8WRirqjb4JzJ/Kt0gfimyanEHnYjv4fHk4mZ2SA7vhaCY6O6cXZ1Yc/G41q3/3i4Y8eTif343f1G14Yw2dhcaJZ7U3twPJmknvNiTZ1dXXS9hK10drXwz8HSf6A3mnzAY3975D/fQerGvAbk4AAAAABJRU5ErkJggg==',
    bookF3: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANsAAACPCAYAAABznK6hAAAAAXNSR0IArs4c6QAABi1JREFUeJzt3D9v20YYgPFXgb1r09JA5uS40VT0A9hLYcBFv0GAbMngTFmKfIIsmaKh2Qxk75DCQLd66OhRqeNJFmIg8KY9AztYZ5xOR/Ioku9R4vNb3MqRdBL58NU/SwSAil7sBSCOq/NxWvdlHpycsj/l4M7pEDuw/t6w9suf38y8pxPhPe6EDjCR2YFlhVFFVsD2dXU5vM7e8C5wI7N3es3JVhR5VwLsxI3soqvzcepG1kRgIYoiL5qy2xLjVtwILDOhxY7MxxdW0fryYtykEDdmoQhjh9amyPIUTba827FJIbZqMahmE0MLkRfUuiGWUVe0O3VcCOLb1tCkQlBtux9CY6v9DVCUlnl03ebQijQ92RaXH7L/F06/kPGYXoxfyyBJghaHZhycnErG9kq/ff6rk6HVydx/9k9ZxFYU7d10Koen76Sop6LYVkJjg8Yxv5n5gkuvzsfS1alWJ9/bE0X3qX2ekODyYvOG1sQnD+DnbmgnOEJrgLt/5+3z7u+KgsuKLTM03080w71/zYY9ODmVq/OxiLNdUE3R/p31+9DgHnmuM70Yv146IeuK0ayso+qb46Mo69l2Ifu3+3DTd6Bb9LPyoor31chBksjddFp4RcA28n2W1D09b9hkvZjom2yFi+C5G7rKnmRlB44bW+77CUy2dvjl159iL6GzSj6VWurJfhiZfnp5LP99/Rp0RUCXZT3UNN6ePJUfHz+W3/74OzUvlpjJln56eay3UqAjFl2lsohtKbQvMz6bDFRld2SCW3rO9ue/txGWBWwnt6eH2PKeqwFYj91VqZf+AazvkTDVgEaZvphsgBJiA5QQG6CE2AAlxAYoITZACbEBSoJj4xP/wKoyXQTHxh+LAqvKdMFkAypgsgFKGplsAKohNkAJsQFKiA1QQmyAEmIDlBAboITYACXEBighNkAJsQFKiA1QQmyAEmIDlBAboITYACXEBighNkAJsQFKiA1QQmyAEmIDlBAboIQvaQUq4EtaASV8/TighMkGKOHrx4EWIjZACbEBSogNUEJsgBJiA5QQG6CE2AAlxAYoITZACbEBSogNUEJsgBJiA5QQG6CE2AAlxAYoITZACbEBSogNUEJsgBJiA5QQG6CE2AAlxAYoITZACbEBSogNUEJsgBJiA5QQG6CE2AAlxAYoITZACbEBSogNUEJsgBJiA5QEx9bfGza7EmADlekiOLb5zWzd9QBbq0wXTDagAiYboKSRyQagGmIDlBAboITYACXEBighNkAJsQFKiA1QQmyAEmIDlBAboITYACXEBighNkDJTuwFII46/2SKv3UMQ2wdYgdWZyBF4RLjPWLrABODvdNrTramIt80xNZSdcUwv5k97OBN/bV9mcmW9W+7EGFwbHfTaSfukNjsOPp7w7UDsadZ7K+0CJlseWts835XpgsmW8vYcawTifuQMXZornUmm3ueNseXJzi2/aNDuf7nQvaPDptdUYf5JkBoLG2PrEiZydaW+Mr2EBSbeWhDcM1zJ1vojrSpkYUoiivGbbY7CL3+4MnmBiciMkiSddeKDOuGto2RZdGebPb13U2nIotHer615Cn1nM0ODmiLJg80/b3hUsxV3j4pjO1uOl2aYF06grbFpr4gsA1C93e3E5/Cz0YOkuRhdCIOd4O7G5UDYFwhoUneZDORDZJkreDsK68zVvdGbeqBwLdxsm7LIElWnjeY85vT884bej1t1+S2r7K/mvMWRdcTkfTtyVMREfky64mIyGT+XT5+eBV0AWhe0TZgG8Vnb4NnL97LqL8rIiJPhqmIiPx+/tk/2Ub9XXn24r18/PAqd6o1daRpaipqq2Oq2I8s8n6ue9lV1xdb0490Qi/fF5rLO9kMe8IhDt/UCj0NunyhZU62J8N0KTgz4aDPHOSypphYgbmns83iyArN2JHFRDO/8AUHfeZhvBS8IuwLjW0Wnx2a6aknIunz0SjzHwAox9fR2WQipqiH4IzJ/LvqAnGvzqnENozD3YZnk4mISM8eX0vBsaHiuLy9luejUaX7f9TflbPJRH7+Yb/WtSGMHZsJTZw3tXtnk0nqOS821OXtdewldNLl7dL/9lb+A61R5wGP7dsi/wPSswA1t6aT6AAAAABJRU5ErkJggg==',
    bookF4: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANsAAACPCAYAAABznK6hAAAAAXNSR0IArs4c6QAABeRJREFUeJzt3LFu21YYhuFfgb1r85JA1uSk0dgLcLYABnoHAbIlgzNl6SVk6RQPzWYge4cUBrrVQ0ePSh1PshEDhTfvGdghonN0fCgeijwfSel9FjeuJNIkX/6UZMsMgMSg7RXA6s5PjrLUy3hycMgx0hA2ZA/lkQ13R8mXdXt5Ffw+EVbHBusRP7KiEJpUFLS/bOIrxwbqifOTo8yPrM3J5i+b+MqxQXriv89/ZsrIyvhxlcVnBEhsfZHH1oXQQsriC91m0+LbansFsB5iJpt/m6JXU9c1QmJDEjGTrWhK5xGuW3TEBpmY6efebt0mX2xsyd88xeYpe1uhbPKt6snBYZ27Fyk9AcTElp0evbWd8biZVQJKlL2PWPdFovOTo1r3993MZrZ/+FtWFlxZjfdC6+qrYZugy69GKtV5M7/J7eeuxzw4W9bUstiCoSl+awHfhZ7jEFucfFu5X63hY9h/rLLgimIrDC30FWn425ftHc+NwL0srbP9io7/2OAeBB4zOz16u/CNUFhMuPS4kljdcHe0EFlT29GPOBTwvJ97L+KEYit8McRdafeHAbrIDaGJYzU24KJ+grEtW5hxxkVPpLgSqxOwH9vS9y9C18FA1zV5FVYx4IWe3PfZsk+vn9u/X79GLQjYZGXvBb47eGo/PXpkv/z+1937b/lkyz69fq5bU2BDzLvKbB7bQmhfrnr5a2dAp7gd5cEtPGf745/rFlYLWE9+T3exLXuuBmA1bleVXvoHsLoHxlQDksr7YrIBIsQGiBAbIEJsgAixASLEBogQGyASHRu/8Q/cV6WL6Nj4Y1HgvipdMNmAGphsgEiSyQagHmIDRIgNECE2QITYABFiA0SIDRAhNkCE2AARYgNEiA0QITZAhNgAEWIDRIgNECE2QITYABFiA0SIDRAhNkCE2AARYgNEiA0Q4UNagRr4kFZAhI8fB0SYbIAIHz8OdBCxASLEBogQGyBCbIAIsQEixAaIEBsgQmyACLEBIsQGiBAbIEJsgAixASLEBogQGyBCbIAIsQEixAaIEBsgQmyACLEBIsQGiBAbIEJsgAixASLEBogQGyBCbIAIsQEixAaIEBsgQmyACLEBIsQGiBAbIEJsgAixASLRsQ13R2nXBOihKl1Ex3Z7ebXq+gBrq0oXTDagBiYbIJJksgGoh9gAEWIDRIgNECE2QITYABFiA0SIDRAhNkCE2AARYgNEiA0QITZAhNgAEWIDRLbaXgE0p+m/OeQPhptFbGsgj6zpOJbFS4jVEVtHxUwpPzLlZPOXRXzlomO7mc3YoAK3l1d323m4OwoGlDoyfzkh/rFQdNt1P2aqdMFk6xg3sKLQUkcWI3aycSn6Q3Rse8/27eLvU9t7tp92jTaYe2AWBVU07dq2ymTr+6Vo1R6iYsvPpgSXnj/Z3AOwq6EtU/dStKsBuh3E7pPoyeYHZ2a2Mx6vuq4oUBSareHHCcZMthQ/c53HvJnNzOZXelUfq9JzNjc4oGmKk0noJFaFe9+q61sa281stjDB1u3s2gddvZTqqxTHsN9JSOmva+2Mx3ejE+3gBNdtMaHZssmWR7YzHq8UnLvwJmP1f6i+nghCO6foZ9kZjxeCC+3cZfeNXU7Xpdz3dY7X/L5l0Q3MLHt38NTMzL5cDczMbHr7zT5+eBP1AEivbB+wj9rn7oMXr97bZLhtZmaPR5mZmf168jk82SbDbXvx6r19/PBm6VRLdaZJNRXVmpgq7pXFsq+rPnbd9Wtb6iudqlcQbmi+4GTLuRMO7Si6ZIz5HrRCoRVOtsejbCG4fMJBLz/JFU0xcwLzv88+a0dRaLktm0+0/H+EgoNefhlvJa8Ih0Jjn7XPDS3vaWBm2cvJpPAGAKoJdXQ8nVpe1F1wuentN+kK4rsmpxL7sB3+PjyeTs3MBu74WgiOHdWOs+sLezmZ1Nr+k+G2HU+n9vPDvUbXDXHc2PLQzHtTe3A8nWaB+6Knzq4v2l6FjXR2vfDPwb3/QGc0ecJj/3bI/5eNxR5yYHm1AAAAAElFTkSuQmCC',
    bookF5: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANsAAACPCAYAAABznK6hAAAAAXNSR0IArs4c6QAABn1JREFUeJzt3bFvE1ccwPGfEdmzWUhF4Sag8VT1DyBLhZTS/wCJDQaYWKr+BSyd8FC2SOwdkCx1I0NHRrchk4nIki07w3VoXvR8fnf37nz3ey/vfT8SCjjYPnL+3u98PhsRAComoRcglJPFvKxe9vDwZbY/D4zvdugF0GYi2723N9htbYPA85HNiq5GdvnlbO37u/f25M7+E++fx8liXg4RrFkOoktfFpPNDsM8uO1QquG13Za5fpfr1THLYU9JwktT8rGZ0FyRNV2n7nt2tENONvu2ThbzkuDSk+wKrU6gpjDM9+smlWsKDhFadRns+7v8csaES0yyK9OeaD5htAVnDB1Z27IQXDpuhV6AsQ0Rx+69vetfGuyNxBBHPBGH5GO7qQguPb4HSFjZAXTYDWb9hNe6u+8TW3k8fy3TohhmkdBLwxHK8mQxD7BEMC5WK3n08veyLbi2GjdC03resq0uh+a7HI0MwSzfnf0nUlln5cliHnz5cmU/Xq6Ck6ammiabM7QhXshFPyeLuTw8fGm2oM7QWD967B6mRSHH89eNE64uttrQXF9jlOqDzgTn2nWMeX2koO7x7xuc62hkeTx/vXaBK6xUH8w3wW+PDzYuIzQdrpMPqj/3q342Dlo5J9u0KORitWq9IyAn9ql6TcOm7mBip9fZzJ3x3A25sidZ14FTja3x9RomWxx++vmH0IuQrY5PpdZ6sncjyw8vHsu/X7963RGQs7r3RRpvDvfl+7t35Zc//ro+WGImW/nhxWO9JQUycdVVKVexrYX2+YyTzIFt2R2Z4Naes/3593mAxQLSVO3pOram52oA+rG74i02gJJbwlQDRmX6YrIBSogNUEJsLXghH0MhNkAJsQFKiA1QQmyAEu/YOFAAbOrShXdsvFkU2NSlCyYbsAUmG6BklMkGYDvEBighNkAJsQFKiK0BR2AxJGIDlBAboITYACXEBighNkAJsQFKiA1QQmyAEmIDlBAboCT72Mx/28r79TC27GMDtBAboITYACXEVoO312BoxAYoITZASbKxsRuI2PAhrcAW+JBWQAkfPw4oYbIBSvj4cSBCxAYoITZACbEBSogNUEJsgBJic+A1RYyB2AAlxAYoyTo2PuwHmrKODdBEbIASYgOUEBughNgAJcQGKCE2QAmxAUqIDVBCbIASYqvgjH+MhdgAJcQGKCE2QAmxAUqIDVBCbIASYgOUEBugJNvY+PwRaMs2NkAbsQFKiA1QQmyAEmKzcMY/xkRsgBJiA5QQG6DEOzaezwCbunThHRtnWgCbunSR5WRjw4GhMNkamHMiU9p4IJwuXdwedUkiw8nHCCmbo5GEhtCyiI3QEIMsYiM0xCCL2AgNMUg+NkJDLJKOjdAQk2RjIzTEJtnYgNgQG6AkqzNI+hhrd5TTxfJDbBZXWGNFYe6L6PJBbBbXA3/syWbObkH6ko2tz1kjmkcw7clGcHlI+gAJD2DEJNnJZti7azFynSTNRiJNycdm1D2AY4iwuhvJbmWakt6N9BHLg/ryy9n1r77vUjDXR5y8Y7tYrcZdkoBiCc7oG1x1OmJ8XbrIfrIZsQXXhwmM3dA4ecd2/+CRnH48HndpcK3PdLM/yIhdyvGdfjyW+wePvP++V2xmpaUeXIzTwHeZOKKpyw7Nd6PmfTTSbGnt4KZF0XdZ4aHrKV12cNWvGIZ5jtY1NOl66N8ODuPr8xyMiTaubQ5CtcZ2sVqtTTC2lPp8AmK9hFXtxKX1Odu0KJI+7H8TVEOqrlRCC8snNGmabCayaVH0Cs6+8yFjrf6jbuqGwLVy6v4t06JYC8peuebypuv63k/sxlz32zxezXXbopuISPnmcF9ERD6fTUREZHn5Td6/e+V1Axhf2zpgHYVnr4Onz9/KbHdHREQe7JUiIvLr4h/3ZJvt7sjT52/l/btXjVNtrC3NWFNR2xBTxd6zaPra97a3Xb7Qxt7T8b19V2hVzslm2BMOYbimlu9l0OUKrXayPdgr14IzEw76zEauboqJFVj1ctZZGHWhGbflaqKZb7iCgz6zGy8tR4RdobHOwrNDMz1NRKR8NpvV/gUA3bg6OlouxRR1HZyxvPymuoD435BTiXUYRnUdHi2XIiITe3ytBceKCuPT+ak8m822+vnPdnfkaLmUH7+7P+iywY8dmwlNKi9qT46Wy9JxXdxQn85PQy9Clj6dr/1xsvEbRGPIDR7rNyL/AUU8IbQ0hCCVAAAAAElFTkSuQmCC',
    bookF6: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANsAAACPCAYAAABznK6hAAAAAXNSR0IArs4c6QAABk1JREFUeJzt3D1v20YYwPFHgb1r09JA5uS8aCr6AeylMOCi3yBAtmRwpixFP0GWTvHQbAaydwhgoFs8dPSo1vEkC/HiTXsGdohOOJ2O5PHtOYr6/4AiqWpJtM5/PiSleiDKbi7P06r3fXp6Nmh2awA9ezGedHgwrnS/KqESKLoiSmwiIou7een7VIm0KFBihJZosRnDg7Es7uZrf2ZpI9CsGIkQTYsamx1CSEhVJlvR42Y9JhGiaVFjs0Ooeh5XpOhxs2IsEyEBIkT0yRZ6CNnmNviUiZDzQoTo/WSrqkyEnBciRPTJtm1829zUeSHx9Vv0q5F90NR5oR0f4fVPaGyVP/WB8ENS++tMeE9Pz8xNefGxPvEV7hxDYkuvzt/KKEma2SSsuBH6zmFvLs9FvkeXZixoar4GcTzMZnJ09kfW+qwU1bgRWt3zrNhXH7eFCc+8Rou7uZly9pqlN5fnvI6R2DvHZXCS11TuoYkvtCqf4nARW5iC4LyhNbE+COP2UBRcVmyZodV9b4zJVo79OpmFfXp6tjq8dD+Fw2vanqyf/9DgHnkeM706f7t2gy8O9qDx/H5yvHEboelwz6t9r/uyn42LVt4LJKMkkYfZrPCJgF1iH2HkDZusi4m+yVb4ZE2duwHbxp5kZQeOG1vu+zVMtm74+ZcfY2/Czip5KrXWk30YmX56fSL/ff0a9ETALnMvWrnenT6XZ48fy69//r16/81MtvTT6xO9LQV2xLKrVJaxrYX2Zc5H8oC67I5McGvnbH/9cx9hs4B+cntaxZZ3rgagGrurUpf+AVT3SJhqQKtMX0w2QAmxAUqIDVBCbIASYgOUEBughNgAJcGx8Yl/YFOZLoJj438WBTaV6YLJBtTAZAOUtDLZANRDbIASYgOUEBughNgAJcQGKCE2QAmxAUqIDVBCbIASYgOUEBughNgAJcQGKCE2QAmxAUqIDVBCbIASYgOUEBughNgAJcQGKCE2QAm/pBWogV/SCijh148DSphsgBJ+/TjQQcQGKCE2QAmxAUqIDVBCbIASYgOUEBughNgAJcQGKCE2QAmxAUqIDVBCbIASYgOUEBughNgAJcQGKCE2QAmxAUqIDVBCbIASYgOUEBughNgAJcQGKCE2QAmxAUqIDVBCbIASYgOUEBughNgAJcQGKCE2QAmxAUqIDVBCbICS4NiGB+N2twTYQmW6CI5tcTevuj1Ab5XpgskG1MBkA5S0MtkA1ENsgBJiA5QQG6CE2AAlxAYoITZACbEBSogNUEJsgJKosfERMOySvVhPbD7AaYLjg87oO/XYhgfjtYlmR0dw6LMok82Oyp5sTDn0WbTDSMM32Zhy6KPosRnuZHMvnrQZX8iFGuJHXZ2JTQrO39q8chkSUpXnrxMoV2r7p1Ox2fow2XwXgkLuY77WN+FDno8p3E3BsT3MZmqL6L4t4P49hrqTLTQ8O7Cyz+nel+jaV6aLzk42qbBn75qswLImUNZbImWfj9C6KfgTJIfHR3L7+ardremxxd189c/wYLzakeQdLleZbHak27yj2ga3n6/k8Pgo+OuDYjOLFiO4Pu6h86KrOp2yPiyAdtihhe7Ugg8jzeLbwY2SpOq2IuCCRt1ztiqPgXwPs5nIcvBIyde31DmbHVwMff3BafL7YqK1q85hfmFsD7PZ2gTr6w/8tmNd4nI78Sk8ZxslyWp0Ig43JHdRCS2ukNAkb7KZyEZJUik4+8mbjNX9prZ1R+BbnKzvZZQka0HZi2tuz7tv6PN0XZtrX+fn1dy3KLqBiKTvTp+LiMiX+UBERKaLb/Lxw5ugB0D7itaANYrPXoMXr97LZLgvIiJPxqmIiPx2+a9/sk2G+/Li1Xv5+OFN7lRra0/T1lTU1sRUsY8s8v6s+th1ty+2to90Qh/fF5rLO9kMe8IhDt/UCr0NunyhZU62J+N0LTgz4aDP7OSypphYgbm3s2ZxZIVm7Mlyopn/4AsO+sxhvBRcEfaFxprFZ4dmehqISPpyMsn8AgDl+Dq6mE7FFLUKzpguvqluIL5rciqxhnG4a3gxnYqIDOzxtRYcCxXH9f2tvJxMar3+k+G+XEyn8tMPh41uG8LYsZnQxHlTe3Axnaae+2JLXd/fxt6EnXR9v/avg42/oDOa3OGxvh3yPzfMGguHTNiYAAAAAElFTkSuQmCC',
    bookF7: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANsAAACPCAYAAABznK6hAAAAAXNSR0IArs4c6QAABkFJREFUeJzt3DFvE2ccx/G/Udi9RZWKEk8hjaeqLwCWCilt3wESGwxhYqn6Clg6kaFskdg7UEXqVoaOjKYhk2MRCWXzznAdyGM9fvzc3XM+3+/O9vezACa2L37u6/8TO4kZAIle2wdQ18X5aaa8v8Pjk7V/zNCOtTlx8qLq7+9Jj2N6NVm4jACRorMnSRhXXlSxk79JseMIj4H4ENPKSZGy9QtP6ryoujDZUo6VACE7AfzAUgIJT1h1VFWkHKv/MYS3nVa66EUTyz8BU7Z+XY6rTNn0I7ztVHmhU4MK+SfYOoe0rLzPn/C2R6XFvTg/zVKDCm1jYHnKwiO6zbSzzJW68mLFusqbbDx+my01ttz3uKZXk9mfqC4W3ucPf2VmZt8c/ex/aNG0k76xj6jS3UhKbNm70xe2OxjMXVj1BQ+Uc4+pF93s34fHJ1nOgmYX56fS48S8m/HYHpz8nrc+M2U1LoQWm2Jsf5rhHmf3mB8en1iwZtnF+SmPf0v8Dm6Ds6KmCrcmsdDcnYRbSBa8Gf5jGwQXDY1dhk44eMqCy4std6KFd0BkzQpjs6+vVprbOobbedajOXlDJjW4O5HbzN6dvpi7IDa9+vt7LGxLfnv0cOEyQtMIB03scb/tZ+FFq1hsCy+GxO4I2Db+gJleTXJ7yOsnGlvRnQHbzJ9kVXsIYyt8v4bJ1g0//vR924ewtSq+5TXXk/8+W/b22SP779OnpDsCtln4olXo5fGRfXfvnv3yx9+z99/cZMvePnukO1JgS9x2ldltbHOhfZzwPbBAXX5HLri5r9n+/Pe6hcMCNlPY0yy2oq/VACzH76rSS/8AlnfHmGpAo1xfTDZAhNgAEWIDRIgNECE2QITYABFiA0SSY+M7/oFFVbpIjo2fZQMWVemCyQbUwGQDRBqZbADqITZAhNgAEWIDRIgNECE2QITYABFiA0SIDRAhNkCE2AARYgNEiA0QITZAhNgAEWIDRIgNECE2QITYABFiA0SIDRAhNkCE2AARfkkrUAO/pBUQ4dePAyJMNkCEXz8OdBCxASLEBogQGyBCbIAIsQEixAaIEBsgQmyACLEBIsQGiBAbIEJsgAixASLEBogQGyBCbIAIsQEixAaIEBsgQmyACLEBIsQGiBAbIEJsgAixASLEBogQGyBCbIAIsQEixAaIEBsgQmyACLEBIsQGiBAbIEJsgAixASLJsfX395o9EmANVekiObbp1WTZ4wE2VpUumGxADUw2QKSRyQagHmIDRIgNECE2QITYABFiA0SIDRAhNkCE2AARYgNEiA0QITZAhNgAkZ22D6AN4Xdq8+NDUNiI2Kr++E8YV5XrEyaWtTaxFQVRNYA6k22Vx4Ht0tnYqgRR9wdbVzXZ2J6iSOux5Z3odbZ6Taoy2VI/t1Vx90fk3ZQc2814vLJF9E/CvNvsSlxVpE62piZgf39vdtvTqwnRCVTpYqWTLTUQ/+DWMapUy0ztOoEQWrclx3bw8IFd/vPODh4+MMs5kVIXeJMDS1E02epsBd11plcTtpQCfg8pkmJzz5Tuhjdp69cFscm2zNsZ/kTzt5RYvbLBE5M82dxCsoDNCidS1VdK/a1k1euj3M14bHa707OKj2+lr9lYOJ1lt4FsG5tV5/WG0thuxmPbHQyWOzLUlvpiB0+E7UrppPQbkXcHg9noRDvCkMJFJbR2pQ6k3MnmItsdDJYKzr/zVcYaflLr+kQQW5y8z2V3MJgLyl9cd3nRdVPvp+uaXPs656u7bll0PTPLXh4fmZnZx0nPzMxG0y/25vXzpBtA88rWgDVqn78Gj5++smH/rpmZ3d/LzMzs1/MP8ck27N+1x09f2ZvXzwunWlPPNE1NRbVVTBV/Z1H057K3Xff42tb0Tif19mOhhaKTzfEnHNoRm1qpl0ErFlruZLu/l80F5yYc9NyTXN4UMy+w8HLWrB15oTk7djvR3H/EgoOe28ZbySvCsdBYs/b5obmeemaWPRkOcz8AQDWxjs5GI3NFzYJzRtMv0gPEV6ucSqxhO8I1PBuNzMx6/viaC46Fasf760t7MhzWevyH/bt2NhrZD98erPTYkMaPzYVmwZvavbPRKItcF2vq/fVl24ewld5fz/2zt/AXdMYqn/BY3w75H2jt68IUHQECAAAAAElFTkSuQmCC',
    bookPage1: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANsAAACeCAYAAAC7Fn+fAAAAAXNSR0IArs4c6QAABTlJREFUeJzt3D9vE3cYwPEnCPZsWYqCJ6BkqvoCYKmQUvUdILHBABNL1VfA0okMZYvE3gEJqRsZOjK6hUxORJZs3hncobnofDnb5z/3nMGfzxJwYvuX/PL1c74kjgAAAAAAAAAAAAAAAAAAAAAAAAAAANhgWw0/btTyOpht2l7Zn+7NbKlJbKOjgxex0+utZkks5O7+s5iwX6OP7w7yF8Sl88Eg7j/7PWb1NCu2K6Ft39pd0RKZx/DktC640cd3B/akI8OT08t/Nwlu6qFJXWjlO6Bd1YgqwdWGZn/yVHuYFdyk2CaGVveWdlS/vsXG3t1/FsWhY/X99qM9k77/mwZ3reY2R0cHL8YuqAvLI2j7Jh1J/PbwwZXLhJajvB+TBs5FP1dOWl2vu8GdXi/OB4OZdwSbpPieH56cTh02k04m1k22mXfmuRubqjzJ5h041dim/rzGZFsPP/38Q9dL2FhzPpUa66l8GDl6+/Rh/Pv5c6M7gk1WPqSs83L/Xnx/82b88sdfo+JkSTHZRm+fPsxbKWyIi65GcRHbWGifTpv+BhcwSbmjIrix52x//n3WwbLg21Tt6TK2ac/VgMWUu5rr1D+wuGthqkGrir5MNkgiNkgiNkgiNkgiNkgiNkgiNkjSODa/8Q9XzdNF49j8sShcNU8XJhsswWSDJK1MNmA5YoMkYoMkYoMkYoMkYoMkYoMkYoMkYoMkYoMkYoMkYoMkYoMkYoMkYoMkYoMkYoMkYoMkYoMkYoMkYoMkYoMkYoMkXqQVluBFWiGJlx+HJCYbJPHy47CGxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJxAZJGse2fWu33ZXAV2ieLhrHNjw5XXQ98M2apwuTDZZgskGSViYbsByxQRKxQRKxQRKxQRKxQRKxQRKxQRKxQRKxQRKxQRKxQRKxQRKxQRKxQRKxQRKxQZLrXS+Aeov8ZXxxHS9hsZ4aT7bzwaDdlRBRiWzeaMof72UscszThcPINbN9a/cylHmDKV/PdFs/jWO7/eB+HL8/anc1G254cjp2KLjIZCuuU74t2nH8/ihuP7jf+OMbxVZsmuDaVz0UbBpceSJWb4fVK4fW9EGt8QmSYuPLwe30eouulQmWORSsOwQ13VareI42b2gx79nIcnCsJxOtXcuchJoZ2/lgMDbBPFLmaxKQfelWtZM6M5+z7fR6Tvt3rBpSdVOF1q0mocW0yVZEttPrLRRc+c5XGWv1k/paHwjqNmfS57LT640FVd7c4vJp1216P+uuzb1f5vu1uO6s6LYiYvRy/15ERHw63YqIiP7wS7x5/bzRDdC+WXtgj7pX3oNHT17F3vaNiIi4szuKiIhf3/1TP9n2tm/Eoyev4s3r51OnWluPNG1NxWyrmCrlI4tpbxe97WXX17W2j3Sa3n5daFW1k61QnnB0o25qNb2MXHWhTZxsd3ZHY8EVE458xYPcpCkWpcCql9uzbkwKrXA9LiZa8Y664MhXHMbHjDPCdaHZs+6VQyt62oqI0eO9vYkfAMynrqPDfj+Koi6DK/SHX1IXyP9WOZXsYTeqe3jY70dEbJXH11hwNqobH86O4/He3lJf/73tG3HY78eP391e6dpophxbEVpUfqi9ddjvj2quy1fqw9lx10vYSB/Oxv67deUfrI1VPuDZ3zXyHxjSLSxj9cjkAAAAAElFTkSuQmCC',
    bookPage2: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANsAAACeCAYAAAC7Fn+fAAAAAXNSR0IArs4c6QAABw1JREFUeJzt3bFuG0cQgOGxYffqhAABZFZJYJUpUqZLYeQdUrpw58J5hLhIp8JlHiCd4SKdH8BNAAmOK4mAAcMdewdgCmuY8/KOt3fcnZ3b/T/AEEFR1N1qf+3xSNEieW1v/wHeZZ+rd3PeuYjI64unQnRwbCsi29t5mtW97N/h/+Dkxye/a3B3LL4vcMBWOnPTQurYuqvXXlBEBwdiIjs4j+dKvrL99uihiIj8+upq8LCR6FBA7Eq27czhpBuQ7TGbbvAhry+eyoerl8JjOmS0FZHth6uXUYeMMfN2rqyP2WI3/DY4+erhz6x0SGUrnbkVI2dokjO2f9afe/kh4rabm7WcPDgjOqSwF5nOrzE6Z789y3OQZXI2MsbmZi0iQnSYqzcyT9zEdvLgTDY3a6LDVAcj03nlgZvYJBgYosOI0ZUs5tDRkpvYwt9G4fVEh1uDkYXzxsuKptzEpqta96N0BpDomhcVmXROiHQ/euAmtqGVLbyO6JoTHZnqOzLywE1sscfXRNeMyZGFwrlSmpvYpiK6ah0dmVeLjU0RXTWqjUwtPjZFdItVfWSqmtgU0S1GM5Gp6mJTROdWc5GpamNTROdGs5Gp6mNTRFdM85GpZmJTRGeGyALNxaaILhsiG9BsbIrokiGyEc3HpohuNiKLRGwBootGZBMR2wCiG0RkMxHbCKLbIbIjEVukhqMjskSIbaKGoiOyxIhtpoqjI7JMiO1IFUVHZJkRWyILjo7IjBBbYguKjsiMEVsmjqMjskKILTNH0RFZYcRmpGB0ROYEsRkzjI7InCG2QjJGR2ROEVthEdFNCW5LZH4RmxND0UWucl+sZkTmE7E5E0Y3cmhJZAtCbE51o9NVbnOzlu8ePdn9h89vX13s3Q5+EdvCvH11IR+vr+V0tSq9KZjobukNAFpBbIARYgOMEBtghNgAI8QGGCE2wAixAUaIDTBCbIARYgOMEBtghNgAI8QGGCE2wAixAUaIDTBCbIARYgOMEBtghNgAI8QGGCE2wAixAUaIDTBCbIARYgOMEBtghNgAI8QGGCE2wAixAUaIDTBCbIARYgOMEBtghNgAI8QGGCE2wAixAUaIDTBCbIARYgOMEBtghNgAI8QGGCE2wAixAUaIDTBCbIARYgOMEBtghNgAI8QGGCE2wAixAUaIDTBCbIARYgOMEBtghNgAI8QGGLlXegNERE4enMnmZr27DKTgbU4Vjy0cEG8DhOUZmlOlFY3tdLXaXSY6HGssstPVSj5eXxfZNikZWze0LqLDVFNWspLBmcemkekOEx3mmnq4GM456+iyx/bHi7/kl8c/7V1PdJjr2MhCp6uVPH/2Ivl2hpLH9uff/+4un5/cF7kNTkTk2fPHeztOdIiVKrLu9WFkl5tPcrlJutk7WVe2y80nkU50umPPnj/euy3RYYjFSqZzNac7Ge5zKyLy/dff7H1Co1N9K50aGzBVe3Sbm/XePn68vt6NS/dzNe67GKxkoTfv3+nFpH3kiE0RXQItxlZbZFnvNJAsurHgpMLoWoptzpPRffPCW2Qmdx5IEl2sWqJrIbZUr/jwGpmyfJ7tjnzewb3oDp1ImRsdJ1L8ayUyVeIVJETXuNYiUyVfG0l0jWk1MlX8Vf9EV7/WI1MeYlNJo+PJ8fJqPYU/l6uNCUw6ezlk6c/TLfFsZOpXfEjnF6xaUmTK5UYFmo5uSbER2WGuNy4wObpDT3jKyA/ZS3RLiG1KZIfGv7tfNUWmFrGRgWRPjsf8Zi0dnefY5kQ29nOoMTK1qI0NNBGdx9iIbJ5FbnRgVnQy80XP1tF5ii1FZOH4txCZWvTGB3qjC4OT4DGdOI/OQ2wpIxt6TCY9odUSmapiJwJVRVcyNiJLq6qdCVQRXYnYiCyPKncqMCs6LydSLGNLeeKDyPZVvXOBydENsYzOIrZUkXUR2b4mdjKwqOhyxkZktpra2cCs6GLfniE0NbruxI+NLbz92H0f8yr8cByIbFyTOx1IdiIlxlh0ukKFHyVyZev7uu59923DFJz4mK/pnQ+4OXsZRjB1ZRu6P84ulsUg7CsaXd/1Ux+zjcXah8jy8/THo170/hFr+Aes0vMOz3PeWj3VXzH3ITJfGJRxxVe6uSdIiMwXBideseiOPYyM+d5Elh+DNF2R6GQkNiEy9xis+UyjC28/5bYx35PI8mPQjmceXUxsROYPg5eOWXSHYiMyvxjE9LJHN/Y/txy6nsjKYTDzSR6dfk5jm/IWD0RWHoOaX9LowtiIbDl4BUl+yV6RcgiR+ccg25u90knEYSSR+cVglzP77Rr6DiOJzD8Gvbzo6GIRmU8Mvh9HR0dkvnGCxI+9Eylv3r+T85Pz3ncJDp2f3Jc379/tvq57n/CB2Pz5IrqpbkMjMof4ofg2Jzh+pk79B+nkhy10woauAAAAAElFTkSuQmCC',
    bookPage3: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANsAAACeCAYAAAC7Fn+fAAAAAXNSR0IArs4c6QAABV1JREFUeJzt3T1uG0cYgOFREPfs1ASQVKWIytwhRS6R0n0KXSHqXajMAdwFKdLlAG4MOEhcSQIMBOrU2wDTcJgluSSX5O63M6vnAQTxD8Lsz4tZrpZSSgAAAAAAlGW++OJ/1skBvhp7ADX5883Pyc61NF+sDzoS24EEl5LQjiO2/TYOlV54cG2hOZzsQGwd/PLjdxuPvdDgWme0tvXDJrF11LZD/fvXb+kFBTdfLO8KoXUnthO9kOBaQ+MwYuvon8ezrc9NPLidoe1aL6wS24meHx5Tmm5wy9DycnI8sfVgosEJrWdi68nEghPaAMTWo4kEJ7SBiK0Hs8uL5ffKg1sJrblcnE5sPWjOABUH1xpaMsP1Rmw9mF1erERWYXCtoeXbZrZ+iK1HzZ2youC2zmgi65fYBlRBcFtDo39iG1jBwQktmNgCFBic0EYgtiAFBSe0kYgtUAHBCW1EYgs2YnBCG5nYRjBCcEIrgNhGEhic0AohthEFBCe0gohtZAMGJ7TCiK0AAwQntAKJrRA9Bie0QomtID0EJ7SCia0wJwQntMKJrUBHBCe0CoitUAcEJ7RKiK1gHYITWkXEVrhmcH///iY1gpsv7gutEmKrQFtwQquP2CrRDKr5b5uEVg+xQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxQRCxneD54THNLi/S88Pj2EMZ1EtZzqGJ7URT3xGnvnyRxHak86ur5e2p7pBty9Vcbg4jtiOcX12lp/v7lcemFty25Xm6vxfckcR2gF/v/ljennJwXUNrrg/2E1sHb99/SR+eP6e02MFyZFMMrktoT/f3y9A+PH9Ob99/GWWstRHbAZrBZVMK7tAZLa8PuhHbfmfvPn1c3sk72O3N3aRmuK4z2u3NXUproS3Wz1nsiOsjtm5ag5vKIeUxh46Z0LoTW3eTDE5occR2mE7BrSs1uF3jElr/xHa4vcG1KS24LuMRWr/EdpyqgxPaOMR2vCqDE9p4xHaaqoIT2rjEdrpOwY19lnLXWcfmbaENR2z92BpcNuavBU65MkRo/RFbf7ZeaZLl4JrRDR1c28/PY2iG5sqQ4YmtX52CW5/lhgpuW2h5DJnQYoitf3uvpUwth5V9B7crtOZ9ocWxQocz//6bb5d3rmevUkop/fT6h5R2fOI5BzK7vNh4LofTjGbb63aFmyP3Hi2WmW04W0+atJ0sydZD6TrTNV+/L7TzqyuhjUBsw1oJLru9udsIbtshZf6+LZ783Prr235uDq35HjIT2vDENrxlcM1ZZD24fe/h2g4Xm4/ve4/WFloej9BiiC3GScF1IbTyiS1OLzPcOjNaPcQWq/cZTmj1EFu83oITWl3ENo6jg2sSWl3ENp6jgmsjtDqIbVwnBye0eohtfEcHJ7S62ADlWF5Lma+jTCmlm9vXG1FlQquLma0cnWa4dUKrhw1Rnp0z3Dqh1cPGKFOn4IRWFxukXK3B5c/DpbW/cSK08tkoZWsNbp3Q6mDDlG9ncEKrx9djD4C9zt59+jhPKaXr2fXKmcrr2avU+HCq0Arn1H8d9oUktArYSHWZtzxmG1biPx60yIW0dChzAAAAAElFTkSuQmCC',
    bookPage4: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANsAAACeCAYAAAC7Fn+fAAAAAXNSR0IArs4c6QAAAm1JREFUeJzt3b1Nw1AYQNEEZQA2gBKJURiAVWCCMAIlLQNQMAgSHaSkYwPokIwSEX5y7YhzqsTxsz7JunouLGU2AwAAYKrmYw/AwNuG49vcp9+sJbAYewCGrs5OB98v7h6Steye2CbqcTXYkDbtWmvXnBxtdToxsU3Y8nY5W645/vq8mh0eH61dc3l+ufO5+JmDsQeA/0JsEBEbRMQGEbFBRGwQERtExAYRsUFEbBARG0TEBhGxQURsEBEbRMQGEbFBRGwQERtExAYRsUFEbBARG0TEBhGxQURsEBEbRMQGEbFBRGwQERtExAYRsUFEbBARG0TEBhGxQURsEBEbRMQGEbFBRGwQERtExAYRsUFEbBARG0TEBhGxQURsEBEbRMQGEbFBRGwQERtExAYRsUFEbBARG0TEBhGxQURsEBEbRMQGEbFBRGwQERtExAYRsUFEbBARG0TEBhGxQURsEBEbRMQGEbFBRGwQERtExAYRsUFEbBARG0TEBhGxQURsEBEbRMQGEbFBRGwQERtExAYRsUFEbBARG0TEBhGxQURsEBEbRBZjD8DQ42r+8fn1ebX2nJenp62vwXTY2SAiNoiIDSJig4jYICI2iIgNImKDiNggIjaIiA0iYoOI2CAiNoiIDSJig4jYICI2iIgNImKDiNggIjaIiA0iYoOI2CAiNoiIDSJig4jYICI2iIgNImLbA1/9H9tXvzMNYoOI2CAiNoiIDSJig4jYICI2iIgNImKDiNj2yOc3Rbw5sl/EBhGxQURsE/bdx0SPldO2GHsANru5vh97BP6QnQ0iYoPIfOwBGHjbwTXdY+B/eQcTBjEij4IGSQAAAABJRU5ErkJggg==',
    tbBody: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAAYCAYAAABTE9enAAAAAXNSR0IArs4c6QAAAmdJREFUeJztm7Fr20AUxj8Zda+nLoaQwbhFBkHwf+ClIMjkxVvGDl0NnjpkEnjtkDGbF08FQzD4PygFgUxbPIRCl07OHsN1iE8+3Z0SXWvJHr4fCHTvzs83fHq8e3fnwURYbIScKp7a8G0jvnx4n71f3tzl2kU2V+iDPlx96LbLmzvjd6q6s8gcR0Fm/PHLw9uzfNC22VyhD/pw9aHbxvOV2p2L1AAgRtO+ACDiKBBxFAgAotfqZO+qnQ+fqh9Vb3EUiF6rY9ilZqWIrSmHRI3UOt/nn0t/bYS48i76aNgGoY9BWKxJ7ASdqXsyXDr96Z/7e6fxhJThzfl56bGKZgVkhB5N+7kBWm5CyNEp0qSuXSPlkAMmw6WxOFSCOSG1cdXtGotBVcgqjRrnRUjl5ASdrDfWQeP5CunDY11zIiRH+vBYmHLomm0A8GRiHbabVlHHUYBB+GxBhJDKGIS+teKWrDcI201gvzj0pEq9yXC5T1KuL7LXQxTJCTkEqhaT9QaLT9+w2Hd7UOrQQibZUvULi0NCToWw3QSuL9QILQB4DZuYVRidyamga1FNkXcaFg19gI3xfIVZsq1wqoQUM0u2hYtCXbOlVnpxFLAOTY5G9/WrF7e8JdY6tOsWOCF1U6RR/7lOPczHZ+W+EkIOyW2aAqlpt+nWV86RitG0b2x5S3i+gxyTIk1Kzeplu3/C5VQUIXWQE7QewsfzFXqtjnWX0HZelZAqmSVbfP39Mxetdc0a11Z2NwKyBq9g0cep+Ci4gvXyJdmnEt0Tt2mKK3Rz/TabK/RBH64+yvi1Ruj/mgkh9ZLT8F8VBvP/1NscbgAAAABJRU5ErkJggg==',
    tbChooser: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAaCAYAAAC3g3x9AAAAAXNSR0IArs4c6QAAAMRJREFUSIntlbEJwzAQRd+ZjBEvYK+QAQKCFGmyQkbxCC7Tpk2VQYRxazSIUgQF2aeAhFMFfxBIn/tPAsGdAB4tSXgpqawA/nE9foxT/8xkvbXM7pYFnWlp6joLNjinPAUcJwF0YUrjJDSJuz3gO9P6sC9dcVYiaFDuh8QPUtnUT5fKA1Q/AM20ATfgBvwPYNxgQ8dZ076ogtGZNi4oWbOsGlKDc0UzJa5NDqm1M0UBb9aCzeIBcD7sZ2f50v4vmbz70ngBcQVSBRjsGjkAAAAASUVORK5CYII=',
    tbChooserBack: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAADRJREFUOI1jfHGw4D8DBYCFgYGB4dvdi2Rp5lLWZ2CixHYGBoZRA0YNGDUAClgYoLmKXAAANFEGmJx0vFIAAAAASUVORK5CYII=',
    tbNum1: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAAHCAYAAADTcMcaAAAAAXNSR0IArs4c6QAAAGRJREFUGJVjZGBg+M9AImBhYGBg6PDWhgvceMiIoUhDHmFuxdarDEy4TJt/+TJOm7BqwqcBQ1PF1qsMDAwMDFzcogzYxGGAERYQCTo6GLYl6uqiiC24cgWhCT0gkJ2XqKuLERAAWQAgw9WpiJ4AAAAASUVORK5CYII=',
    tbNum2: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAAHCAYAAADTcMcaAAAAAXNSR0IArs4c6QAAAH9JREFUGJVjZGBg+M9AImBhYGBg6PDWhgvceMiIoUhDHmFuxdarEE3oYP7ly3B2oq4uhjwTNk1c3KIMXNyiOJ2Hoqli61UGBgYGhnAlCYZvX1/DNcLEYYARFhAJOjoozuPiFmUIV5JAUbzgyhVUmzTk/6N4+NvX13C/weRgAQYAcEwkKdazRogAAAAASUVORK5CYII=',
    tbNum3: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAAHCAYAAADTcMcaAAAAAXNSR0IArs4c6QAAAHxJREFUGJVjZGBg+M9AImBhYGBg6PDWhgvceMiIoUhDHmFuxdarEE3oYP7ly3B2oq4uhjwTNk1c3KIMXNyiOJ2Hoqli61UGBgYGhm9fXzN8+/oaQxwGGGEBkaCjAxdcee8FXDOy8xZcuYKwqcNbm0FD/j/cw+g2weRgAQYAxrUq0xOshHwAAAAASUVORK5CYII=',
    tbNum4: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAAHCAYAAADTcMcaAAAAAXNSR0IArs4c6QAAAHtJREFUGJVjZGBg+M9AImBhYGBg6PDWhgvceMiIoUhDHmFuxdarDEzYTJp/+TIKjQ6waiIEUDRVbL2KYRu6OAMDAwMjLCASdHTggivvvWBgYGBg+Pb1NUOiri5cfMGVKwwMqAEB8eyNh4wM4UoSKCbDAqJDXpuhYutVBgCIVCREV08lXwAAAABJRU5ErkJggg==',
    tbNum5: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAAHCAYAAADTcMcaAAAAAXNSR0IArs4c6QAAAIBJREFUGJVjZGBg+M9AImBhYGBg6PDWhgvceMiIoUhDHmFuxdarEE3oYP7ly3B2oq4uhjwTLidwcYsycHGLYpVD0VSx9Sqc/e3ra4ZvX19jiDMwMDAwwgIiQUcHLrjy3gu4RmTnLbhyBWFTh7c2g4b8f7iHkW1hgAaEhvx/eIABAK61KtMt5pXfAAAAAElFTkSuQmCC',
    tbNum6: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAAHCAYAAADTcMcaAAAAAXNSR0IArs4c6QAAAIJJREFUGJVjZGBg+M9AImBhYGBg6PDWhgvceMiIoUhDHmFuxdarEE3oYP7ly3B2oq4uhjwTLidwcYsycHGLYpVD0VSx9Sqc/e3ra4ZvX19jiDMwMDAwwgIiQUcHxXlc3KIM376+RnHegitXEDZ1eGszaMj/R/EwzBYGaEBoyP+HBxgAVhgn/Q4DalUAAAAASUVORK5CYII=',
    tbNum7: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAAHCAYAAADTcMcaAAAAAXNSR0IArs4c6QAAAHZJREFUGJVjZGBg+M9AImBhYGBg6PDWhgvceMiIoUhDHmFuxdarEE3oYP7ly3B2oq4uhjwTNk1c3KIMXNyiOJ2Hoqli61UGBgYGhnAlCYZwJQkMcRhghAVEgo4OVmciO2/BlSsImzq8tRk05P+jeBgZwORgAQYAxhEdnX8srCoAAAAASUVORK5CYII=',
    tbNum8: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAAHCAYAAADTcMcaAAAAAXNSR0IArs4c6QAAAHZJREFUGJVjZGBg+M9AImBhYGBg6PDWhgvceMiIoUhDHmFuxdarEE3oYP7ly3B2oq4uhjwTLidwcYvidB6KpoqtV+Hsb19fYxVnYGBgYIQFRIKODorzuLhFGb59fY3ivAVXriBs6vDWZtCQ/4/iYWSbYHKwAAMAykgk/T4XWvMAAAAASUVORK5CYII=',
    tbNum9: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAAHCAYAAADTcMcaAAAAAXNSR0IArs4c6QAAAHZJREFUGJVjZGBg+M9AImBhYGBg6PDWhgvceMiIoUhDHmFuxdarEE3oYP7ly3B2oq4uhjwTLidwcYvidB6KpoqtV+Hsb19fYxVnYGBgYIQFRIKODlxw5b0XcI3Izltw5QrCpg5vbQYN+f9wD3/7+hrFJpgcLMAAIvQn03oOOr8AAAAASUVORK5CYII=',
    portraitMc: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAA1CAYAAAAztqkoAAAAAXNSR0IArs4c6QAABM5JREFUaIHFmk1oG0cYht81cS2IaE0cYgKWXYFbG1mENTU0GBLqS1NwQ6GFtFS0+BCoGpxL0iD7VHIIsWirS+z+gAuBIkOLeyjUPqbBPqQFGa9BUeVQEGrSgygCH3SIsOj24J3t7Oz8ynLzgkA7++03z747883uSkDn5HqfjqqrQ3ncmWSyQ6mCOnYEOUUuWu0k6zggcXJ0KMg5t/aQbtCGbRcw0Dt7eVk4AFiYHvO/U7BK0HZsd+nOiMpVC8W9fSR7u33AcjWYngYvVy3cLRaVDKaAXDii1Z0Wkr3dWolGh1wtSF1A/9RFY4yIdo2N4TmqgtQBdGeSSSGQDJAHycapIFV10AiOBZMdR49TWZwMsC04AlauWiE3RZAyiQDbdg6UKybHe2M7dAAP8FBw0HSGlsxproOHgTuMKBd9ABYwtOirxpFI7Rw3OuRiYXqMrDouDzDUiYmbZGIQOHbbRASSuxbTNcoEjlZxb9//nuzt1jpZXr8duZtZ3WlJ95M1midSkuhtWocGVMHRErnIa5tbewgAlhBQ5/Ku7rTw+dybyrhPFn6WusiKdpQdva7qZoCF64/HhTG1SiUASQBludl1WQgoS1SuWphJX5DC8SBloMQ19qYhBDgxMBK4FKJbJrb9rSsfCyF/+vKrwPFkhtP9FPf2UXiyG2LiFSjlExrP2XLVQiabDrVnM1+HnKJLEBEPDqJZLBvQM+kLeG32i1D772uLobZapXJwyYrB9omBES04CFYSyzsAF6fHuK4AwIPtAh5sF/DimVfxd70WGmtEZD+JB6A180WAgYU6cf4capWKD5nJptEfj+P+4nUMD8YwPBgDAMzeygGeY/SHaPZWzo+/v3jdb59P2ZhP2UaAoUdI0nEmmw50evLEKZw8cQqnB05LOyD7STzRn3/xHVcC0pCljU1uKemPx1FeXwIAvHHxdSReGhJ2QO8vry8F8vXFBpSA0qXudt7BPHWpWZXXl3BpkGz91zEde2nwHz+WPkGid7LfQ/bwxjpoeYUS8OrU7bwTSqqSTuwPd66i/viJMk6rDpK6pVraTFSrVEi5auvNggsAzz93DG+/PKoFWdrYROL8OW4ydp8unCrAd/JusRgort99c5V7gKgW0idkAqcTRL+FcnUgZTKFg8abBYtK5q8w8ykbH3x058jhjIM9uT9m3vU3ROOOBruZvYdfHm+31afJLT/35rC0salVcD0ZG6IL6ObtgzVzuR7sg8DxZjZn0hi/Bpa+PCKfqdi435ibPI7FlUdKOLY9b9vI2zamYuPwTlbrZwuRg75jhHW5bmGipwfYbSA3GcW1lUf4NKN9aZEYiWJlqwWg6QMDQMpxXJOljgN3oMt9LgrNJpxGBPCcfGHzNyXYzew95CaPo7Tb4O6n3OQq9ExyY/gs7OhTYYcE8P1XguZHPnwvsH0l/a1/IgCwstVCodnE5b4wi9OI4LM/fuXxBBrcqdg4N4EI1I4+RWIkqowt7TawXLekuVOOowZUuceDBCAELe02AjGqXDwXyXVyp2LjRnB0p04jAmeL9wokYpyTFaE1du8oxHNR+WsnW5iPUjyDumQ7n4VuDJ8F+wo4sFKwmujp6biLZOLoqItA/J8qNJvascoxSM/UZ6FO/SXAWLon/C/gzz1lAzll3AAAAABJRU5ErkJggg==',
    portrait1: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACcAAAA2CAYAAABEKYALAAAAAXNSR0IArs4c6QAABRhJREFUaIGtmU9oHFUcx7+Tuq1rtNnqmhBomt1YaU01RRRjD5ZGUIpBEBIpPUghXgTjKYQVT7n0ECW9uAUvFoIHaetCKKTHJiSHYKtItY1b1EzWbUt2uyWbwzrabV0P7nv5zZv3b3b3CwMz78/vfd7vvd/vzc46sFeN3Dsh+jWsxyzb1Z7tOQgAuJfPSusV/ZqahC2cThycSjGJUGprdHCLuqZl8lyzYKrlVslRPtgMvnV7HQ9qf6PVHqtvAx/PDhUYADzyKtj1ZMxX8fjuGHbubMeOSCTQqep5+PfhQ2ldWDAolrWWGBhEZXPLV9i+pwMAAuUULBKNWsFUPY/fl0s5KZissJYYGAxAMDAAKN/dkA5oC0YBWR+V52gBB1OJgjHDJo+qRCcMAOs/fx8AtEklfPBINMqvsGrf08GBRDAAqDvGF90+ON3sRYNssMrmViivycCY6hmAAzI4njZMgNQDqnrxmQaASmzLUEC2xtKcpptlK1TZ3PLtWTFIlCdEo2B0QJOqnocKeY5Eo6h6Hksv5oBoZE+p2ou2GAwVyXuOA6C2OxbHrqfi2kGZkUg0auUZ5kFx6VS2ZTmvDQAHU21cCiYClO9ucI+Ig6sStk6xeC9YQBjf52TAIgSducw7uvY6afecKQVUPQ9zU6OYmxq1Shc2Nq3hWjVIo30CcFXP45dJc1Ojvnuxj6pMB0qXu40CNaKuZBJdyaQPRrRnsh2JRnE//xt/ZqcEPyHqUWI0wnQxNcyhmAquGwAvuC7em/qOwwPgz9Re+c5azWlznI7u/23ey2cRGo4FwfvT8766pa/GfZAU/OhHaV/bi6lhHBufQSzeywG3Nlw8qP7ja6cMiK8/fB0rs5O+MgbGZk515NQX/J6C0XJZPVMdzKEXy3NOuZTzea//6BsouC5WZicDA7Czj+rX+XSgrOC60rZU5Cy1+g0RGGBldjKwn1Z++gEAcPLUx7i2cAk3v/1c6pHEwCCuLVzC73/mAQBHXn6V2zKB8/c5sWJ1aVk6WFcyicX0BPbv68H+fT0AgPHTZ/hE6MU0fvoMb7+YnuDli+kJZFInlHDcc2JAjEyfR4YsL4S9En+6EwDQvbdbO3tWz9qLGpk+D9WvL2VAxOK9rGPAg13JJLKXzwIAjr/7NvqfV0c6rc9ePuuzdT9/Wzev7VQigjGxfbGYnpAus0x0SVV9XhjmqUf51cH301CX68qlnDQiG1UdTvuJrOGDvxmJka8ShXPE0KbPsXgvXYqmdGx8BjYfFsU855RLOb7/ZMv8zZcZfPDJiNSYzCOm81cn7ScwGVy5lMNnx4eUgDoVXNfaa0Y4VUUmdQI/Xi+GBrQJAipdQDiKCwDwyuFOrC4tWw1ScN3QYCY4K60uLRshwywlVZiv6YFlfqZnL78vuK4p47P+1pDW/0OsnRsCAPSNLQTAWETSyBSjkvSv2QKqlrVGryupQ75KGZgo+tuCqm6rZvOlXfpN+ErqEBIHtt8i1m8V+f3auSH0jc2EOmtFCV6E9TdhEYwC9r/zFgDgrz+uo29swQjIThQGs36rGLB9IVPEp/M3pYC+g18FRgETBzrxxHOHeVn2F9W/BcDBlx7xycjAQFblzekgIH9lMoHpAHXSgYl2RUAOx1xvI7oHVaAMirWxtUsBnTBeM4GKasRmPVVtw5m8ZrMstjLZogFifXzpPNRKvfbi9r013NUbrQO8kCkqbVGvhjr4W7W0trKCayUUs3X1hrntf8dQk0qe+nW9AAAAAElFTkSuQmCC',
    portrait2: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC0AAAAyCAYAAADImlLUAAAAAXNSR0IArs4c6QAACQNJREFUaIG1mW2MXFUZx3/nvsxMd5eatLUNKdu4uri6YDpbBGtaKVJePoBErW2RrXzAjYlihETRGOIHE/2AxSgJxJg0xDQU3baYKAGhptHWbba02+4slYWFxSq1IbUttbMzc2fu3HuPH3bO3XPv3LkzffGfTObeM+fl9zznOa8j0PTM49uQUuLXPeqej+fOf9ecKo5To1x2qDguFy+W+MPxd4lJxhNiEl9Y/RGEaZG1TExhsHLlUizbwM5ksTMmpmVh2wa2leHihSKZXIZszsayLEzTJpOx8PCx9FoDz8fzJdL3qdfquHUXt+pTKlUolavMFSsUy1VeOXGyCXRXPs/gQE8i7fRMieFCQb449c/QAICv37GanJ3Bznlksxls2yLI2vg2lJ0afqN2mZNIIRABBL6MQtc9D78u8fw6dbdOreZRKVcpzlW4WHKYu1DmzzOnQtg0UF2DAz1QgMmt60MDAC7+tyzqOQ/Ltcll62RzGXwvIJsLKJcqgEQYAmEIwEcIAz9o8nRA3fNwax5urU6l4jBXqlCcq/L71966ZNh22jsxKwG+uOZjYlHOZlFXlqDLIwhy/OrlowA8dv8GhJAgBEIIJDFPe36AV/dxXRenUqPiuMyVarzw2psAUnnqcoB35fPQ8PrkwPowfXqmxPDxggTEV265Hun7+MHC8KiUXAxMhOWBIcCXGHrFft2j5ro4jkup7FAsOlz4oBwCd682uHnL4ksGTtPgQI8ySO498o6cu1BmrugsQDtVqnWXenUhdCOedmsu1XKNX+w9oCeHwFdbqs5B5r2vxzsgNq8dwLIFliGwLMGPfv1Hfvi1O6LQP/7Nq/F6WwKrtPJU0BFgoZRjsIN8KoyGCwW55/CMGP7cjZi2jWHNozo1Lxoem9beGAHelc+nAl+qnj/mMT1TCt/LUwHlqYDu1UYYeir8VMh4VRenMh+yALVaLQpd8z3W9V0bAusD7ujuYhNEKy8rCCUFmu+pJuaNSwcfPfq2dKsu1Qa0V/ej0G7N59DJ9yVqbm2AHd1dTByAcbhWEKquQikXGqGXTXKIDv7bQ2/IslMDoFKNDcRKxQ0z6l5qN2MkgSb1wj2PrgPg9I79Tb8pcL2twYEepmdK7MrnGT5YkF9eOyjcej3q6bHZf0kFPD1TigAneaOdIfon31NlRV8fK/r6WDmyMVKfauPmLYubjNWNqFdreG50IMrJresjBQYHesLBosD1xi7VkLji5VU7epvqe1c+z4uFd6XvL8R0uNrpwHEDLgeklVaObGyCbSW9bZ9gwdM6cCcVxD2hgJPi/+juImt+OhK+r+jri/x2Ke0G9YVlXAwXComWocW3Dqze44NQN0Lv5rhUbJPgMP09/tufpv4Rzh5hPLfyuG5I0qbp6O5ik1FKupfjWjmykdM79qeGX2N5D9+tpAEYL5AW37rX9TLE4jZJK/r6OHPyZGoefdqjsbxbaQU62YbqeZJg9fgNyxz8W+Q9d/cA06/OtGxLgSsZAEOjY6lgccgk4KHRMYYLBXJ3D3D+1L/bAm96YpRNT4x21I4CV21ZjfOaVHGTFipJihusQF74wdZE6DioetdXYb3nkrwfDv0k4Hi36NIrHJ+cYHxygvUPbmf9g9s5e/4MS3uvSyyn51HlaLEOxNtvOEiE0EkeVgWmZ0pN20pd/at66V/VG76P7JxK9LKukZ1TYbm/Pv3dlvkUuDYYpdFq9lCAgwM9FEo5HnpqW7hLAxh7/x0A3nzp6TDtzOyJheeTJ5M/Wp4kKcA0Jc4erWLpnkfX8dIvDzEIfOO2oTD93OE9LFu7mft+8phWSXKDkTyNsrp0z+oM4XOhAT00OpY4EJL00FPbqO78XVP6ucN7iCwhsfBQ8/GIc0Ark9xGPJbjPEZj9giX8STgfE+VZx95rm2cpimt7Okd+zva+6iBGC7juqfjGhzoYRB49pHnAHjgptQ1qaWuxGilL33mkzQdOdIsfuAmKwLc6c4wTWnLeFL9mawVnadJiedWO7Hjj++4IuDbvv3zxHbjWwOlbNZc2JrGt6edenG4UGjaS8TB1CcJuF1Y0ohltfLalh0Njw0f7xVDo2MdATftuVuAq3OhHs9x4KT9e1yf/0SvuHdNv7BtKwptmWYqaNImphNwXe2A0a4a9Oe/vHUK27axs5nYQBSiJZB+Z9HKiHbgnQCrOuM9fucNH8XOWNi2GV0Ru3sW0YhtqV/HPn/MC2+H1J1cqxBa2ntdE/ixqf+0NESHTTJi++xhAJHJmuQyFrZtI/QMW27NU5yr8Mrk26gL9Mf610auswqlnKoIGltQHThNaqZIupRXTtDqF4C8/frrhJHJcM3iHEuWXMO1K5dHob+5+S7mKg5O2WXOqVJzPA68/kbiH0Bnz58B4ODPvtMEnLSIqNnjhq9+nw8vXRGm67OHDnzrp66nu8vmQ11ddHfnyHVl6F6UpasrG98wGQgMAsPEx8STgbIYQCrQ2fdORUq1AyZ2Hjx7/gyz752if1VvxACAWwb6hW1CNmuTy2Qxs1nMjI1lWxi2gWkasX8CMPClQdmVzJU9Dp04QSNMQuC4OgFO09nzZ8IPwJGZWUzLxjBthG1j2haWlcG2bEwzg7DMOLSg4gbsGxvnyN9fB5DjkxO0AqbR3VdLjVOMxLByEkCYCNNEWAJh2gjTQJhm/C85cBcO6HJ8ciJyIlHqX9Ubdu+yJcvZ8PCTHHjme22vAzY8/CQA5z5Ink36V/UyPjnBZ4c+7Wy8eUjIRmQawsSyDGzTwopDl12fl/fvTwWOgy9bshwaHlfPSdJBlcFtwOV9t68TgTSQppg/GRoGCCMK7VTdSOF26l/Vy+HCMQDW5m9KzbtsyfIwbyd1A3iBIEAgpUlgGAjLRBgi5umqR9qgawUOhECd5O0kn/L2/ffeKQIpwZcEgSQgBn3g0EFI6b523Xo5SqsTwA8EfgC+KeanZCmaDgFS3UOkNXI1pcZGUvr45AR7Xt4n60FA4En8+XWj+eRCitf2HT5yVYE7ledJPAkykAT6pbrS5XbzlSqtBz1fEvgSL4AgaA6PVH1ry6b/i7fb1en5QSM0JBKD/wH0RwvqEHmb8wAAAABJRU5ErkJggg==',
    portrait3: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACcAAAAzCAYAAAAU5BG4AAAAAXNSR0IArs4c6QAABQVJREFUWIXFmU1oG0cUx//rFGpyaMiHohgqhQ0qTgWhOFAXfygYH5xCg0sQpiBkUQKGQpNDEkJKfbWNXLf0EOckyEF1DW0IaU0bSg6OGydyMGmFEChKLayQBOyNEcYX1z6U7SE745nVzM7uKk3/IPDOvpn3mzfvzeyuNTQuk/lbs12z7Z7lqxML8PG3t2njz+f7uGsAqOULuJe95MufVzgTALpTE9jf9p7QYObCSXQNfkWviZ0fSLdwSqhavsBdy+xgRdiNbzdwphOUTCpYC9CRQQXnC4wFdOrLLLWQwwnOtCe3FyhWqsnJllkG5xtMJFUEIQFsEoF1pyaEDv5LWT65PdIOJ8wxNzNvVKLxRZHj1AhYLV9ALV+AUSm6srdHz55zXK41CiaCig4klf1IBbNwdbnmBYydCMlPWcSCkWOuNuk3RDcb3XAJWCYRqGsfml6DUSm68lGXc68i8VmwoK5zv5nhds5WNDErtUxlQYjEDuiU8EFd9zwuO7YUTrav2dsJmNuKdAsphCP07PKKQGv5AkrXpwAAmUQAmUSAXruVyt7XsqoUHUhiaHqt4XGE1cpKtrxkGdnEzySAoWl19GaG29E/ytuxubuUy8K+z8G+1xFj+77ELqc9QvZqZNU/ushdk/7ByDHqj4DBaVmNShHp2DZmhtthVIp1EcwkAvjk6/t1/Xo+F0dO1K6qZnZZTetHoxk9EYNRrVrLsEih6QSePIDx5AE34KNfJ+snWq0KbYGdKBuVIpYWrv8DYBdp4yLXnZqQPnySCILJMwBYyD/EQv4hulMTWKsZMKpVYX9yn9gTaG7C5t+72OC4qlYyCJtPQV3H3ORFRMIhRMIhAEC68ILasz+idOEFtZ+bvMj5YHNNBKfdy16CUSnSmZTuztO8IE4yiQCXKwf2HcSBfQfxwacfOk6QFBSxZ5WObQv72COnWTMAAHwx/yYFFCVvUNdRvnUVANB2uBlth5ulcAP9Or1fvnUVQV1Hz9lvkI5tIz7+Azy9Q7zTmRLObH/obddnJrukoj7vfnTWkcPx7UvTNEQ6BrnGdGwb0RMxV3AqWXBSBseCsIPBWurXJafjS1vKZU3NOkREoI1ItuVwAC7G4fKPSHZMiZw65Jujf9cfcuyAA289w+C5uMvu3sHg4ZFJW8plwW4zfaeO47srNzxBGdWqazDXRjaZmqbhzpULAIDbv/zpOoJewODzYVMzzZ2vBn2njiuT22vEiJQPm4x23sTrHgNfqnR3nrv+wzprx3674xnMSwfzy/ZhAEBuo4Tf//qJLisk1chGs/bsOTmiPPl2ihyNVDjUQRvPBLuwvLnqCMa2G9Uqzk8/BZnc1Moski29GFscJeNLIWVwNFJEUyuzOLL7EIAoRvQ4UuM3kL3c6TA3Xkeb9+KasfPkTMa3IIWAwu9zdjAASLb0YnlzFbmNEgBgRI/j6Y8tSqjUeA4jehzlrXXhfcuX6H8X9V+ZelpPo3NPVOqMwJ0JdnHt71/mH5dOfvY9nQQAXDPuY3lzFcmWXuGYc49v1vFwX5nCoQ5hZxlk554ojjbvVdqWt9Zprsk0tjjqDKeKmggQgBSyvLXO2ajGskePFIQZDnV4AmMd5jZKyG042/gRrdaXlehPjQBwY7QCc49v0upVHl9TK7MNO3Yr+ySbZDf+L/W0ngbZWppIvsl0ZPehVx49UiQqNaHBfPMj9vhzkjLn2Ip83foXNttJwQoaTzcAAAAASUVORK5CYII=',
    portrait4: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAA1CAYAAAA6XQlSAAAAAXNSR0IArs4c6QAABQhJREFUaIHFmU9oG0cUxj85gUBupUWpoTZyE6PW2hJIQPhStREkTWKoD6bpIZfQU2UCOfQgn3OKDoUeTNRT6LUqOuSgJiVELfIhRoQGUUmpMMq67cFITWlPvhX1sPvGs7Pzdmf/lHwg2D8zo998+2bm7WwG/59mynkmjUbTaEQFAwC0qwXPebk2SOV/j8esJyBlsFw+i/3RFOXaALl81lOhXT06LtcGVD8yeNQKMx2kqv3RVHtdvg+v68YcUYBnBLpy9aK4eDjusUBgOqSWdcGNWExDYtauFjygHKwMKYNzWrl6Ee2jMAmFnosLm5YOxz0H2nl62gEsK6xHsxf3LgAATp4+q/2ztETtv/nBV4FcQcACFgwwJGi6fzjueY5NQWUFQXMhMVPn0aA/5DoTV0HhYRLDHh2Oe6xzdJ0ro+ucrlwun2WhdbbP2tVC4HQU5KgMYBpGXJm3P/vRxxh3pWNlEh6mIdSuFnzTnRoSsxf3LoRO9qTh94/Y8Ai6Z9qmjiNyDEMToyqYKahJp9yZSsSyDOyZxqKKOhE2IHXnUZ5E7BgOSnDkJdkUzBSaHPa5G5QHhGVjJjLJM0hyWMxFDYUw2EZzim4f6PaNm/SIcmoO2jPo3HkvEez6ZkX8OBf3R1PMlyro9sOdVpmOm4DCIES6fWB9sxLahlxufbOC+3frAIKNkPnm3Ek5gyPbWVju7aLbB5YtC8PODoadnVBYKjfs7GDZsnxOy+EkMWUAZEJnCRNnly0LALBR+xYA0ASwUnqfhfWUrX7qQveRy4fR+HMJMQAJdL7kPL6DTt3jsOa9zKPnrW0cdOqA6xiFwbtrN7Xl76wVcG3Dab/RnIpjNZ9gV7pcPisezcS2tWXo/pNnT/Hk2VNcun0Ol26fw59/TTydlWNbLkP1SI2m92nqkp9YS7OqM4sLOLO4IM4fj2+JY4JW9Xh8S9T7afsLAEDRcqCLFj8RJM7Wnre2xfHZ5dfQ2/sbCHgqchmdis5woEwtOvBBp475UgUHf/BlXu5+hzdWP8H18x/j+nnn2j/4XVtWLkN1oygQuGi5A6bkPtpJMxD6BI6J81NLS5775PiJvaMyL/d4WG6vgo1hmgWKFnD/bl2MeBLNGNyjV6V2QNbug4ciFMJkNOjI6aTSQZt2mBRpllAXkaLluJNEUdxFlARe57JJijmxbfHT3YsqbT7MLcc0T8raag3Y/AFuGNBPhf3w5pdad4M2B30hYZJY68oEQasiWNPNGlliWpNXlqCGKDTKNf9KNOzseJKetGFlYLLfaIuqaAFtyymnrkYc9MS2sfvgIbZag9iwSHsj5fWFtwApPPb63lG61Rrgzlp8WCQBJmcJgGAh5cKy0xPbxo3fMgBmom6iGI4KSrNKozn1wHI6tbSEG59/hG++/kHUNR03snwJvK6iHKe0USi/kDaaU6xeuSzAgjSxbSye/FnUUxJ1OUvTTmuhDpdrA4TtZl7byKLRdFa81SuX2SWYVsXFDX9bOtd1CnS4XBuwL6ZQXvvlHclffznmK/vOe/8C0g6P7K4q3ZsGiXU4DBbKpsfKaT8cp/0RDwt3IG+19F+VtA6bhIEOgjrBfcDhtgt0GzScy6zDUffOPN/mRo8it6lCcy77HIY0E5g0nJZMXVaTnwxiuJuWTBIv3yeDJOt8EulMUnffoUsvw9w12XFMIjXfVpXoFelVKPbOz6uCjwVM73ZpQ5sM9v8ABG3Md6e3nYEAAAAASUVORK5CYII=',
    portrait5: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACcAAAAyCAYAAADfuMIdAAAAAXNSR0IArs4c6QAABF9JREFUWIXtmc9LHGcYxz8r9eJJkrBeNHWjYOpOMZQivbT0B1vbrKUHiwSksORSW+IlKUb/gboJ9hTb6qUsSA4VPQiJ0Qox6CFBNk0WJlu3xY4h28NukAZSvMQyPbjvm5nZd2Zn1rp66BcWfN953vf9vM/7Ps/7zhiiepn7aOtLoSramAAJTeP0qwfHN3LzEa9UAwUcKJiQHzgTIBmPWos1kReczVO1hNp4vLfb3ODMw/CUUErXAUJ1imfmS28drpxw5kFHYRCVee6ogKGCO0r6H65aHTk4keM4inAix3EU4awKcvBLWV2/X3mlrsBwAiwx2LM/qpJSk0uugGVwYnCvGQmwpkhkX2AFwyAx2MO9W4v+4PxKgBUMw/WZCsaPnRtcKKXrZkLT2HgcQn/2AoDPutRzKBgGqcklW11isIeCYZQN7GbbFInI1bJGKl7Rqj97wejAGaanhpjN7CqD4OvkDWWdCkxl64R1ynNZO995m4JhMD01xOdfXAPqpTcB0vkc6by9za83J5R9edl+Uro7ljwn5TvPTU8N2cCE7j5Ic/dBmmQ8ytPtgnIPUrrmP90uSHtKHs2urrmO6QtODDg9NWSrvzNxifaTLbSfbAHg+fw5aW/9CT2fPyft70xckvXHW5r9wwkPZVfXyqJyfKTXtqdOHAtz4liY/r6w5wS7Nbu9U31XfsL5qqqCC6XzOQDGrj+UgKqwb4pE2Fj4DoCGti4a2rpc4TrPxuRz0ebdC98CsP0kr2zjdQ6ZbzZ3ADA6cEZWHm9p9p18rUuqavNa/IIni68kPHb9ofx7dMD/yeDTztVBlU5w6T2rnPtO5DGtsV557ImE7mxX8pwrQ6VolfvPKeuSpSaX0BrrPTvSGuttSdct5QSBUwKKbK8aYDazy6dffSl/s5ndMpuCYYhg8Fw5v0k4lM7nuP/nb7Li5xu/yIGcyVmV4yilKL9gQeAAQqb5cj992PuGBBwf6bUZitTjDIjxkV7fYEHhcHrQCmgFcCsHAQtk6JBpPX6sUqWPIEtpVeCPhwChUPkYTZEI2dU1W7a/nykC8M3iSmCwIA3MP358D4CtXJEPrmZZuXbRBuaUNRi2n+TF2Rlo7IofD7F91dw7I8cs1y63U8B6Yfhd1xGTm5kr0t8X5tT5FdG/K6Trx0PRmdDMXJFuDVrJkBiOkbq6yFsff+QxN7sa2rrILizLsui/BKkEVH48dIIB9PeFWdf3lhUgMRzj9Ov/VIS6d2uRxHCMnc2M8nlpLOWrnpPYvH05SmuH+91MwHWejdnq//q73Vae//4HOQmA7MIy6zrKe99Wrsj7Vx6V8VgLZjIerXhptHbY2hH2vMMJ7Wxm5F5z06nz5RFtg6vkNRUg4Aq5s5mx2VTqy+k9ERBmMh4MzDrgVq4IuWVPm2okKAN77SDk9F7Fs3VmrlgLLlB4uc7twWHp9uUoIrXU2f9bU65u7b/3ngiSSqrD8k5ZK63rPoz87DlbRNZY/wI+5enfKnsd6QAAAABJRU5ErkJggg==',
    portrait6: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAyCAYAAAAus5mQAAAAAXNSR0IArs4c6QAAB7xJREFUWIXFmX9oXWcZxz/vuefm3myp0FWYYLPR0jQ0ok2bUDL6g5W5Vij4TynDRETm1DGFFUbVvxT7XxsEhSL+sYn/rHUMUdTiullX10mDNO2dpunSNA2sExy2TWt+3HPO++Pxj5Nzcu/NuT+SFPxCyTnvee7zft7nfd73fc6p+ukPvg3ksM5hI41xBhsZjHWYKCLSEWEQEoYR5XJIOQgoL4SE2vLOtQkAoYme3bpZ+TkPC7S3F3m0vUixvUCh4NNWKFJsbyOfbyPf5pPPt+G35cnl8uT9HL414CmLs4I4h9MWYw06MotgAeFCwNxCwIO5eebnQ/46eSuFOrZlgN6OoC7cUKnEOzduVQ3iS92bVeHRIo8UihQfibCmnWLRIq6AiAIU5AVP5fGdtVgFzjiMMRij0doSRRFhGLBQLjM/t8D9+/OcG79RBQY0hEv0em9vel2aKzI8MZL6ObzrC0qsRZwgIumECB5KefgowAnWGYyxGLM4tWFAEITMzi4wc+8Bf/7wliRQrYItDWTJdrDPZ7BvD+MTczHs30fkSP/nlFOCwqEQFApFG56K8J2zOAFnHc4ZdKSJtCYINLPzAfdm/sv5RbjBPj/taHwCero7Fq/nloElz0qjJhO8p7uDHgAGGL48IoB6fv+ueHq9HE6B8hSeExBrsc6itUUbTRhGzM+XeTBzn/PXp5bBVQI0U22kawcz2Ocn6SKz92dZmC8TBGV0FKGNwbdOEGOx2mKMJtKGQEfMlsu8NTaZCZfVYW00s9rrDSr2P8Dw1TiSX//iAJ7n4bf5eEoE58A6i9MuBlzQzMzONwRK1NPd0VI0m9kM9vlcfW4PgARzAUEQES5ofCcOh8WJEIojCjXlMOJixtQ2ikKrII2UDP7XIyW+tn+AYrvGc86BU1gtOKMJo4jfjVxZ9uPTo2ZNnWeB1KqnuyPNR6MjoijCEwErFiMaqw1RpKk8HcYn5uo6rNfezKanu6OqvfI6WVSn37+CDk28UTsriBG0dUTaQs0JUZorZna61ojWg0wUaoPvACsG6wzOOmwUZjrr7QgYn1g5QOUgKiFKc8Vmm71EOlIeVnBWMMYRmQhrbZWTVkFOV2zISVpU/r4W7vmffbWu/+RoNKHGRwnWOox12MBybuxGlXGjkSadJjZZEW4lT+vJOsETERQADisOQPZ37oAWz9t6A6gXnSR6AIeO7m44S7mcxKvYicT1oMSLt79QWDNcAtFIj2/alAmZ3Bur8EQcOAtG4r9rVCO4VsArB608wRNP4UQhnoBSKwLJajt0dPeK4JIo1sIBeICPEwRBiVqsZluD6+0IUsjk78DhJ7l7+2Me37SpIdz4exernm/o3JiZLr+9PI4frwtwAnhNXy+WOSrNFRk4/CQAh0+8AcBvgJ59exvCpbbff467tz+u6mOoVCIuDMFXCpA4irj6EXz1bvysv7DUdujobp7+7k/gxEiV7eETb3B9397MKU3Aau8/qzro3b6l6tmhHdvwEfAQlAJJwpkB9/NffAOAl158jd6aE+7S1csA/OgP3wLg9e/8iTsjb2b6OnB8Z2pz86PbADy1o5+tG7uWvSDmvFy8D1pAJH4bqFXldNbmTqItT3Sy5YnO9P781MuZdpU6P/Vy+rsLp17JtPn96Bg+yoIolFgc2RFspOtnT6XX27vW88HkDACfTE9n2lfatCLfORARnBPqzHCqnn174fTSUZis2Dsjb/LpgSMM9X2Zob742X0+yvRRaQPUTYUUUATEOSxwdvSfmUYvbBBeevE1+guFzOdJRwVy6X3tVpNEtDC5ZHNnMob78Ym/LPoOqlbwkYFePCSeWHGWZ3u21gV4YYNwOawuxU6dvlHXvla1wM108PPdtLXl8ZwVcA6xNM3BRhF82JC+nyPn5+J3EpEYMpdxkrRaE65WtamzWAtKzvNQnofnEJyxRM4S2ZWt4iQ3G+mT6en030qUE8EHfKctxlmsMVy4MSX7O3e0/N0l0fh7F9OjrVaNprXRwlNWECt41lnECtbEpdZq86zeJr4aOCBduJ4xFmvN4qevtalVyGZwAE4ZrHN42mqsdfzx6viaARPIRqD14GrT6lPr1rFu/Tr8X537GwBPd23iwmScyJX1Xm9HunkCkLyvZGlD58YqUIDJsbEqm3dvX+PdivvKb46VEuvAOdIPLxcmp6X2c+7wzaUy6tiZZ+K2r5ynv1BtVwnG4sJIFkfPvr3VK/jstSpfwzdH0tfMoVIpvXYCINT9rjZUKlU5qgS9/L17y0quSristgTywqlXOEs8IweO72R713qGKvwnOnPpKiyW/Q3hEqhKyP6Tj6UFbDO4Vp4dO/NMVX8AB3duY+jgU3h7tm3OL7ap4Zsjy+AqnaykTFopZNJHku/aU2gE//3rt3StUT0ltdz2rvWZz1s5Lf69618wRV0/B47v5O0fXsEowYiqn4PNIJd12qJGp/7TcJDbu9bzNqBzihBdlYPSKHq1Tlaj0ZszDeESHTi+k0sj42KsW3kEK/XqXUX+m4pfvtV6XZgFVwudRlFM64BZI+8/+RkgahlupYoil73NtKL+k489NLjpsez/7LHGrB7wYekfE+XM9jgPP5SWAD+YnKk7yrVKvOzaM0mn/3sEm2lFgGs9SVaj/wHVyLfXnraZAwAAAABJRU5ErkJggg==',
    portrait7: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACYAAAAyCAYAAAAweqkjAAAAAXNSR0IArs4c6QAABBRJREFUWIXFmM9LFGEYx7+bklejw+JgrZOE5UEEwVai1pOEUghB1p+geMqDx6VjB8HDmscQD6YRROEe9mSKuElRFKgLbZPbMsseQjt0KLLtkM/0zjvvr9md6AsLM+/7vM/7med55n3f2RgaVy2EbSxyQ04ezKPVZ0hYltJ433UBALdHbhjPGxasRjAAtEAi7buuEaApWMNAPBz+RlDIYAJW23rzqiEQmZjoBTh0YP8MiiSDO/E/oaAoCxlYZFBUTyodz+VbdlQRi0QJyzKC4yUCizyFOjhRX6QRU00eNnI8mC9aMkf7rivsqydt+66LhGXRGunVmTRiNECkhGV5EDxIoVRGLr+tBJH5ZCUEU0HxzmQgorZCqYxCqWw0T7MIylTs5Ln8NlJHRaR8/cBQsl86TtQnBUOIvTB1VAy0xW37b79TRC4vt5eBS8FE4sOey2/7okOqOo4PMuUUffesXeqoKIUzAhPVAj09O5lIsv64bfseIjSYCIqipXLOR0fUHrdtoPTHX3p8AuxGHgArlMrKGqPCpQlaLt/x9be6+cAYsj20kjhk2r9vLgFNncJ5RMeewCLLvuI4TmPctrFSOhGoj1x+G7fO/go4Fdm2unlcHJkUsihTqVooASA9PoE017a7mgnYVR0H6ckZI1slGAvEPv1KKbge35t/AAB4OL+ApYU5VDeXhAXf0XMJSwtznu/0+ARbe4HMiVb+2HEhelB8gdPEa5kpDCX7vRTNLj727NkfaXbxsWe/lpkSxUQJ5oMjVR1HWDvJ3j4ke/vQ1t6mnIj6yV6nho49cdvGXnYOAHDt+hC6zyektmz/XnZOu/5pP0Z2VzNeOnhnVcfRTiAT+RycnBFyGH2+0dsjApEtnioYsj1eKur+rtTCicS/waL6jAIM7OlStlbRLqAq7vzb194RSZZGhCz+GDnhlw8WykRDyX4lFMIce1h9+fxni6KUvmjqRBez2S9nn3vbGKWQ3ZJMDqP1/A1VezI9BgDovnol9OCq42ijhUbXsZ31jdBjTKAQxXflzvqG8sDHSvUW8gpdYydbTnnXp8+0A4Ka42WavnrBagDw4/uBD4q9psgRKOnm/WWfDxNAU7DawPAoAGAr+zTQyUeK7tkUq8aLJP0bivv5xEZLtQso+oR+WYkiVuvoueQ7xrBPOTA8isHJGaxlpurewJnoSVPLNwSgWLixu9MAgNJeAVvZp1o4Os+zaaRrUqVcwad3LwMs7I0UioUbGB7F2QtdXtv4uZ9S+/mPzd6DVMoVrW+Why60UCSagIVTyQRKBOeB8SHWwZFkkAQE5lht4pfSGgsTLR0kr3p8UtRiJtEyTYWJdL4oasZ7pSoyUYqgjcG+HXyNbPIP7/e0D/rP/+evV1qwSrkSabRM9RvGdiYv9bm9PQAAAABJRU5ErkJggg==',
    portrait8: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAA3CAYAAACRvGMdAAAAAXNSR0IArs4c6QAABL9JREFUaIG9mM9rk0kYx7/Z9g8o9NBuqC1BoSguJVCkBdfqpXsodg+C9SQLelF6KSI9LSJ4UIp4CfW0bPGy7aEHKwHpXpp2JVEKIQgpgchLY3g1SMTLIrKs8dD3mc5M5ueb1C+UtvPOPO/n/T4zz8z7JuCuluFawiOOt1yCtwBgNbsBABhJJoWL+2GIKzOzPvG8ZQpqhJPFwXYdVBew5QonazI9boobS6pgrdXshjcc6SgclQPFBtwsvAIA3Llx0/eeVvV603BAvEaHhwAA+eKucexkepyqhDMs39HqIg83OjyEkWQS+2EYy/lo7jrBOjlJcCqwuHOXHHdx9gdfwE7AVMoXdwlYu1kIkPzNeTiab/thiP0w7AhKN94Eqkz3ZHoc+eJu7PkWV/niLqVfSH1buo8SkFw0ZSPaRARHhdWN6GlUQToF9okp71oC5N3Hy5ieONN1mEqtru2vup+8a/XaBvhKdkdV+OXrtDB1zpKTHe3XJgAAmPr/jfJ6ruc4+1s2iHez93sADqRSyj6X8RWNIECu5zg2C6+0mWSruxs1UJYJkDSQSjGneYaRZJKtdDYnOzmayarU6uzGjSCwQiJ6oFxNvS5inYJ48Q9HwARoc5EHbQTBwTGPqzAUu2NIGbBSq2MwapNdVEHbnEa3IKmM8Gn2ddEK6Tsf+XlIYM3tHE4DaGpAZJW3d5zvZz2qqUQPVanVcXn4K5pvD3aUSw/WcOnBGgCwNhMg398k53Tz7g0GOQwC0dxLtd2I/l9fnFNC6vqbIBOT6fGW6t3ky4u/2JypcLsDLQwe4O7jZQDA3/l/AQBLCxcQri4pb3r26hLr4/ICJxRzHSBfcHWanjgj1Lj7Wx9x6tzPxjH3tz6ycVuZW23X6TQkpJsvI1NcO4GidtjGu7iXzeAT9a2+xsCJn9g4lRrVD6yPSvJLmncJkh2lB+gLC/iUnMDsvduHF8vqGEIffEFfWEAj+i9Ku3Ay10Ken3+IvWxGCci7yE+JvrCA6/wAadGQs9c/5w4bP7c53vbW2PbeDe6QeufGTexlM7F3DlNB5/sPpFI4OTOvBFQ1tlazG8JJmkD5wK67iY9MkHIxT1yZmWUnZUSl5eTMvNMee1QyfvqTHSVtZW5Z3WQVwaG9EQQ4P/9Qy2P8iCqD8rDyonIB1F03pRqWvTvBfWZmop0lCqxU820djSBQ/qiAbXL+Zk5wiNxcX5xD/7Eh55TqZHPRFVKAJa0vzgFAR6AugPDccdq+dsBwJOsWIOKeJ1VyLVHl7R0vQMSAbMlp7z92WFNtoOXtHTo7en03d003A/v10ebBH+//EAAhva/QNOD1ZPAagDWK5wyqgxTcIrCnC9PaQDQH5d+IHH703y9CvKcL0/w9jMAqyNbZq0voT4+ZxgkuxtnLWUYOHt7orDwnjYB07AcgOOMjPobUpv1mLpQVFwebxRL602M4MfYjAOBiecUK9uzUbwCAaukdG6+K+8+T2zKTAOkEqAKtlt4xYJXougnQBsrS7QpIfZvFEl6uPGcgOkAAeLny3ApoUsLXRVnNYsnaxye2ys1elyAmFzp5ONexzjuOi2M+oimjapflBNmovu4OWUx17YARVy4ZskKW/vy9Wzyx9Q1MHIiDbvFsbQAAAABJRU5ErkJggg==',
    bmTab1: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAUCAYAAACJfM0wAAAAAXNSR0IArs4c6QAAAIdJREFUOI1jZEAF/xkwASMWMYIAWdP/Dm9tBlVxAbjA7ZcfGCq2XsVQR4x5MAaGoTgMJ1YdfsXomohVx8DAwMjIwMDwf22SNcPtlx/waiIWwAxnotgkNENhjqOqwchg1OBRg0cNHlYGszAwMDD8+PWbAZmmBMDMYGFgYGB4/P4rAzJNCYCZAQAY9kJDguMUnwAAAABJRU5ErkJggg==',
    bmTab2: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAUCAYAAACJfM0wAAAAAXNSR0IArs4c6QAAAIBJREFUOI3tzrEJgDAQheE/kgHsnMDKUVzIEVzIUawsraxMI4gWWh1E1BiI5b3mAnn3cYZrDsIxHx1zewBHW1eURf64MUyOput568i/mAIHUX851PFxE4vGRvAMoCxyhsn9gsqBWfqNz1FYYYUVjokFWLcdf6ZEDAswzgv+TIkYJ8z7N0S8M1XNAAAAAElFTkSuQmCC',
    bmTab3: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAUCAYAAACJfM0wAAAAAXNSR0IArs4c6QAAAJNJREFUOI1jZEAF/xnwA0YC8lgV/u/w1mZQFRfAqvD2yw8MFVuvIuvB5ghGdAZeQ7EYzoCuHt1iJmINZWBggKvBpl5VXIChw1sb7hNGBgaG/2uTrBluv/xAlOGEAMzlTBSbhGYozHFUNRgZjBo8avCowcPKYBYGBgaGH79+MyDTlACYGSwMDAwMj99/ZUCmKQEwMwB5bDpsktsCLgAAAABJRU5ErkJggg==',
    bmBack: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEwAAAADCAYAAAA5memSAAAAAXNSR0IArs4c6QAAAClJREFUKJFjZGBg+M8wCogGLAwMDAwd3toD7Y4hASq2XmVgGmhHDDUAAGCpBAeL6bs6AAAAAElFTkSuQmCC',
    artInventory: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFkAAAAeCAYAAABHVrJ7AAAAAXNSR0IArs4c6QAAApdJREFUaIHtmjtuwzAMhpUgB8jUjHZO0KFbzhL0Bl2aczRLcoKiV8gVumXIlDH2mEy+QbqEhmCTEinqUaD9AcOBaov0Z0oU5U7Oh/3d/CupZqUMXy+X/vdiuXReO68r8m9d00azk0rZIV8vl/5hF8tlD8FuBwHc3WZL9vf28W4MAltiJ7UmpaYLX4TN66qH+/L8RPZzPN2MecDGovo3RPII8ryuTNe0o3NOAWAX3KGOpxsJurTQSNYA1kZOCGCQBnTKiJ8OG7BI1jhpt0P/cGC2QwGbx7Sy22zJvjG7XL81mhorwWimCspBu53zwkIBS+63/eD4rdXUPDLzMHKlkWw7B4dEdqLTiopml0L9BlGj08ASjgIaO+n5+tJGsauflAnR5ga/bXszY0Uy1YHGQdeIyLkSoOzHeD6qHfqdui6UdMpR17T9UUIx7Iew8lZ8mEMa0CXW3T772sDx3e+ETMGQQBo6ULpYwOxrnscwQDshY28911BLoRj2Q0b25HzY3znGc5TY87oy359f6n5Wr+tsI8bHrmta3i4cBzBnIV9y6uDaTlGQjMrqoXwldsyytGtas3pdi++zFRrFoc/BseWEjFWAQ0nKUo5DGtBcwNrnAEGV57PJnpM5jtrGtdul0vk5xzxsV3NcZl3ThkM2QtA+YeUotLlgQ9Rj98WErmGk+vxEAaS2S7mw4To4u6aP0MJC6pNGUb7xYZkbS5aSqLav40akFDBmK8UKSA2Z2iCn5i3p9GHLBSOlv1p5l3ChkjoXO2mFJNpU6jftJWeNXH3EAp3ahpTXaNOe+joS8pXEJyz5hE4JFLxUKw0ur65p8c9P9pvQrHUpBw2SfFIIsxFrk0jCq9+0zxnJqRJMLhtSXsX+g+gv6QfKFWQRQy9nVwAAAABJRU5ErkJggg==',
    artEquipment: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFkAAAATCAYAAAD7yKGlAAAAAXNSR0IArs4c6QAAAbtJREFUWIXtmE3SgjAMhiPjAdixlN7Zq7jWWziugKU7buC3ChNCQt/y7ze+mzoYSvo0TQKn5+36oZ9WVUZE9K4qelfV3r78K0mm5zUfIlWE4NoVIfTsPduthPqOKuNJrIny8mKOqIN6Xuu0aMDSduvThfqOcJH3n6VRWzc9w7ZuKC8vvTGmMajWRh4pTaG+I1wk09Pzdv3IneAb9O6kgE7VkVIFIglYymLX1o2dk63wjwGeCkrft3dkI75bgGmEEVz4kEhmSHNA7RHJXHz1b09eJHvKrAk8WYAZKjsmHdTXvHFPaajIaRoLNIsfFMky1+ikb+38nGO/dbqwNpr95/+sdbd1A0fzIJIt5eXFfBBLg5kLCj0BS4xe+1iE0K2bHNBouhh0FzF5u/e6P2YXLp0Xtx5JpQ9rnSm5mLwWbqpe98cAFqIjdxdLcHFbuCmaWsQkWKSyf6N6OZkLnB5jmvOC4uXzWCvI/6/5+p26fo9bJg29Koo6wsUgpSikRm7qtxFUnu/I+mPcunThGcYab7Qx915Bra9wNAI/9dsI4oNnG1sXymuxwhdzxLq+tZboFlLVdRerPeEnIiL6A/65zOGMo5bjAAAAAElFTkSuQmCC',
    artQuest: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGcAAAAYCAYAAADnNePtAAAAAXNSR0IArs4c6QAAAfRJREFUaIHtWdGNwjAMdasbgA3oNyMgwSSIqZig6gos0EqMAL+wARtwHydXaeokduu0QZcnoaDgOvZznxvS4nG9fCAjSZQAAPe2A2rMWAYu/gtUzr3tYHc89GPGsqD4L6kfsnKWhYv/rJxEkJWTKILKSRkxbpZv6A4/AACbagsAAO/na+14RsDCaJJ5b7tk27dZi+JxvXxwAogCbartYM609UGj0DEKE8P3FE5sXm0/7+frTzm+Rd/P12CUBDynQBR5vjkKvmuxt89V0BRO7NGF0p4wk8UL12p33CJIYPpZq61RvFL5DYpzq5vecFNtRx8baO+C6zoptDcEGv44uVH8ULxiPLZ96XIUIh5/D9mBJX38rlG0JUDFy4mdy4+P99LngDvPKRDMfIatganxcvkJzY+eOdoLmbB7bYpbdxNT4tW8oYvH9fLh9OD9+cRyuD+fgjYmXAkv9T/Et45U2Vx+OHa74yGsHMnCEjtEqq0tRmEkdoAnBGDs+zXO2G51I1YQBe76dqxLnw9Kb0gTPt575Wgfftq7lSkJ7I4HdmtDW6m9FBp5mfDxHkU5CFRQSEnYQjBRKWkaKkEfIcWb+cwtDKylHEQokVvdqCSpCV9MmoWBAO/9bi2GcuYCFRTzlUEKObr4HyiHGjPiwsf7V7xs+6/4BRfm902ilSEhAAAAAElFTkSuQmCC',
    artCalendar: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFkAAAATCAYAAAD7yKGlAAAAAXNSR0IArs4c6QAAAdBJREFUWIXtWDF2wjAMdfJ6AKaucIMO3TgLjxuwwDlggRP09QpcoVuHTqzJ2ik3gElGUWRZsuPQvsdfeMSy9PWtyLGry/l0dU8UxcujCWgxW8wHz7qmfQgXKwYic8lwKJEgxMa+4dlxdxjYb/bboH1JfjHQ2D2RtU7AtnQlzRZzL+772+tgHMY2++0kXCy2mE8FPVlbATQYV0WhcQtAYE5ciu+f3yyhY7ylnCV/YFddzqcrfhhbMZhIHUnzrMlbBAakCq3hbcnVER27pr23C43AXEBN0JTWYhE4xd4ZeGvFpfPAvnYGgTmClsDSGPbHbXIaHHeHnp9YTA2seeJ5sDh1igNKgAKvfgpSqjJnnotwztWnTmYVACaqFTp3UXJ9pnC2YHSRY0itiv8cf3SRcRK4L0Hft2yYJThRHnQ/KsHJi4yDusTXhvvkwTstToj+xz6W61VSMsv1asBbiksFzzktSvr5T7iQGBbguVx1SAmWQmyhXaDSrZD084cRiczYkGLgqvr6+FT7xFXM+Zw6J/zr28VUAtNY3Jgztg1J4Fi8sSDp1+vJU77G0n0BFTokNoxpemrpTVbSr3d38RdAz/0A7SVO6Yq1omva+y3cE+VwA9ogmpgTSrjpAAAAAElFTkSuQmCC',
    cell1: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAfCAYAAACCox+xAAAA4klEQVRYhe2Y7RGDIAyGtecyztJVOg6rMAvj0F/pYQox5MPGu76/9DiSh1eI0WVRquRUS05VG2fVQrT3+/MljieeOHJBCiOadPYoNM6wATj7QbJvWOQQFFbKdQTPU4GUnCoXgAI6gyEHIYD2eEIMCmY4YAXBhXlYJLHQAQRWb+1GLyaOfQBxP/9Erg+IpxttjpErYfbI5rHyGUH+MI6EAdmk5dtKkD+MI9264XWEqTLfraxXCOf6v/Sw4vcjGAauZwFwDDFIC+DZs07p5118LxE1LnHg3l96I5grO7wvWf0NeAOW7+W3PTIhYAAAAABJRU5ErkJggg==',
    cell2: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAfCAYAAACCox+xAAAAx0lEQVRYhe1YwRGAIAxTz2WcxVUch1WYxXHwhYe1aEkB4c78OG0aYqvFYVBit8bt1jgtz6gVEa6XdYP54MCYC6gYKOjtUWicEQuQ1ANSNyLlntTvVOoIjVMhTIo6ou4qT4C2aBgHi1ETJHJN2iRFQJXncEPKfXGkeP9LcpV0Q5KjmRqZuZ2XcCPG7dfNONKMkBN/sT6hxguNYuJurgFxrv+jx6GJeYSKSRGETGj9zKxU0KdTPJfo6TriQN8nvZiYmhPeDbn+BhzKMxKmECbTJwAAAABJRU5ErkJggg==',
    cell3: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAfCAYAAACCox+xAAABJUlEQVRYhdWYPRKDIBCFl4x3sKb0Fum5Cp3nSMdV6L0FpXVOQYoMBjfAIqAhr9JBdj8e/wJUymhljVa2Ng6rhfDfJyGL4xVXjLlQClNUieqKGmeyAXLGQ8m4GXIBAD4tXdSc5QiulxL5gdHKYoCR82Sd57oCAMBdPjYgCiZZ6ALkAqSAKJhogQ9xFCAERMHcqjI01A7EDa6WbgC8u3RRs52EZH6OKMjp8z+RawPBbhitmrjhNHK+i+3n3IH8WkNoBWyxm8aEY7v3bhzpB2QSkuERfObsCeWahGTdOBJsOZ5mreRihhwPrqxXCOciN71WcCk3ADqaNVnnkVpXKDdIEB/GPR8FwDGKQXyAXKCSM+shnXmK7+Ze8983vRjMlSe8L7X6G/ACVvz1tFZVJskAAAAASUVORK5CYII=',
    cell4: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAaCAYAAACgoey0AAAA9UlEQVRIicWWPQ7DIAyFTZQ7ZGbkFtm5ClvP0Y2rZO8tMmbuKdKhcoWozY8B8aYgYX95NiADCHUe/j4Pf0vjlRQaro111XmqAziXEngxMFXa2tKvpVB09PKPpGOE5yqQLQ9CEbhpTe57XxcAAOzuqcI4ETiEckDqB0rgS08owLciXDtYMPZHCo3hxjoV5mTBw64EkfsH7uUWlXPN9ni0VurSt7zBoTat/3LheprjxVin4sb3PGRUbmOdmuaYdIYnu7XXmIOqIPmAjFCcm+1lq+uU2yS4BZ6DZsESeAm0CBzC8ZsDxnu7qPfoM23YmzbeitU60H8AZ7TokvVn2J4AAAAASUVORK5CYII=',
    cell5: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAaCAYAAACgoey0AAAAtklEQVRIieVW0RGAIAi1rmWapVUax1WcxXHsi844VEDJ7np/evDgoSjOKRGDTzH4pPVftEHz9X6cYh6xQ0mlJjg7YK200tI3swQyUNRSjO1VyINIFasvHjhKS5jb1/xWDpmkbKoS40x7+rTF9VBs1hI17pFqOZysM7bARikbobbEBetpim/85oxJWPQxxkoZW4DN3aN62Fst/SS4tiyS0d/iNwcBnMCrow8VgNqXKpw23qrRO9BfN7rzXSOvdyIAAAAASUVORK5CYII=',
    cell6: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAaCAYAAACgoey0AAAAvElEQVRIieWW0Q2AIAxE0biMs7iK47AKszAOftUAKa0tRUy8P9Te4xArzikVg08x+KStX7TQfLwfp9hHXNBKqYE/BlJLK116dpZgBom4xPXzKnAMPnFAagIUvHkDCrU7F2pb8FVjaqECDOl602IetVcBHvZJIN432DJt7tlKPe0dbxbJJALevMTSBtEr4E1LjH4+Vjub6l5oAxmh2vt/vfp7v8UcXhtywHzcrdePPhgAuy5NOO14q1bvgf4CLxXFsd7h7rQAAAAASUVORK5CYII=',
    cell7: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAYAAADEtGw7AAAAkElEQVQ4jWNkIAJc3zrlPzJf0zuHkRh9GIbAMLKh+MTQLSboOnSDCImR7FJclhPlckKuImQ4TvXEuJRsPaQYSrQecgwlqJcSQ3GaQQ1DsRnOCOOQlZvwGM5EDcPw2kDtoKCa4TRJGYMjg1AtS9O0EKJJsUmsy4l1KQs+wzW9cxivb53yH0bjEsMGiMrG5FSmAH7JVDWxfyVNAAAAAElFTkSuQmCC',
    cell8: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAYAAADEtGw7AAAAr0lEQVQ4jbWV0RGAIAhAoXOZZmmVxnEVZ3Ec+6JTBEQz7rouhAeJIIJDcoql/j6vGz1+HYSeGmrpeOBhdhKAw6U/AgBAafG8bswpFnpLCWg2tE2BG1MQC8ptaj9aPywHDeqxRa+hJTzzBrwK1eDuPZ2FD6u/Ct8G5NKdiq3gpd5X5P/ikfKX4/YVLjXIWzyp92eh5qyYgVu2zXSjiF/Gpiq7Bn3gilHm3kxdRVq5TB+CSia0boHxFwAAAABJRU5ErkJggg==',
    cell9: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAWCAYAAAAvg9c4AAAA4klEQVQ4ja2VMRLEIAgA8eb+kNrSX1zvV+x8x3V+Jb2/SJn6XuFVZhDRARNmMhMTWBAEDQjk2FPBa+eDkdg1gPpgYE6x5BSbb1RXFBUGVmMK5nZiuB/OB3PsqTgfTE6xbNY2jn/nCZ/wvXSo7Rsr11zNgAAAm7WQUyzYOQ7sxW1/BhyB2e1rgFhoKhroCnAEFuVQC55WeRXcJfkJ6ar/GFTdyxPpCnU3FZXRHalVMO4u9vBrwbRdr0JhoCbH2GbY+xrwSLeZUtUT510S4VC44YsnPL0R6HsXqSRiSYSigmgvvj9/sC9vfBMF6gAAAABJRU5ErkJggg==',
    cell10: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAqUlEQVQ4jaWTsRXDIAxET17CNaW3SO9V6JgjnVZxzxYuXWcKpVKeIEImL+oQ9w8BEhDEebCcB0ukGQIWtLnQsIcrF6lcxNvTIC+57ZkqF1lTAgC8rguP/CRPt9iFBwPAmhIqF7GapgKtwoNt2ErUhGbhkQn9AnsmnzeYhXttc4XZplHttmf6esQ7EwsDwNLD9osiWA8aNtJsrjmhb1dvNm5n4a9higxH8QYWG9BTw8yA/AAAAABJRU5ErkJggg==',
    cell11: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAbUlEQVQ4jWNgwAOub53y//rWKf/xqcGpAVkjshheA9E1YzMQ3QBGbIKa3jmM17dO+a/pnQOXh4mhq8NpMzGuw6uAGC+SpBmnWlI0YzOEiVhNpDmLHLVUDURSopE6CQmfLcS4DsUAijITPgNxAQAt/ttJbJU/owAAAABJRU5ErkJggg==',
    cell12: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAdklEQVQ4jaWT0RHAIAhDhW06S1fpOK7iLI5jv7iLFLAKf+aSh6KWElRvdfRWR+RxAxhELQTqsAXUALLE637or8a48IzSBD3TDtCwGpp4BEI7YQtCu2EN4bU1rvwRRDwdIuswXlEUlkbphzR1OHnKH0DqM0VAr16hpcRTXPkEagAAAABJRU5ErkJggg==',
    iconsAtlas: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAAAXNSR0IArs4c6QAACKlJREFUeJztXT1oHEcU/kZWYSxjAk4UuTKJZcdExVlRIYWIBFkWGEwqFSoSTEiZJoEgLETKYCzUJI1LFyIpVLgyAoN+TIxMTmD9HEHGP2cHV6c4NgQhhxSSN4VvVnOzMztvZmdPq/V+sHCzO2/27r15b2a+N7vHAATY32B7/QWSoBUA/vzxVyfh9374AgCwOtLvJN89vQgAmJ0vO8kPDfaZqvDOZWskXafUtnP90ohVRx6emGbgBgCA2vKmjTyO9RxpKN97sGUl/+EHhxvKj6pVK/mTnZ2mKkEQvNYJYyywNQKX5WDMLM6VaoJorBabL7WPEIgKrH/OZKjNowECufciw0ZoJdTZT1AqX7hoCkcmA8WOKbbjAHJogMTQGVAYT7zeL48haF8hdx4wt7AEADh3tld5PmsoPEBCnKHSMGLuPIAvzuRYTli0hZhbWGqaB+XNA5hhwWW8zg0lKpx/rl8jj8LDE9PMtDjLnQdwJOixbGiwL5idLze0Yat8KvLmAb7AxJCVlvIheoDM7dhC5nZsQeB2rGAT8zVgQ4N9rmQe/SZZXJ5bYl/T0UUI2mO0AsDaw5+dhM+c+hZ4zYE4yQ9PTAMA/n7xl5P8O0ffdZLLEsIx4P4/v1sJnn7r44bycuWZlXxPqb2hPF+2m7UM9vXGXZbDqmuY8tWOFnmchjYwoknJM6ktLZOaOCOWE+joaFOKkaQ8E50tL7q4UXTnkTMDxCViIpA9Iy6PINdzSXHqkBcDxCZiUriZ0gi6MBQXnopp6B4jNwZoJt/v8155CUFAQhpZVy9tWjovHqCkkX3DlZaOQ548II5GNkJXT961Z6N8Pv18kwZhplEk0xzU64Cj8uXPMvLkARwijZwYkkG1ijRlvnTXQwPI3I4tZG7HFgZuxxa+OJvUqe4iH7DHyNsYsO/QCgAbv33nJNzx2U8AgF8eP3KS//LESQDAlQtdTvJjM+tOcnsFeTY0PDHNwjHg38cVq8YOnSg1lFef/mcl3338YEP5/lO7SHL6uN/ISaWTXZ4BiEMeZ0FwecIFknLHzw8EqonF9UsjgckINrmBvBog8tgUfxzKB+KMYJuYKQZhR6gUXTwfIID3eJsHCMfPDzgPLDrly2GNf75881YuU5IcVqlGDlXMl0ONbmxQQZTlYUsOX3kOQQHv/a7xnzrjMcnqlI+cGwBtpRa0lcKfuCcr5jjlI8chCABwavy21/ZsxwiT8pF3D1gd6Xd+il8GV75ubaCqb1I+8u4BNrGfK0s8J/d4UfmU8YGyaMuzAaxjvmwE3WyHOjhT6oUGkLkdW8jcji18czuuUHmCfJ3SDp/nm1DkAwq82Sh6jwYq7t5FTobcThoGMIW0zBo9aU6ASlWLdWzfGmJSXjA7X47sJuOYW1iy2drh8nBEnExse677+0V5fk63YOMDs1hX9aOC2voNsOfzjSffHsSxrs91MjApn8PCCMGTawMAgPe/vkWpDwDBw8uf4mXlFbC7DmAiL9RWauEr5AauhtB2BOLGK1H5uunrcuVZxAjySjhUfu3q3YaDPZ9Hbf0GNN5BUj7qey3ru81SmX29rLzCvQdbuPdgi6+Cg9WR/vAcN04aMDGlPaX2iHdEFmJc+W2lFhz55CMAwOadFdSu3sWxb/Q358oX31ai+0wxlA9wI9i+z84VFJq6p9QO3NwtK1fCXPmbd1YAoG6IFY9ftXlolvJdETFA3O4Iys4JsXfrPhfYhZYN3byzgtaOA2jtOBB6QhxstoVT6x46UbKlSFj39CLWttS0yNrWQXFgzgQiHrC9sYPWjgPY3tjB9sbObsX6OQ3CreFiT9c9MEGdivKNX5Zgk9VyMNrZhzOHd/cqrW0dxGS1bLyvnMnSnfMF2QPYqfHboRHEY3tjJzJ9k2WHBvswt7AUHuLOYukcqQc+uTYAPhW1BJuslkNPoCo/KSirZepK2HUhFpENgkA2BlUJLuuASBujnX1G5SddB0BaC5h2SJgWYj4RzM6XXR/p8fm6AVLyxKZRVW/3SUX4Qurv2/EJHQFnQ8zZknEFCrzZKNxBEzbiXrChq+MCr0n5Kxe6SAPZ2Mw6+Yvr2hTbEOuY2qbW9T3f14FiANIsgqp8XpdiBJs2eXsmGWo9MTlvStQngckAQf/FSSxOjZJfz2LTA33Us5WhGr9ZMO6MO9ptt10lTglpKX9sZp2l4YGUN98mRZwHBP0XJwEAFC8QlaD6gdTY69Lz00AmxoDer87vFqbMjemMQFE+r2Pbm31AlcuVkyviSwmpm64o0HJB3y/8ERaqlRperFawODUaJxOCMnOJkzEZIa0Y7vtJSQqMs6BqpQbwsYDgBdAo0KQ0lfeojGDyIFV7Lt+nWdAOwtVKLVS+LeQxgBpW5Lm9rKSsKM0ntAZ4sVqJLacBWelimaL8sZl1Jhs+rpwF6EIQW5waDfoxGZ6gxn8RLiteOfzYzNtFL1N5XFZmWCLixgBWn3qGZZuGXX+s2OP3YjbUbDo5U+6YFL64KMozvwUKFPCBwqWISCsfkOpjqlcudAVZnHnYIk1eiJoP0MGbB8WtVH2sYm2SNiLSJuVIGTHVm8nj/hhBVphICVC/WBwdYQMbjklGMxhRkgFEZddf3a6tq2JBxbKPdKSLfBaVD8kAxhvyXW51RBSp4oDka83KSOmUT7k3Rfm+1gQNg3AQBJFDvCZtMYyEGUo60pbldK0n1qf0/OuXRgJ+mP6QyOeCrMEAjLHwgBB6uCHOne2NGMYnKJQ1pR0dDU2V7ym1a/8VyvdqWDRA2LAUahoMIxpIhaQkmIqxdGExXZXPoTJCGlSEaIAA6lAD6tvFVfBByrnIi15ATcDL50QjpMUDNcyC5FADh//hiou5zRp8be/DB93lyrNILrin1J4qCacdA0yhRoZppuE6FbWBj7Zt/xEwKUQPSKwUcZqpUkTaU9CkbfPen+ZOOBmp9UTV+aylAwsUwP//n0lvqr1YZgAAAABJRU5ErkJggg==',
    dlgPaper: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOwAAAB9CAYAAACh6Y/yAAAAAXNSR0IArs4c6QAABe9JREFUeJzt3Tty1EoYhuFvgMSmypEXQAIhK3BIRsgqXIQUq6AIXayCkOyErOCEOPECJnIVMxFlApCRZanVN0n9d79PZDzMWLfXLWnk0U4AnE5Oz+9yvM7xsN+lvkbyCwA1yxVrJzVagkXxckeztZRoCRZFqy3WTmy0BAtvtcazlZhoCRZeiHUZodEmB1vbipxagLXNJ8J8//I+6fkXl1fBzxnbFpOCrXUjHi6oWucTflJj7eSINjrY2jfibkHVPp9W5Iom1fMfX++//vnqXfDzU6N9EvxstbERn5ye37UwnxaUGGv37+H3ltDfDp+lPBntKSWetbnC7B6LGXF9nZye3x0P+13QLjGxto1Y/+jCHIvYJ9qY3eKOd7CuWP//71P0BJTk9ZuPzsdrmU+43V7f3H89FWufz/8JNRV11DFsX00bcU3zgnhnL19I8g8x965w9/PHTAbbnXRp7eQL0UJ6HM2Sx6eunzs0GmxLgY4hWkjS07cf9PPVu9lYc50pnotVGgm29Vg7RAtpPqJcx68+sUqDYENjrf2sIdFCmo5p7VilXrDEOo5oIT2OaotYpb/BEqsb0UIKP3vs+3ohnrlibS1MF6KFtG2skuNtHWJFa359+6xf3z47H+9bO1Yp4lriof5VIUMpEwasyRXq2ONP337Q2ZITNCE52ClTsboCR72G20NJ28FwN3c4baO7wYHTn2vwSr40cQwjK6yYOyZd4jrhFNlHWN9YibptJaz/ud3cHLvBufckso6wJawEwMdYjCGPbyVbsMQKK6zGKmUKllhhheVYpQzBEiussB6rtNBZYqA0NcQqESwaUEusEsGiMZZjlQgWjekHai1WyRFsykcxAiUbu8i/pFhdF1s8cd09i2hRg7kYrcQq/R1hU2/jDpRuKkpLsUoL/rUOUJqS4hzqx+ras+WkE7Ax31iPh/2OYIEN+cYq/fnsNXaJgQXNXbrbf7z/uWFT93lihAUMIVhgQbfXN1n/iH022IvLK96PBQpxHyzvxQLlezDCEi1QNo5hAUMIFiiM8+L/9SYDwByvi/8BbM/n7R+CBQrAxf+AEYtc/M/FE0B+IbFKIyMsn0ABrM8nVmlil5gLKID1+MYqcQwLbCokVolggSJN7eUSLGAIwQKGECxgCMEChhAsYAjBAoYQLFCgk9Pzu7HvBwfL5YlAHrfXN/r+5f3k42PRTgbre01xzo9wBFoUEq1zhCVaYB2+0c7uEhMtsA6faL2OYYkWWIcrWingpBPRAtvzDnbqNHOHaIHlJd9usn+LPADL4sIJwBCCBQwhWMAQggUMIVjAEIIFDCFYwBCCBQwhWMAQggUMIVigIHOf6EKwQCGibjcJoCyzt5sEUCaCBQwhWMAQggUMSf7EiVilfYzM2csXD/5d2vSBdSRtGCxQq+EvlpxWD3bJmcnJynS2rMV1xDEssIHY3XmCBVaWcuy9arAtniQA+lIbWH2EJVq0yrXt+97GdZNdYqJtW4vrPzbW4S1yNjuGbXGl4Z+W1n/svI7dz2rTk04trTQ81sL6zz2PycGmTlALKw0PtXLjtCXmLcuFE0SLUBeXV/f3Qs21/lMvpLCwHfI+LDbje2bUl4XghkKXQXKwuRc62tJytCFnhzuTd1UfM3dT57nbvWMevwDj9be/mN3j128+ZpyaeFOxSoEjrOuFJDa2VCy/NDWczJprLPik0/Gw382NtJYRjW3Dk1mW/qJnLlYp8hjW54UtItY6WBxpfZsq9g/YiQcpLI20IQNg9rd1coRGrPU7Hva7pffULIy0ocsgaYHVfCy7pVoPOZbk2hZ9zx5PnSUuaX0kjbAlzUgtWKZxXMvNwkjrK8vGUdtISzR2pYy01Y+wnZJmKFVN89Ki2kfarBtn7pGWeBArZqRtZoTt5JyxkhYS7Kl1pCUKVC1kpG1uhAVKU9tIS7Conm+0FhAsmlBLtMXsmwNriHkno6Rj2GImBFhLSLQlxSoRLBrlE21psUoEi4a5oi0xVolg0bixaEuNVSJY4EG0JccqSb8Bl5rfZpimIjsAAAAASUVORK5CYII=',
    dlgPaper2: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOwAAAB9CAYAAACh6Y/yAAAAAXNSR0IArs4c6QAABc5JREFUeJzt3T9y1EgUgPE3ZhN7qxz5ACQQcgKHmxFyChchtaegCF2cgpCMkBMQrhMfYCJXMRNtmQBky7L6f0t6r/v7RcCsZ0aj/rYljSztBIDX6dnFfY3nOR72u9LnKH4CoGW1Yh2URkuwUK92NFsriZZgoVprsQ5yoyVYRGs1nq3kREuwiEKsy0iNtjjY1lak6wNsbTmR5vvn90U/f3l1nfwzc2OxKNhWB/H0g2p1ORGnNNZBjWizg219EA8fVOvLaUWtaLZWGu1Jzov2MIhPzy7ue1hOC1qJNdd4HP5V8sPoT+/xDP7+78vDn3++frf4652eXdwfD/td0iYxsfaNWH8bxzoWG27OZvEgOlhfrD++fcx+A5q8+edf7+OtLCf87m5unY+5Yh2rMeO6os7ahx1raRC3tCzId/7q5ey/T2P9+frdbJwxUee8vogn2OGgS28HX4gWIs+jmYt1/OdpuLnR+mIVcQTbU6BziBYij/H4Yo3599TX83kWbO+xDogWIs8jWuqIcEysIpNgU2Nt/agh0UJE5MXbD8791bGlNoPHHoIl1nlEC5FwVLGbzanPO3UiQqwhRAuRtKPHJc/ns/PFGhNmzosClo2/p10qVtc5Ac6vdXqbRYFYqUePXT+fI/lc4infWSHMvmjVNNYXbz/I+QqvWxysiytWX+Bo13Q8aB4HQ4yuGXN2Zg0sT63Jq/jUxDnMrLAq9NVM7mZwLdVn2NhYibpvGtf//18/Pfn79D1OH4/ZDK69JVF1htW4EoAYczGmPL6WasESK6yyEqtIpWCJFVZZilWkQrDECqusxSqy0FFiQDuLsYoQLDpkNVYRgkVnLMcqQrDoiPVYRTzBllyKEdBOc6y+ky1OfHfPIlq0ahyolVhF/pyaeDzsvb8XC7RoGqqI7lhF2IdFR0IxaonVt2VLsOiKK0oLsR4P+91ivw8LaKXp6G9srCK/r71GsMCCQqfujh8fX+wv+ZpOAPQhWGBBdze3VX+JPRjs5dU138cCSjwE6zuBAoAOT2ZYogV0Yx8WMIRgAWW8J/+v9zYAhISOKBMsoAQn/wNGcPI/YETKyf/RwXLyBFBfSqwiMzMsV6AA1hcTq4hjk5gTKID1xMYqwj4ssKmUWEUIFlDJtZVLsIAhBAsYQrCAIQQLGEKwgCEECxhCsIBCrlvnJAfL6YlAHXc3t/L983vn43PROoONPae45iUcgR6lROudYYkWWEdstMFNYqIF1hETbdQ+LNEC6/BFK5Jw0Iloge1FBxu6QzvRAssrvt3k+BZ5AJbFiROAIQQLGEKwgCEECxhCsIAhBAsYQrCAIQQLGEKwgCEECxhCsIAioSu6ECxggPN2kwD0IljAEIIFDCFYwBCCBQwpvuJELm2XkTl/9fLJ37W9P7S/jmIu0r9ZsECrpv9jKTW+AOLqwdZemKVYeZ8963EdsQ8LbCB3c55ggZWV7HuvGmxrBwmAVKUNrD7DEi165Rv7sbdx3WSTmGj71uP6z13m6S1yNtuH7XGl4VFP67/msm560KmnlYbnelj/tZexONjSN9TDSsNTvdw4bYllq3LixNbRln6B3vKg0ery6vrhXqh8/vG6/x6WwbKd2COjeFQcrOUPnVi3Z3n81JLyGTjvqj4ndFPn0O3el5KzSaw1VgYwBtOvdEQSZ9i5JxizMtiIFdq5Wks+6HQ87HehmVazUKxEg635JsasfdjQTKsVsUK7UFtqf4E9JZ4f3z4G/5txrIQJjWImwupf69SIoXZQxKrP8bDfWd1SW0LsZ1H0gWnZl/XNsBZjZSDDpWiG1T6wiBWtKd6H1XrUuCRWooFWVfZhtQ1wYkWrqh0lXmKmncYT8/yxsRImLKp6lLhmBDnPRaxoXfXvYbeKgVjRgyZ+vY5Y0Ysmgh0QK1rXTLDEih6YGsg5R6GJFS0xN5hToiVWtMbkgI6JlljRIrOD2hctsaJVpgf2XLTEipaZH9zjaIkVrfsFkLvK1mRLhVYAAAAASUVORK5CYII=',
    dlgBox: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAAMCAYAAAA6cw7iAAAAAXNSR0IArs4c6QAAAFNJREFUSIljZGBg+M8wAgELAwMDQ4e39kC7g66gYutViMcZGBgYbjxkHFjX0AloyEMSONNAO2SgwKjHRxoY9fhIA6MeH2kAXo/D6reRAhhHapMVANJ0CWHI1NQIAAAAAElFTkSuQmCC',
    todFrame: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEwAAAAfCAYAAABNjStyAAAAAXNSR0IArs4c6QAAArVJREFUaIHtmTFr4zAUx/8Ouf063ZISOpS0F0Og5BsYjoCh0y3ZMmboavDcyZD1ho7ZvHQKGLrkQwSUXqBDCZluavcWdEP8FMlRdKnr9BSnPzCN9SJFfv7r6enVQXngBptTVJ/q2+ZkN6N+Z63t8uau0D6lctj9YrHzPpU3/8IeECbTbBPfcJn6aCmVwsJkip7rol1rKO26ZYfM0mvXGpjNHQwZM/6GzmGmQGg1kd8EwHFWVx9rm2X3s1UFwBHVm0a1aRVGb+Ty5k58vl8sECbTjW/rfyOrJfvAs7kD9vySOgW4nbzC/fpl7btLh5vRbZ2cOs7mDs7qK8Fl722BXmSeoK/j+/Gxbqdc85UIhpHf5AB4u9YQn+mvjdeo3+GR3xRX3nHkMUb9DgfAg9hTNghlSQaxh0F3DBjk+Tv5VchbLIpz/0pRFgX+PIQJE8+9Sa25dsk/j4+5JlQ0305OgDRUAMCQsdzOAoCe6yJM1DFIQKSyqiw3Mm6bk9iCiKvmjCDXeEHsifZBd7xUmNwIyXFy8N/jbKNQtJl+1oGfrCjl0ahIJg9Pyn3FZEQaz9jzy+5nZimt0yNgFaacKgBn0B3zIPbQOj3C5OFJfAlbZr9lRtolHUhphTPojldR/foCsDiz/0gonqf+cWhJ8iD2EMQeflxfKAo7dChMpY7jFXIWGWVnHbq6IMUwomIyIg36t5PX3c9sT/hnWhH5TVEK+WTDWVLaGQ6erC+qukZCKa7V7U0v6PC9i/GkCo5IK8jKyZjNvWw/jNPmtCwv569YDBkTZW5Af5jPVd6hsootyPli5C+dlgdZKKQy7ZIkZGOYTNGuNUQdnDj3r3JNZpcMGUMPruK09yD992htrZeipg+p0vre+ZmchU1LUqlgYhUPsvc20XPdQuZncpbJYKeMPoZit9xD5y8uUGxWq9zhAwAAAABJRU5ErkJggg==',
    todDay: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAAYVJREFUOI2dkz9Lw0Achp/EDFJcQxEECacOEog26CdwEAe3TjrZQcHBDnbTSZ1cdBB0aCY3hxaH0sFPUGhroDhEQxEEKd2LQ/84lItJagv6Lrkc7/v83js4BeDefx3wD+2KRUWR4Y2PG/ZrW9ylSgDBer+29Ws4vW0AoNz7r4P6+xcAuak8Hd8FICEsLnuZiQ1W56fRAN7cT+5SJTq+S0JYAHR8l5zIj20wBBhDwII1O9Ykq8YlW6ty47KXISEsOr4bNHmaO5wYjgByU/kAIsMbHzdBwK0c4FYOqL9/obayqK0sxC9xnKQZwBY6AFW/jbV++9MgTFVbWdZmLiZC+8mr6BHCIFvoVP32CCQ8PRgWJvaTV4FJQqRR7sfXqtkr8Xi7EzmCVLHQjkyNtzF7pWEDw9SwhU6x8GNyyh6GqeGUPWyhYwsdp+zhlL0ISANoNrqcNl44O14Ows1GF8PUaDa6OIz+720uAaA8e9cDgPRJHtlGKhyKfx/Oh+9EAZCQv2pl6Uj5BhO+uZolIOL2AAAAAElFTkSuQmCC',
    todSunset: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAAaJJREFUOI2dkz9LA0EQxX+XHDkwZ0TUkMJCEDy4JhjTaEALsfEjiK2CjYillZUWgmg6wTrfwVJBg5ATDkFIIGCR4lCOkGCil1yMRbKr558UTjMzu/PevBl2FQDncqfLPyyxdKIoAly/vqNSc5kcGQOQcaXm/go2V1cAUJzLnW6zbAPgOx0a9jsA0WQINREeqGBoOokK8Fh8YnJkjIb9TjQZAujFfSV/mTlNj2DKiOM7nYFSv5tQrYoDNREm2u8sRohlUgPBAQLf6UgSgFgmRf36jlgmRbNsk89WAZjfHpXx8imEvioQXk2EaZZt6QUAoHbRxjR0mUuCfLYqC/PZKrWL9u+b69v89miQ4CuRaeg8FF9+kIjOD8UX2UzuQDAKkCChGAQH7oDw5kxkf+OoTvz+lcrtGxPjEVl4WGqzPqvz7LZ4dluBu4nxCN2W0xshrWmYhs65q8iCnOWT1jRylo9p6JiGTs7yyVl+YCwVoOB5FG48jheiElzwPNKaRsHzwOJHvjanfi7xbGsYgN2bhuwgiv/y4skrAKWDxX9955m9K+UDCjrAyPQ83jMAAAAASUVORK5CYII=',
    todNight: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAAWJJREFUOI2dkL1OAkEUhb8lxMLK1mKACMsuJDZUAoVBswRDKHgHGn0IDZ2NLTS8A4UhMRCkQqwsEQUSYAregQYLnMn+iImeZubOPefce8YAqDcbW/6Bu+sbw1Dip8cuAKVKUd9/Q6lSBMCoNxvb8XQZINTKVVqdtq7TZhQ/L21GCQOsJh+ByVNrRq1c5fbhHsXxQxtEbIvxdEnEtgA4t04Dq/qhtgn7157OZgCYicTe/O4oHoNWp02tXNX1y+ebFsyHIwDi+ay+6wh+Ez+UAGCzWiNEDCkXAITcJEWcD0dsVmvSZnRvjHg+G4ygxHpCHw4ix7onRAxg15MLbwTluFmtNVkR3WJPDwjlkhlODo88ERQc58o71QUhYuSSmd0GQgiEiGHbKSaT929xEdXr9bqeN1XrT5RSBsRSSlTPcYrYdspTKxi9/usW4Hkw0BMVpJQIIX48LwqFnQGAMvkrnMsz4wvVGKjNU/kTvQAAAABJRU5ErkJggg==',
    compassRose: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAApCAYAAABHomvIAAAAAXNSR0IArs4c6QAAAWdJREFUWIXlmLsNhDAMhp3TDcYOFLcEHQUzUNCxBAU7sFmuOSMrysN2HF0k/opHCF/8ygPASNc++9y9Vi+LTlBWUFSmgMO0OWtIU0BoAGkOCD/IFv0+Qy0SxUwI1yVkCHUun/7qYAt1D/iWNKZupKUkFXPn8vHjejh6j9f0eU5qC3ITAqG0MVnlYm621iSMCNBqhuC6FwBA9cOY5WLwMctJ4EDj4hIcfR+DkbpbNBoJHH1eY0l37bMPf8IpITk4LmQKlvaVrYMhbK5d6fucxcJ6CWRwdwzG5tIaOO57hI/taa599skkGdfDcQK6NAjuIMN2w7S5YdrcTU6X6prYkSRQaRC0rSiLS9komau5RV9cqDmQVnAqQA6kFRxYWRBVikmUBFI01Vkt4yV7lqrlFne6qlkFqQERrgSJcH/fzIfu7/J0q4W6BzRV1ycLqK7hWsg09VOLhW7Uwr3PsiDK0pKiw6OSWrj4C6dLFK5eooKMAAAAAElFTkSuQmCC',
    compassAlt: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABMCAYAAADdq7GlAAAAAXNSR0IArs4c6QAAAYBJREFUeJztm8sNwjAQRA3iTA1cqCAFUQqiFAqiAi7UQANwQJYgkpXgePcZdt6Jj8OuxhPb65iUnLmcj4/L+fio/b41a69AvYIJ4N3TJcI7YEMFHg6nVUovJ7y/9ya8AyQAnQANNgZkxmOBN+Ed0I0Aw+G0ImaCbgQQIih0TRB+DEDW3ymV533vmUAO8A449373coIc4BWodqS3dkJ4B+BoHQCjdYBnsB6RAHQCNLgA2/0ubfc7LD4uAI0EoBOgwavBfP/fr7ePdqoGncCrwZIDMqoGjTF3QO75Uk/P/dzKCeEdYPZ0eNzzteTrrU6ShHdAMzVrd3WmZoEpljpCDpjbsPW+XWlsqHVCiSmHyAH5xdJ7mKbWOXLA3IYaA/4UrQOWXPwPmFWDpVrg22pwfJ1qgcaYVYPjM8C16wXtBxijPUHLH/8F9FzAI0jPSAA6ARr8jJDX/n+J8A7A/zXWuv7/lvAOkAB0AuHRWWEYCUAnQCMB6ARoJACdAI0EoBOgeQLABLC4jsxO4gAAAABJRU5ErkJggg==',
    goldFrame: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD8AAAAQCAYAAAChpac8AAAAAXNSR0IArs4c6QAAAVZJREFUSIndlz9rwkAYxp80txU6dYiTmxQMFEq3QhdH8Ts4+wkkH6D4CZz9DuKYRcgmgUICRXBwSoZMGZwS7JDc+d4lDjUFc/lN7/2DPM+9793FgN6cmyxm//cd92ExHt60br4J9RcPAD9HQ8SrIKidM7VtEb/0i4RhTVOnTayCAFG4hpG4Uv/5eYTecCIZAJ72t6bOvZlvQhFfEw4ARuIiCtcVA0Ta09TRDVV4tNxJ473Zu2TAol9stlTzvBZQmtH2NoUKf3x9wNPHGwAg9XxEy50wgNKJA4/ChaeeDwClCX7t3M6IPx2+/zzeGfGU1PPBLFPE15DEq3XU9jYli3MwywSzTGRxjizOxRg3gvaBiqeHiTaU75mpbWPgbLH/+hQGqGRxjoGzLa+6yyNHui91RTWAIgu/wADoe8Err1NuQB2qcHTlwKMlyx8wVaplrfOuo+l/yS/eq60HBRNuVQAAAABJRU5ErkJggg=='
  };

  // ---------- CSS VAR INJECTION -------------------------------------------
  function injectCssVars() {
    const root = document.documentElement;
    const pairs = [
      ['--img-hb-back', HV_UI.IMG.hbBack],
      ['--img-hb-heart', HV_UI.IMG.hbHeart],
      ['--img-hb-fill-red', HV_UI.IMG.hbFillRed],
      ['--img-hb-fill-blue', HV_UI.IMG.hbFillBlue],
      ['--img-hb-fill-purple', HV_UI.IMG.hbFillPurple],
      ['--img-hb-bush', HV_UI.IMG.hbBush],
      ['--img-icon-heart-red', HV_UI.IMG.iconHeartRed],
      ['--img-icon-heart-blue', HV_UI.IMG.iconHeartBlue],
      ['--img-icon-heart-purple', HV_UI.IMG.iconHeartPurple],
      ['--img-book-f1', HV_UI.IMG.bookF1],
      ['--img-book-f2', HV_UI.IMG.bookF2],
      ['--img-book-f3', HV_UI.IMG.bookF3],
      ['--img-book-f4', HV_UI.IMG.bookF4],
      ['--img-book-f5', HV_UI.IMG.bookF5],
      ['--img-book-f6', HV_UI.IMG.bookF6],
      ['--img-book-f7', HV_UI.IMG.bookF7],
      ['--img-book-page1', HV_UI.IMG.bookPage1],
      ['--img-book-page2', HV_UI.IMG.bookPage2],
      ['--img-book-page3', HV_UI.IMG.bookPage3],
      ['--img-book-page4', HV_UI.IMG.bookPage4],
      ['--img-tb-body', HV_UI.IMG.tbBody],
      ['--img-tb-chooser', HV_UI.IMG.tbChooser],
      ['--img-tb-chooser-back', HV_UI.IMG.tbChooserBack],
      ['--img-tb-num1', HV_UI.IMG.tbNum1],
      ['--img-tb-num2', HV_UI.IMG.tbNum2],
      ['--img-tb-num3', HV_UI.IMG.tbNum3],
      ['--img-tb-num4', HV_UI.IMG.tbNum4],
      ['--img-tb-num5', HV_UI.IMG.tbNum5],
      ['--img-tb-num6', HV_UI.IMG.tbNum6],
      ['--img-tb-num7', HV_UI.IMG.tbNum7],
      ['--img-tb-num8', HV_UI.IMG.tbNum8],
      ['--img-tb-num9', HV_UI.IMG.tbNum9],
      ['--img-portrait-mc', HV_UI.IMG.portraitMc],
      ['--img-portrait-1', HV_UI.IMG.portrait1],
      ['--img-portrait-2', HV_UI.IMG.portrait2],
      ['--img-portrait-3', HV_UI.IMG.portrait3],
      ['--img-portrait-4', HV_UI.IMG.portrait4],
      ['--img-portrait-5', HV_UI.IMG.portrait5],
      ['--img-portrait-6', HV_UI.IMG.portrait6],
      ['--img-portrait-7', HV_UI.IMG.portrait7],
      ['--img-portrait-8', HV_UI.IMG.portrait8],
      ['--img-bm-tab1', HV_UI.IMG.bmTab1],
      ['--img-bm-tab2', HV_UI.IMG.bmTab2],
      ['--img-bm-tab3', HV_UI.IMG.bmTab3],
      ['--img-bm-back', HV_UI.IMG.bmBack],
      ['--img-art-inventory', HV_UI.IMG.artInventory],
      ['--img-art-equipment', HV_UI.IMG.artEquipment],
      ['--img-art-quest', HV_UI.IMG.artQuest],
      ['--img-art-calendar', HV_UI.IMG.artCalendar],
      ['--img-cell1', HV_UI.IMG.cell1],
      ['--img-cell2', HV_UI.IMG.cell2],
      ['--img-cell3', HV_UI.IMG.cell3],
      ['--img-cell4', HV_UI.IMG.cell4],
      ['--img-cell5', HV_UI.IMG.cell5],
      ['--img-cell6', HV_UI.IMG.cell6],
      ['--img-cell7', HV_UI.IMG.cell7],
      ['--img-cell8', HV_UI.IMG.cell8],
      ['--img-cell9', HV_UI.IMG.cell9],
      ['--img-cell10', HV_UI.IMG.cell10],
      ['--img-cell11', HV_UI.IMG.cell11],
      ['--img-cell12', HV_UI.IMG.cell12],
      ['--img-icons-atlas', HV_UI.IMG.iconsAtlas],
      ['--img-dlg-paper', HV_UI.IMG.dlgPaper],
      ['--img-dlg-paper2', HV_UI.IMG.dlgPaper2],
      ['--img-dlg-box', HV_UI.IMG.dlgBox],
      ['--img-tod-frame', HV_UI.IMG.todFrame],
      ['--img-tod-day', HV_UI.IMG.todDay],
      ['--img-tod-sunset', HV_UI.IMG.todSunset],
      ['--img-tod-night', HV_UI.IMG.todNight],
      ['--img-compass-rose', HV_UI.IMG.compassRose],
      ['--img-compass-alt', HV_UI.IMG.compassAlt],
      ['--img-gold-frame', HV_UI.IMG.goldFrame]
    ];
    for (const [v, b64] of pairs) {
      root.style.setProperty(v, "url('" + b64 + "')");
    }
  }

  // ---------- ITEM REGISTRY -----------------------------------------------
  // iconKey is a key into HV_UI.IMG, resolved at render time.
  const ITEMS = HV_UI.ITEMS = {
    potion_minor:  { id:'potion_minor',  name:'Minor Healing Potion', flavor:'Tastes like wet leaves.', stack:99, value:10, iconKey:'cell3',  use: s => s.health = Math.min(s.maxHealth, s.health + 30) },
    potion_major:  { id:'potion_major',  name:'Major Healing Potion', flavor:'Glows faintly when shaken.', stack:99, value:35, iconKey:'cell4',  use: s => s.health = Math.min(s.maxHealth, s.health + 70) },
    bread:         { id:'bread',         name:'Stale Bread',          flavor:'Better than nothing.', stack:99, value:3,  iconKey:'cell5',  use: s => s.health = Math.min(s.maxHealth, s.health + 8) },
    salt_reed:     { id:'salt_reed',     name:'Salt Reed',            flavor:'Cut from the marsh edge.', stack:1,  value:0,  iconKey:'cell6' },
    censer:        { id:'censer',        name:'Cathedral Censer',     flavor:'The smoke remembers a hymn.', stack:1, value:0, iconKey:'cell7' },
    forest_gem:    { id:'forest_gem',    name:'Forest Gem',           flavor:'Smoke-purple, hot to the touch.', stack:99, value:25, iconKey:'cell8' },
    sword_iron:    { id:'sword_iron',    name:'Iron Sword',           flavor:'Standard issue. Reliable.',     slot:'weapon', value:50,  iconKey:'cell9',  stats:{ dmg: 4 } },
    sword_silver:  { id:'sword_silver',  name:'Silver Edge',          flavor:'Sings against the undead.',     slot:'weapon', value:140, iconKey:'cell10', stats:{ dmg: 7, crit: 0.04 } },
    dagger_swift:  { id:'dagger_swift',  name:'Swift Dagger',         flavor:'Light. Mean.',                  slot:'weapon', value:90,  iconKey:'cell11', stats:{ dmg: 3, speed: 0.6 } },
    hammer_warden: { id:'hammer_warden', name:"Warden's Maul",        flavor:'Heavy as the law it broke.',    slot:'weapon', value:220, iconKey:'cell12', stats:{ dmg: 12 } },
    armor_cloth:   { id:'armor_cloth',   name:'Patched Cloak',        flavor:'Mostly thread.',                slot:'armor',  value:35,  iconKey:'cell3',  stats:{ def: 2, hp: 10 } },
    armor_chain:   { id:'armor_chain',   name:'Chainmail',            flavor:'Cool. Heavy.',                  slot:'armor',  value:120, iconKey:'cell4',  stats:{ def: 5, hp: 25 } },
    armor_plate:   { id:'armor_plate',   name:'Templar Plate',        flavor:'Bears the watch sigil.',        slot:'armor',  value:280, iconKey:'cell5',  stats:{ def: 10, hp: 50, speed: -0.4 } },
    helm_hood:     { id:'helm_hood',     name:'Drifter Hood',         flavor:'You vanish in it.',             slot:'head',   value:30,  iconKey:'cell6',  stats:{ speed: 0.3 } },
    helm_iron:     { id:'helm_iron',     name:'Iron Helm',            flavor:'Dented above the right eye.',   slot:'head',   value:75,  iconKey:'cell7',  stats:{ def: 3, hp: 12 } },
    helm_circlet:  { id:'helm_circlet',  name:'Hexsmith Circlet',     flavor:'Hums in close fights.',         slot:'head',   value:160, iconKey:'cell8',  stats:{ crit: 0.06, dmg: 2 } },
    charm_luck:    { id:'charm_luck',    name:'Lucky Coin',           flavor:'Heads up. Always.',             slot:'charm',  value:60,  iconKey:'cell9',  stats:{ gold: 0.15 } },
    charm_ember:   { id:'charm_ember',   name:'Ember Stone',          flavor:'Warm against the chest.',       slot:'charm',  value:100, iconKey:'cell10', stats:{ dmg: 2, crit: 0.04 } },
    charm_vow:     { id:'charm_vow',     name:'Vow Token',            flavor:'A promise, kept.',              slot:'charm',  value:140, iconKey:'cell11', stats:{ hp: 30, def: 2 } },
    ring_iron:     { id:'ring_iron',     name:'Iron Band',            flavor:'No stones. Just iron.',         slot:'ring',   value:45,  iconKey:'cell12', stats:{ def: 2 } },
    ring_blood:    { id:'ring_blood',    name:'Bloodbond Ring',       flavor:'Drinks before you do.',         slot:'ring',   value:130, iconKey:'cell3',  stats:{ dmg: 2, hp: 10 } },
    ring_sigil:    { id:'ring_sigil',    name:'Sigil Ring',           flavor:'A name no one says.',           slot:'ring',   value:170, iconKey:'cell4',  stats:{ crit: 0.05, gold: 0.1 } },
    ring_warden:   { id:'ring_warden',   name:'Warden Signet',        flavor:'The forest still listens.',     slot:'ring',   value:240, iconKey:'cell5',  stats:{ dmg: 3, def: 3, crit: 0.03 } },
    relic_bone:    { id:'relic_bone',    name:'Bone Reliquary',       flavor:'A coin from a dead god.',       stack:1,  value:0, iconKey:'cell6' },
    map_scrap:     { id:'map_scrap',     name:'Map Scrap',            flavor:'Half a road on burnt linen.',   stack:99, value:8, iconKey:'cell7' },
    rune_blank:    { id:'rune_blank',    name:'Blank Rune',           flavor:'Waiting for a name.',           stack:99, value:18, iconKey:'cell8' },
    feather_crow:  { id:'feather_crow',  name:'Crow Feather',         flavor:'Black. Wet. Watches you.',      stack:99, value:5, iconKey:'cell9' },
    coin_purse:    { id:'coin_purse',    name:'Coin Purse',           flavor:'Heavy.',                        stack:99, value:0, iconKey:'cell10', use: s => { s.gold = (s.gold||0) + 35; HV_UI.updateGoldHud(); } },
  };
  HV_UI.itemIconUrl = function (item) {
    if (!item) return '';
    return HV_UI.IMG[item.iconKey] || '';
  };

  // ---------- DROP TABLES --------------------------------------------------
  const DROP_TABLES = HV_UI.DROP_TABLES = {
    forest:    [['bread',0.10],['potion_minor',0.06],['forest_gem',0.05],['feather_crow',0.04],['rune_blank',0.02],['map_scrap',0.02],['ring_iron',0.01],['sword_iron',0.005]],
    crossing:  [['bread',0.08],['potion_minor',0.05],['coin_purse',0.04],['map_scrap',0.03]],
    marsh:     [['salt_reed',0.06],['potion_minor',0.06],['potion_major',0.02],['rune_blank',0.03],['ring_blood',0.012],['armor_cloth',0.008]],
    cathedral: [['censer',0.05],['potion_major',0.04],['ring_sigil',0.012],['helm_circlet',0.008],['armor_chain',0.006]],
    catacombs: [['rune_blank',0.06],['potion_major',0.05],['relic_bone',0.03],['ring_warden',0.008],['armor_plate',0.005],['hammer_warden',0.003]],
    town:      [],
  };

  // ---------- INVENTORY STATE ----------------------------------------------
  HV_UI.INV_SIZE = 24;
  HV_UI.HOTBAR_SIZE = 9;

  function freshState() {
    return {
      bag: new Array(HV_UI.INV_SIZE).fill(null),
      equipment: { weapon:null, armor:null, charm:null, head:null, ring1:null, ring2:null },
      hotbar: new Array(HV_UI.HOTBAR_SIZE).fill(null),
      hotbarSelected: 0,
    };
  }
  function ensureInv() {
    if (!window.state) return null;
    if (!state.invSystem) state.invSystem = freshState();
    return state.invSystem;
  }

  // ---------- INVENTORY OPS -----------------------------------------------
  HV_UI.addItem = function (itemId, count) {
    count = count || 1;
    const inv = ensureInv(); if (!inv) return false;
    const def = ITEMS[itemId]; if (!def) { console.warn('[HV_UI] unknown item', itemId); return false; }
    const maxStack = def.stack || 1;
    if (maxStack > 1) {
      for (let i = 0; i < inv.bag.length && count > 0; i++) {
        const s = inv.bag[i];
        if (s && s.id === itemId && s.count < maxStack) {
          const room = maxStack - s.count;
          const take = Math.min(room, count);
          s.count += take; count -= take;
        }
      }
    }
    for (let i = 0; i < inv.bag.length && count > 0; i++) {
      if (!inv.bag[i]) {
        const take = Math.min(maxStack, count);
        inv.bag[i] = { id: itemId, count: take };
        count -= take;
      }
    }
    HV_UI.refreshAll();
    HV_UI.showPickupToast(def.name);
    if (count > 0) console.log('[HV_UI] inventory full, dropped', count, itemId);
    return count === 0;
  };
  HV_UI.removeFromBag = function (slotIdx, count) {
    const inv = ensureInv(); if (!inv) return false;
    const s = inv.bag[slotIdx]; if (!s) return false;
    count = count || 1;
    s.count -= count;
    if (s.count <= 0) inv.bag[slotIdx] = null;
    HV_UI.refreshAll();
    return true;
  };
  HV_UI.equip = function (bagIdx) {
    const inv = ensureInv(); if (!inv) return false;
    const s = inv.bag[bagIdx]; if (!s) return false;
    const def = ITEMS[s.id]; if (!def || !def.slot) return false;
    let target = def.slot;
    if (target === 'ring') {
      target = inv.equipment.ring1 ? (inv.equipment.ring2 ? 'ring1' : 'ring2') : 'ring1';
    }
    const prevId = inv.equipment[target];
    inv.equipment[target] = s.id;
    inv.bag[bagIdx] = prevId ? { id: prevId, count: 1 } : null;
    HV_UI.recalcStats();
    HV_UI.refreshAll();
    return true;
  };
  HV_UI.unequip = function (slotName) {
    const inv = ensureInv(); if (!inv) return false;
    const id = inv.equipment[slotName]; if (!id) return false;
    inv.equipment[slotName] = null;
    HV_UI.addItem(id, 1);
    HV_UI.recalcStats();
    HV_UI.refreshAll();
    return true;
  };
  HV_UI.useFromBag = function (bagIdx) {
    const inv = ensureInv(); if (!inv) return false;
    const s = inv.bag[bagIdx]; if (!s) return false;
    const def = ITEMS[s.id]; if (!def) return false;
    if (def.use) {
      try { def.use(window.state); } catch (e) { console.warn(e); }
      HV_UI.removeFromBag(bagIdx, 1);
      try { if (typeof updateHUD === 'function') updateHUD(); } catch (e) {}
      HV_UI.updateHealthHud();
      return true;
    }
    if (def.slot) return HV_UI.equip(bagIdx);
    return false;
  };
  HV_UI.bindHotbar = function (hotbarIdx, bagIdx) {
    const inv = ensureInv(); if (!inv) return;
    inv.hotbar[hotbarIdx] = bagIdx;
    HV_UI.refreshHotbar();
  };
  HV_UI.useHotbar = function (hotbarIdx) {
    const inv = ensureInv(); if (!inv) return;
    const bagIdx = inv.hotbar[hotbarIdx];
    if (bagIdx == null) return;
    HV_UI.useFromBag(bagIdx);
    if (inv.bag[bagIdx] == null) inv.hotbar[hotbarIdx] = null;
    HV_UI.refreshHotbar();
  };
  HV_UI.selectHotbar = function (idx) {
    const inv = ensureInv(); if (!inv) return;
    inv.hotbarSelected = idx;
    HV_UI.refreshHotbar();
  };

  // ---------- STAT RECALC --------------------------------------------------
  HV_UI.recalcStats = function () {
    const inv = ensureInv(); if (!inv) return;
    const totals = { dmg:0, def:0, hp:0, crit:0, speed:0, gold:0 };
    for (const slot in inv.equipment) {
      const id = inv.equipment[slot]; if (!id) continue;
      const stats = (ITEMS[id] && ITEMS[id].stats) || {};
      for (const k in stats) totals[k] = (totals[k]||0) + stats[k];
    }
    if (!window.state) return;
    state.equipBonus = totals;
    const baseMax = (window.CHARACTERS && state.characterId && CHARACTERS[state.characterId] && CHARACTERS[state.characterId].stats && CHARACTERS[state.characterId].stats.maxHealth) || 100;
    const ratio = state.maxHealth ? (state.health / state.maxHealth) : 1;
    state.maxHealth = baseMax + ((state.talents && state.talents.bonusMaxHP) || 0) + (totals.hp || 0);
    state.health = Math.min(state.maxHealth, Math.max(1, Math.round(state.maxHealth * ratio)));
    state.displayHealth = state.health;
  };

  // ---------- BOOK (animated open) -----------------------------------------
  HV_UI.bookOpen = false;
  HV_UI.activeTab = 'quests';

  HV_UI.openBook = function (tab) {
    if (tab) HV_UI.activeTab = tab;
    const ov = document.getElementById('bookOverlay'); if (!ov) return;
    ov.classList.remove('hidden');
    void ov.offsetHeight;
    ov.classList.add('show');
    let frame = 1;
    const sprite = document.getElementById('bookSprite');
    const tick = () => {
      const key = 'bookF' + frame;
      if (sprite && HV_UI.IMG[key]) sprite.style.backgroundImage = "url('" + HV_UI.IMG[key] + "')";
      frame++;
      if (frame <= 7) setTimeout(tick, 55);
      else {
        if (sprite) sprite.style.backgroundImage = "url('" + HV_UI.IMG.bookF7 + "')";
        ov.classList.add('pagesReady');
        HV_UI.renderTab(HV_UI.activeTab);
      }
    };
    tick();
    HV_UI.bookOpen = true;
    if (window.state) state.paused = true;
    try { sfx && sfx.uiOpen && sfx.uiOpen(); } catch (e) {}
  };
  HV_UI.closeBook = function () {
    const ov = document.getElementById('bookOverlay'); if (!ov) return;
    ov.classList.remove('show'); ov.classList.remove('pagesReady');
    setTimeout(() => ov.classList.add('hidden'), 220);
    HV_UI.bookOpen = false;
    if (window.state) state.paused = false;
    try { sfx && sfx.uiClose && sfx.uiClose(); } catch (e) {}
  };
  HV_UI.renderTab = function (tab) {
    HV_UI.activeTab = tab;
    document.querySelectorAll('.bookTab').forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
    const left  = document.getElementById('bookLeft');
    const right = document.getElementById('bookRight');
    if (!left || !right) return;
    if (tab === 'quests')         HV_UI.renderQuests(left, right);
    else if (tab === 'inventory') HV_UI.renderInventory(left, right);
    else if (tab === 'equipment') HV_UI.renderEquipment(left, right);
    else if (tab === 'calendar')  HV_UI.renderCalendar(left, right);
  };
  HV_UI.renderQuests = function (left, right) {
    left.innerHTML = '<div class="qstHeaderArt invHeaderArt"></div><h2>Wardstone Pilgrimage</h2>';
    right.innerHTML = '<div class="qstHeaderArt invHeaderArt"></div><h2>Side Threads</h2>';
    if (window.QUEST_STAGES && window.state && state.quest) {
      for (let i = 0; i < QUEST_STAGES.length; i++) {
        const s = QUEST_STAGES[i];
        const status = i < state.quest.stage ? 'done' : (i === state.quest.stage ? 'active' : 'locked');
        const div = document.createElement('div');
        div.innerHTML = '<b>' + (s.title || ('Stage ' + i)) + '</b> <span style="opacity:0.7;">[' + status + ']</span><div class="qBody">' + (s.body || '') + '</div>';
        left.appendChild(div);
      }
    }
    if (window.GAME_MODES_GUIDE) {
      for (const g of GAME_MODES_GUIDE) {
        let s = 'available';
        try { s = (g.status && g.status()) || 'available'; } catch (e) {}
        const div = document.createElement('div');
        div.innerHTML = '<b>' + g.name + '</b> <span style="opacity:0.7;">[' + s + ']</span><div class="qBody"><i>Where:</i> ' + g.where + '<br/><i>How:</i> ' + g.how + '</div>';
        right.appendChild(div);
      }
    }
  };
  HV_UI.renderInventory = function (left, right) {
    left.innerHTML  = '<div class="invHeaderArt"></div><h2>Bag</h2>';
    right.innerHTML = '<div class="invHeaderArt"></div><h2>Hotbar Bind</h2><p style="font-size:11px;color:#6e3a1a;">Left-click to use or equip. Right-click to bind to a hotbar slot.</p>';
    const inv = ensureInv(); if (!inv) return;
    const grid = document.createElement('div'); grid.className = 'invGrid';
    for (let i = 0; i < inv.bag.length; i++) {
      const cell = document.createElement('div'); cell.className = 'invCell';
      cell.dataset.bag = i;
      const s = inv.bag[i];
      if (s) {
        const def = ITEMS[s.id];
        const icon = document.createElement('div'); icon.className = 'invIcon';
        icon.style.backgroundImage = "url('" + HV_UI.itemIconUrl(def) + "')";
        cell.appendChild(icon);
        if (s.count > 1) { const c = document.createElement('div'); c.className = 'invCount'; c.textContent = s.count; cell.appendChild(c); }
        cell.addEventListener('mouseenter', e => HV_UI.showTooltip(e, def));
        cell.addEventListener('mousemove',  e => HV_UI.moveTooltip(e));
        cell.addEventListener('mouseleave', () => HV_UI.hideTooltip());
        cell.addEventListener('click', () => { HV_UI.useFromBag(i); HV_UI.renderTab('inventory'); });
        cell.addEventListener('contextmenu', e => {
          e.preventDefault();
          const slot = prompt('Bind to hotbar slot 1-9?');
          const idx = parseInt(slot, 10);
          if (idx >= 1 && idx <= 9) { HV_UI.bindHotbar(idx-1, i); HV_UI.renderTab('inventory'); }
        });
      }
      grid.appendChild(cell);
    }
    left.appendChild(grid);
    const list = document.createElement('div'); list.style.marginTop = '8px';
    for (let i = 0; i < inv.hotbar.length; i++) {
      const row = document.createElement('div');
      const bagIdx = inv.hotbar[i];
      const item = bagIdx != null ? inv.bag[bagIdx] : null;
      const def = item ? ITEMS[item.id] : null;
      row.innerHTML = '<b>Slot ' + (i+1) + ':</b> ' + (def ? def.name + (item.count > 1 ? ' x' + item.count : '') : '<i style="opacity:0.5">empty</i>');
      list.appendChild(row);
    }
    right.appendChild(list);
  };
  HV_UI.renderEquipment = function (left, right) {
    left.innerHTML  = '<div class="eqHeaderArt invHeaderArt"></div><h2>Worn</h2>';
    right.innerHTML = '<div class="eqHeaderArt invHeaderArt"></div><h2>Total Bonus</h2>';
    const inv = ensureInv(); if (!inv) return;
    const doll = document.createElement('div'); doll.className = 'eqDoll';
    const slotDefs = [
      ['head','Head'], ['weapon','Weapon'], ['armor','Armor'], ['charm','Charm'], ['ring1','Ring 1'], ['ring2','Ring 2']
    ];
    for (const [slot, label] of slotDefs) {
      const el = document.createElement('div'); el.className = 'eqSlot'; el.dataset.slot = slot;
      const id = inv.equipment[slot];
      const def = id ? ITEMS[id] : null;
      const icon = document.createElement('div'); icon.className = 'eqIcon';
      if (def) icon.style.backgroundImage = "url('" + HV_UI.itemIconUrl(def) + "')";
      const lbl  = document.createElement('div'); lbl.className = 'eqLabel'; lbl.textContent = label.toUpperCase();
      el.appendChild(icon); el.appendChild(lbl);
      if (def) {
        el.addEventListener('mouseenter', e => HV_UI.showTooltip(e, def));
        el.addEventListener('mousemove',  e => HV_UI.moveTooltip(e));
        el.addEventListener('mouseleave', () => HV_UI.hideTooltip());
        el.addEventListener('click', () => { HV_UI.unequip(slot); HV_UI.renderTab('equipment'); });
      }
      doll.appendChild(el);
    }
    left.appendChild(doll);
    const stats = (state && state.equipBonus) || {};
    const block = document.createElement('div'); block.className = 'eqStats';
    block.innerHTML =
      '<div><b>Damage:</b> +' + (stats.dmg||0) + '</div>' +
      '<div><b>Defense:</b> +' + (stats.def||0) + '</div>' +
      '<div><b>Max HP:</b> +' + (stats.hp||0) + '</div>' +
      '<div><b>Crit:</b> +' + Math.round((stats.crit||0)*100) + '%</div>' +
      '<div><b>Move Speed:</b> +' + (stats.speed||0).toFixed(1) + '</div>' +
      '<div><b>Gold Find:</b> +' + Math.round((stats.gold||0)*100) + '%</div>';
    right.appendChild(block);
  };
  HV_UI.renderCalendar = function (left, right) {
    left.innerHTML  = '<div class="calHeaderArt invHeaderArt"></div><h2>Vigil Calendar</h2>';
    right.innerHTML = '<div class="calHeaderArt invHeaderArt"></div><h2>Sky</h2>';
    const tod = HV_UI.timeOfDay();
    const block = document.createElement('div'); block.className = 'calBlock';
    block.innerHTML =
      '<div class="calBigDay">DAY ' + tod.day + '</div>' +
      '<div class="calLabel">' + tod.phaseLabel + '</div>' +
      '<div class="calIcon" style="background-image:url(\'' + tod.iconUrl + '\');"></div>';
    left.appendChild(block);
    const stats = document.createElement('div');
    stats.style.marginTop = '12px';
    stats.innerHTML =
      '<p><b>Total Vigil time:</b> ' + Math.floor((state && state.time) || 0) + ' s</p>' +
      '<p><b>Total kills:</b> ' + ((state && state.totalKills) || 0) + '</p>' +
      '<p><b>Best streak:</b> x' + ((state && state.streakBest) || 0) + '</p>' +
      '<p><b>Endless best:</b> wave ' + ((state && state.endlessBest) || 0) + '</p>';
    right.appendChild(stats);
  };

  // ---------- TIME OF DAY --------------------------------------------------
  HV_UI.timeOfDay = function () {
    const t = (window.state && state.time) || 0;
    const dayLen = 300;
    const day = 1 + Math.floor(t / dayLen);
    const f = (t % dayLen) / dayLen;
    let phaseLabel, iconKey;
    if (f < 0.20)      { phaseLabel = 'DAWN';   iconKey = 'todSunset'; }
    else if (f < 0.55) { phaseLabel = 'DAY';    iconKey = 'todDay'; }
    else if (f < 0.75) { phaseLabel = 'SUNSET'; iconKey = 'todSunset'; }
    else               { phaseLabel = 'NIGHT';  iconKey = 'todNight'; }
    return { day, phaseLabel, iconUrl: HV_UI.IMG[iconKey], f };
  };

  // ---------- HOTBAR -------------------------------------------------------
  HV_UI.buildHotbar = function () {
    const slotsEl = document.getElementById('hbSlots'); if (!slotsEl) return;
    slotsEl.innerHTML = '';
    for (let i = 0; i < HV_UI.HOTBAR_SIZE; i++) {
      const cell = document.createElement('div'); cell.className = 'hbSlot'; cell.dataset.idx = i;
      cell.innerHTML = '<div class="hbSlotNum">' + (i+1) + '</div><div class="hbSlotIcon"></div><div class="hbSlotCount"></div>';
      cell.addEventListener('click', () => HV_UI.selectHotbar(i));
      cell.addEventListener('contextmenu', e => { e.preventDefault(); HV_UI.useHotbar(i); });
      cell.addEventListener('mouseenter', e => {
        const inv = ensureInv(); if (!inv) return;
        const bagIdx = inv.hotbar[i]; if (bagIdx == null) return;
        const s = inv.bag[bagIdx]; if (!s) return;
        HV_UI.showTooltip(e, ITEMS[s.id]);
      });
      cell.addEventListener('mousemove', e => HV_UI.moveTooltip(e));
      cell.addEventListener('mouseleave', () => HV_UI.hideTooltip());
      slotsEl.appendChild(cell);
    }
    HV_UI.refreshHotbar();
  };
  HV_UI.refreshHotbar = function () {
    const inv = ensureInv(); if (!inv) return;
    const slotsEl = document.getElementById('hbSlots'); if (!slotsEl) return;
    for (let i = 0; i < HV_UI.HOTBAR_SIZE; i++) {
      const cell = slotsEl.children[i]; if (!cell) continue;
      cell.classList.toggle('selected', i === inv.hotbarSelected);
      const bagIdx = inv.hotbar[i];
      const s = bagIdx != null ? inv.bag[bagIdx] : null;
      const def = s ? ITEMS[s.id] : null;
      const iconEl = cell.querySelector('.hbSlotIcon');
      const countEl = cell.querySelector('.hbSlotCount');
      iconEl.style.backgroundImage = def ? "url('" + HV_UI.itemIconUrl(def) + "')" : '';
      countEl.textContent = (s && s.count > 1) ? s.count : '';
    }
    const chooser = document.getElementById('hbChooser');
    if (chooser) {
      const sel = slotsEl.children[inv.hotbarSelected];
      if (sel) {
        const r = sel.getBoundingClientRect();
        const parent = document.getElementById('hotbar').getBoundingClientRect();
        chooser.style.left = (r.left - parent.left + r.width/2 - 32) + 'px';
      }
    }
  };
  HV_UI.refreshAll = function () {
    HV_UI.refreshHotbar();
    if (HV_UI.bookOpen) HV_UI.renderTab(HV_UI.activeTab);
  };

  // ---------- TOOLTIP ------------------------------------------------------
  HV_UI.showTooltip = function (e, def) {
    if (!def) return;
    const tip = document.getElementById('tooltipPopover'); if (!tip) return;
    let html = '<div class="tipName">' + def.name + '</div>';
    if (def.flavor) html += '<div class="tipFlavor">' + def.flavor + '</div>';
    if (def.stats) {
      for (const k in def.stats) {
        const v = def.stats[k];
        const fmt = (k === 'crit' || k === 'gold') ? ('+' + Math.round(v*100) + '%') : ((v>=0?'+':'') + v);
        html += '<div class="tipStat"><b>' + k.toUpperCase() + '</b> ' + fmt + '</div>';
      }
    }
    if (def.value) html += '<div class="tipStat" style="opacity:0.6;">Value: ' + def.value + 'g</div>';
    tip.innerHTML = html;
    tip.classList.remove('hidden');
    HV_UI.moveTooltip(e);
  };
  HV_UI.moveTooltip = function (e) {
    const tip = document.getElementById('tooltipPopover'); if (!tip) return;
    const x = Math.min(window.innerWidth - 260, e.clientX + 14);
    const y = Math.min(window.innerHeight - 120, e.clientY + 14);
    tip.style.left = x + 'px'; tip.style.top = y + 'px';
  };
  HV_UI.hideTooltip = function () {
    const tip = document.getElementById('tooltipPopover'); if (tip) tip.classList.add('hidden');
  };

  // ---------- PICKUP TOAST -------------------------------------------------
  HV_UI._toastTimer = 0;
  HV_UI.showPickupToast = function (name) {
    const el = document.getElementById('itemPickupToast'); if (!el) return;
    el.innerHTML = '<b>+ ' + name + '</b>';
    el.classList.remove('show');
    void el.offsetWidth;
    el.classList.add('show');
    clearTimeout(HV_UI._toastTimer);
    HV_UI._toastTimer = setTimeout(() => el.classList.remove('show'), 1800);
  };

  // ---------- DROP ROLL ----------------------------------------------------
  HV_UI.tryDropItem = function (zoneId) {
    const table = DROP_TABLES[zoneId] || []; if (!table.length) return;
    const r = Math.random();
    let acc = 0;
    for (const [id, p] of table) {
      acc += p;
      if (r < acc) { HV_UI.addItem(id, 1); return; }
    }
  };

  // ---------- HUD UPDATERS -------------------------------------------------
  HV_UI.updateHealthHud = function () {
    if (!window.state) return;
    const cur = state.health || 0;
    const max = state.maxHealth || 100;
    const pct = Math.max(0, Math.min(100, (cur / max) * 100));
    const fillEl  = document.querySelector('#healthBarV2 .hbFill');
    const ghostEl = document.querySelector('#healthBarV2 .hbGhost');
    const curEl   = document.getElementById('hbCur');
    const maxEl   = document.getElementById('hbMax');
    if (fillEl)  fillEl.style.width = pct + '%';
    if (ghostEl) {
      const ghostNow = parseFloat(ghostEl.style.width) || pct;
      ghostEl.style.width = Math.max(pct, ghostNow) + '%';
      setTimeout(() => { if (ghostEl) ghostEl.style.width = pct + '%'; }, 200);
    }
    if (curEl) curEl.textContent = Math.ceil(cur);
    if (maxEl) maxEl.textContent = Math.ceil(max);
    const wrap = document.getElementById('healthBarV2');
    if (wrap) wrap.classList.toggle('crit', pct < 25);
  };
  HV_UI.flashDamage = function () {
    const wrap = document.getElementById('healthBarV2'); if (!wrap) return;
    wrap.classList.remove('damaged'); void wrap.offsetWidth; wrap.classList.add('damaged');
  };
  HV_UI._lastGold = -1;
  HV_UI.updateGoldHud = function () {
    const el = document.getElementById('goldNumNew'); if (!el) return;
    const next = (window.state && state.gold) || 0;
    if (next !== HV_UI._lastGold) {
      el.textContent = next;
      el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump');
      HV_UI._lastGold = next;
    }
  };
  HV_UI.updateTodHud = function () {
    const tod = HV_UI.timeOfDay();
    const ic = document.getElementById('todIcon');
    const lb = document.getElementById('todLabel');
    if (ic) ic.src = tod.iconUrl;
    if (lb) lb.textContent = 'DAY ' + tod.day + ' . ' + tod.phaseLabel;
    const lvl = document.getElementById('portraitLevel');
    if (lvl && window.state) lvl.textContent = state.level || 1;
  };

  // ---------- INIT ---------------------------------------------------------
  HV_UI.init = function () {
    injectCssVars();
    const portraitImg = document.getElementById('portraitImg');
    if (portraitImg) portraitImg.src = HV_UI.IMG.portraitMc;
    const todIcon = document.getElementById('todIcon');
    if (todIcon) todIcon.src = HV_UI.IMG.todDay;
    const compassImg = document.getElementById('compassImg');
    if (compassImg) compassImg.src = HV_UI.IMG.compassRose;

    HV_UI.buildHotbar();
    document.querySelectorAll('.bookTab').forEach(t => {
      t.addEventListener('click', () => HV_UI.renderTab(t.dataset.tab));
    });
    const close = document.getElementById('bookClose');
    if (close) close.addEventListener('click', () => HV_UI.closeBook());
    const ov = document.getElementById('bookOverlay');
    if (ov) ov.addEventListener('click', e => { if (e.target === ov) HV_UI.closeBook(); });
    const db = document.getElementById('dialogBox'); if (db) db.classList.add('useNewSkin');
    window.addEventListener('keydown', e => {
      if (HV_UI.bookOpen) {
        if (e.key === 'Escape' || e.key.toLowerCase() === 'b' || e.key === 'Tab') { e.preventDefault(); HV_UI.closeBook(); }
        return;
      }
      if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) return;
      const k = e.key;
      if (k >= '1' && k <= '9') {
        const idx = parseInt(k, 10) - 1;
        HV_UI.selectHotbar(idx);
      } else if (k.toLowerCase() === 'f') {
        const inv = ensureInv(); if (inv) HV_UI.useHotbar(inv.hotbarSelected);
      } else if (k.toLowerCase() === 'i' || k.toLowerCase() === 'b') {
        e.preventDefault(); HV_UI.openBook('inventory');
      }
    });
    HV_UI.recalcStats();
    HV_UI.refreshAll();
    setInterval(() => {
      try { HV_UI.updateHealthHud(); HV_UI.updateGoldHud(); HV_UI.updateTodHud(); } catch (e) {}
    }, 160);
    console.log('[HV_UI] initialized', Object.keys(HV_UI.IMG).length, 'sprites');
  };

  function tryInit() {
    if (!document.getElementById('hotbar') || !window.state) {
      setTimeout(tryInit, 60);
      return;
    }
    HV_UI.init();
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', tryInit);
  } else {
    tryInit();
  }
})();
```

---

## STEP 4 — Wire HV_UI into the existing legacy code

Twelve precise `str_replace` operations on `game.js`. Apply each in order.

### 4a. Reroute the journal hotkey to open the new book

Find:

```javascript
    const journalOpen = document.getElementById('journalOverlay').classList.contains('show');
    if (journalOpen) closeJournal(); else openJournal();
```

Replace with:

```javascript
    if (window.HV_UI && HV_UI.bookOpen) { HV_UI.closeBook(); }
    else if (window.HV_UI) { HV_UI.openBook('quests'); }
```

### 4b. Redirect the legacy journal functions

Replace the entire body of `openJournal()` (the function block starting `function openJournal() {` and ending at its matching `}`) with:

```javascript
function openJournal() {
  if (window.HV_UI) HV_UI.openBook('quests');
}
```

Replace the entire body of `closeJournal()` similarly:

```javascript
function closeJournal() {
  if (window.HV_UI) HV_UI.closeBook();
}
```

### 4c. Pulse the new gold counter on every gold award

Search for every `state.gold +=` in the file. After each, append on the very next line:

```javascript
  if (window.HV_UI) HV_UI.updateGoldHud();
```

### 4d. Drop items on enemy death

Find the enemy-death resolution (search for `state.totalKills++`). Append immediately after that line:

```javascript
  if (window.HV_UI && state.zone) HV_UI.tryDropItem(state.zoneId);
```

### 4e. Apply equipment damage and crit to player attacks

Find the player-attack damage calculation (search for `state.talents.dmgMult`). After `damage` is computed but before it is applied to an enemy, insert:

```javascript
  if (state.equipBonus) damage += (state.equipBonus.dmg || 0);
  const _critChance = (state.talents.critChance || 0) + ((state.equipBonus && state.equipBonus.crit) || 0);
  if (Math.random() < _critChance) damage *= (state.talents.critMult || 2.0);
```

If the legacy code has its own crit roll at the same site, remove it so rolls do not double up.

### 4f. Apply equipment defense and flash on hit

Find the player damage-taken block (`state.health -=` paired with a `damage` variable). Insert before HP is reduced:

```javascript
  if (state.equipBonus && state.equipBonus.def) {
    damage = Math.max(1, damage - state.equipBonus.def);
  }
```

After HP is reduced, insert:

```javascript
  if (window.HV_UI) HV_UI.flashDamage();
```

### 4g. Apply equipment speed

Find the line where player movement speed is summed (search for `state.talents.moveBonus`). Add `+ ((state.equipBonus && state.equipBonus.speed) || 0)` to the expression.

### 4h. Apply gold-find bonus

In the gold-pickup helper that uses `goldMult`, multiply by `(1 + ((state.equipBonus && state.equipBonus.gold) || 0))` at the same site.

### 4i. Save-schema bump and inventory persistence

Find:

```javascript
      v: 3,                                         // schema version (bumped: expansion zones)
```

Replace with:

```javascript
      v: 4,                                         // schema version (bumped: ui overhaul + inventory)
      invSystem: state.invSystem || null,
```

In `loadGame`, find:

```javascript
    if ((s.v || 0) < 3) {
```

Replace with:

```javascript
    if ((s.v || 0) < 4) {
```

After `state.gold = s.gold || 0;` in `loadGame`, add:

```javascript
    if (s.invSystem) state.invSystem = s.invSystem;
    if (window.HV_UI) { HV_UI.recalcStats(); HV_UI.refreshAll(); }
```

In the bootstrap pre-flight save-wipe, find:

```javascript
    if (!_s || (_s.v || 0) < 3) localStorage.removeItem('hv_save');
```

Replace with:

```javascript
    if (!_s || (_s.v || 0) < 4) localStorage.removeItem('hv_save');
```

### 4j. Fresh-game state must clear inventory

In `mainMenuStart()`, after `state.gold = 0; state.shopBought = {}; state.wave = 1;`, add:

```javascript
  state.invSystem = null;
  if (window.HV_UI) { HV_UI.recalcStats(); HV_UI.refreshAll(); }
```

### 4k. Starter kit on new game

In `mainMenuStart()`, just before its closing `}`, add:

```javascript
  setTimeout(() => {
    if (!window.HV_UI) return;
    HV_UI.addItem('sword_iron', 1);
    HV_UI.addItem('potion_minor', 3);
    HV_UI.addItem('bread', 5);
    const inv = state.invSystem;
    for (let i = 0; i < inv.bag.length; i++) {
      if (inv.bag[i] && inv.bag[i].id === 'sword_iron') { HV_UI.equip(i); break; }
    }
    for (let i = 0; i < inv.bag.length; i++) {
      if (inv.bag[i] && inv.bag[i].id === 'potion_minor') { HV_UI.bindHotbar(0, i); break; }
    }
    HV_UI.refreshAll();
  }, 200);
```

### 4l. Keep the legacy health bar in sync

For every line that writes to the legacy `#healthFill` (search `healthFill.style.width`), append on the next line:

```javascript
  if (window.HV_UI) HV_UI.updateHealthHud();
```

The 6 Hz fallback timer drives this regardless, so this only matters for instant feedback on damage frames.

---

## STEP 5 — Animation + wiring verification

### Every animation in this patch and its trigger

| Animation | Trigger | Defined in |
|---|---|---|
| Heart pulse on health bar | HP < 25% | CSS `heartPulse` keyframes; class `crit` toggled by `updateHealthHud` |
| Health bar shake | Damage taken | CSS `hbShake` keyframes; class `damaged` toggled by `flashDamage` |
| Yellow ghost-bar lerp | Damage taken | CSS transition on `.hbGhost width`; JS schedules width change |
| Gold counter bump | Gold gained | CSS `goldBump` keyframes; class `bump` toggled by `updateGoldHud` |
| 7-frame book sprite cycle | Open book | JS loop in `openBook()` swaps `bookF1` to `bookF7` at 55ms cadence |
| Book frame scale-in (0.55 to 1, rotate -4 to 0) | Book opens | CSS transition on `#bookFrame transform` when `.show` added |
| Pages fade-in after book opens | After last frame | CSS transition on `#bookPages opacity`; class `pagesReady` |
| Bookmark tab slide on hover/active | Hover or click | CSS transition on `.bookTab transform` |
| Calendar day text glow pulse | Calendar tab visible | CSS `calPulse` keyframes |
| Inventory cell hover lift | Mouse enter | CSS `.invCell:hover transform: scale(1.05)` |
| Hotbar slot hover lift | Mouse enter | CSS `.hbSlot:hover transform: translateY(-2px)` |
| Hotbar chooser smooth slide | Slot 1..9 selection | CSS transition on `#hbChooser left` |
| Hotbar chooser glow pulse | Always on | CSS `chooserBob` keyframes |
| Compass rotation bob | Always on | CSS `compassBob` keyframes |
| Item pickup toast slide + wiggle | Item added | CSS `toastWiggle` keyframes; class `show` |
| Tooltip appear | Mouse over inventory/hotbar/equip item | JS `showTooltip()` removes `.hidden` |
| Dialog box new skin | Init | JS adds `.useNewSkin` class to `#dialogBox` |

### Every hook and the function it calls

| Hook | Calls |
|---|---|
| Press TAB / J | `openBook('quests')` or `closeBook()` (4a) |
| Press I or B | `openBook('inventory')` (init keydown) |
| Press 1..9 | `selectHotbar(n-1)` |
| Press F | `useHotbar(selected)` |
| Press ESC inside book | `closeBook()` |
| Click hotbar slot | `selectHotbar` |
| Right-click hotbar slot | `useHotbar` |
| Click inventory cell | `useFromBag` |
| Right-click inventory cell | Prompt + `bindHotbar` |
| Click equipment cell | `unequip` |
| Click outside book | `closeBook` |
| Click bookmark tab | `renderTab` |
| Hover any item slot | `showTooltip` |
| Enemy death | `tryDropItem` (4d) |
| Gold awarded | `updateGoldHud` (4c) |
| Player damage | `flashDamage` (4f) |
| HP changes | `updateHealthHud` (6 Hz timer + 4l hook) |
| Time progresses | `updateTodHud` (6 Hz timer reads `state.time`) |
| New game | `mainMenuStart` adds starter kit (4k) |
| Save | `saveGame` writes `invSystem` (4i) |
| Load | `loadGame` restores `invSystem`, calls `recalcStats` + `refreshAll` (4i) |

### Final checklist

After applying, hard-reload and confirm:

1. Console logs `[HV_UI] initialized 72 sprites`
2. Style 1 chevron health bar visible at top-left, heart on the left, vines on each side, red fill
3. Portrait + gold + DAY 1 strip below the health bar
4. Hotbar at bottom-center, chooser sprite hovers over slot 1 with a gentle glow pulse
5. Pressing 1..9 slides the chooser smoothly between slots
6. Pressing TAB plays the 7-frame book opening, then bookmarks fade in on the right side
7. Clicking each tab swaps pages
8. Killing an enemy in Forest occasionally triggers a parchment toast above center
9. Item drops appear in the bag tab with stacking
10. Clicking an equippable bag item moves it to the equipment tab and updates the stat panel
11. Right-clicking a bag item prompts for a hotbar slot 1..9 and binds it
12. Pressing F uses the currently selected hotbar slot
13. Calendar shows DAY 1 plus DAWN / DAY / SUNSET / NIGHT phase synced to elapsed `state.time`
14. Compass rose floats top-right next to the minimap, gently bobbing
15. Saving and reloading preserves bag, equipment, and hotbar bindings

If `[HV_UI] initialized` does not log: the JS module did not load. Check that Step 3 was appended at the very end of `game.js` and that the cache version in Step 1a was bumped.

If the book opens but stays on frame 1: confirm seven distinct keys (`bookF1` through `bookF7`) exist in `HV_UI.IMG`.

If the health bar shows but never updates: Step 4l was skipped. The 6 Hz timer fixes it within 160 ms of any damage event regardless.
