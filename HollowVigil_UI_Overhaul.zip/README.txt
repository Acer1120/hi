HOLLOW VIGIL — UI OVERHAUL PATCH (fully self-contained)
========================================================

Single drop-in update for the Hollow Vigil project. Every sprite is
base64-embedded inside PATCH.md. No external asset files are needed.

Contents:
  PATCH.md      Master instructions. Read top-to-bottom.
                Steps 0..5: HTML edits, CSS append, JS module append,
                wiring patches, verification checklist.

How to apply:
  1. Hand PATCH.md to Claude Code.
  2. Tell it: "Apply PATCH.md end-to-end against the project,
     then run through the Step 5 checklist."
  3. Hard-refresh the browser (Ctrl+Shift+R).
  4. Confirm the console logs "[HV_UI] initialized 72 sprites".

What's inside PATCH.md:
  - 72 PNG sprites encoded as base64 data URIs (Style 1 health bar,
    Pixelwood book frames, toolbar, portraits, bookmarks, artwork,
    icon containers, dialog paper, time-of-day, compass, gold counter)
  - HTML markup for new HUD elements
  - CSS for layout + 7 keyframe animations + 12 transitions
  - HV_UI JS module: item registry (28 items), 24-slot inventory,
    6-slot equipment paper-doll, 9-slot hotbar, animated book opener,
    calendar, drop tables, pickup toast, tooltip, save/load v4 schema
  - 12 str_replace operations to wire HV_UI into the existing legacy code
  - Animation + hook verification tables and 15-point checklist

That's it. No other files needed.
